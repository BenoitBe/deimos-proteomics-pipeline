# ==============================================================================
# config.py — Gestion de la configuration YAML réutilisable
# Deimos — DIA Expression Integrated Multi-Omics Suite
# ==============================================================================
# Usage CLI :
#   python deimos.py                        → questions interactives
#   python deimos.py --config mon_projet.yaml  → chargement direct
#   python deimos.py --save-config          → questions + sauvegarde
#
# Après chaque run, last_config.yaml est toujours écrit dans out_dir.
# ==============================================================================

import os
import sys
import json
import argparse
from datetime import datetime
from typing import Optional

# PyYAML optionnel → fallback JSON transparent
try:
    import yaml
    _YAML_OK = True
except ImportError:
    _YAML_OK = False


# ── Clés obligatoires et leurs valeurs par défaut ──────────────────────────────
_DEFAULTS = {
    # Volcanos / Robustness
    "volcano_use_padj":    False,
    "volcano_p_thresh":    0.05,
    "volcano_ratio_min":   1.5,
    # Axe Y des volcanos : "pvalue" = -log10(p brute) (défaut, comme limma ; si le seuil
    # porte sur la p.adj, la ligne est placée à la p brute équivalente) | "padj" =
    # -log10 de la statistique du seuil (comportement antérieur)
    "volcano_y_axis":      "pvalue",
    # Loading plot de la PCA : nombre de protéines motrices annotées, réparties entre
    # PC1+, PC1-, PC2+, PC2- (0 = aucune annotation)
    "pca_n_drivers":       20,
    # ANOVA / Heatmap
    "anova_use_padj":      False,
    "anova_p_thresh":      0.05,
    # Heatmap clusters
    "n_heatmap_clusters":  3,
    # Robustness
    "n_iter_robustness":   0,
    # Correction FDR
    "fdr_global":          False,
    # Contrastes : "__auto__" = tous (question au-delà de 30) | "all" |
    # liste de motifs "A_vs_B", {x} = même valeur des deux côtés, * = libre
    # ex: ["Live_{s}_vs_Heat_killed_{s}"]
    "contrasts":           "__auto__",
    # Imputation
    "impute_method":       "auto",   # auto (diagnostic) | qrilc | mixed | mixed_legacy
    "seed":                42,      # graine du tirage d'imputation (reproductibilité)
    # Modules optionnels
    "go_organism":         None,    # None = désactivé
    "go_backend":          "gprofiler",  # "gprofiler" | "string" (bactéries, non-modèles)
    "go_species_taxid":    None,    # si go_backend == "string" : "auto" (détection depuis les accessions) ou taxid de SOUCHE (ex: 511145)
    "string_caller_identity": "Proteogen",  # identifiant appelant STRING (pas de donnée perso)
    # Univers de l'ORA (gProfiler, STRING, clusters) : "quantified" = protéines
    # testées (défaut) | "genome" = génome annoté entier (comportement antérieur)
    "enrichment_background": "quantified",
    "string_background":   None,         # None = suit enrichment_background ; "genome" | "quantified" force STRING
    "string_reference_taxid": None,  # mode orthologie : organisme STRING cible (défaut : espèce parente via UniProt)
    "string_reference_fasta": None,  # protéome STRING local (sinon dossier des données, puis téléchargement)
    "string_categories":   None,    # None = GO:BP/MF/CC + KEGG + Reactome ; ex: [Process, KEGG, Keyword, Pfam]
    "perseverance_annotation_path": None,  # TSV Perseverance (protein_id, GO, KEGG, Pfam) -> ORA local, independant de go_organism
    "control_condition":   "__auto__",  # "__auto__"=detection par synonymes, str=explicite, False=desactive
    "control_synonyms":    None,     # None = liste par defaut (ctl, ctrl, control, wt, mock...)
    "run_perseverance":    "__auto__",  # "__auto__"=demande, True/False=explicite
    "perseverance_reference_organism": None,  # code gProfiler de l'espece de reference (ex: "athaliana")
    "perseverance_fasta_a": None,    # chemin FASTA explicite (sinon auto-scan du dossier de tsv_path)
    "perseverance_fasta_b": None,
    "perseverance_min_identity": 25.0,
    "perseverance_min_coverage": 50.0,
    "export_matrices":     True,     # matrices/ : log2 NA, imputée, DPC (Mfuzz, MOFA+...)
    "run_gsea":            False,    # GSEA rank-based (optionnel, complément ORA)
    "gsea_organism":       "human",  # jeux de gènes : human (Enrichr) | mouse (MSigDB souris)
    "gsea_gene_sets":      None,     # None = défaut de l'organisme ; liste de .gmt locaux,
                                     # "msigdb:<collection>" ou noms Enrichr
    "gsea_msigdb_version": None,     # None = 2025.1.Hs / 2025.1.Mm
    "gsea_rank_p":         "pvalue", # classement sur la p brute | volcano (ancien : p du volcano)
    "gsea_fdr":            0.25,
    "gsea_permutations":   1000,
    "qc_only":             False,   # True = données brutes + M&M + figures QC seulement (auto si aucun réplicat)
    "make_wgcna":          False,
    "make_dashboard":      True,
    # Statistique principale : "dpc" = sans imputation (méthode limpa, précurseurs,
    # repli automatique sur l'imputation sans pr_matrix exploitable) | "imputation"
    "primary_statistic":   "dpc",
    # Sensibilité aux valeurs manquantes (comparaison DPC / imputation, détection)
    "dpc_sensitivity":     True,    # analyse différentielle sans imputation (DPC)
    "differential_detection": True, # protéines on/off : test de détection (DPC)
    "dpc_level":           "auto",  # auto (précurseurs si pr_matrix, sinon protéines) | precursor | protein
    # Pathfinder (synthèse multi-contrastes en fin de run, processus séparé)
    "make_pathfinder":     False,   # True = lancer Pathfinder après l'Excel et le dashboard
    "pathfinder_path":     None,    # clone Pathfinder ; None = $PATHFINDER_HOME puis ../Pathfinder
    "pathfinder_publications": False,  # True = axe Publications (STRING PMID, réseau)
    "pathfinder_options":  {},      # ex: {pthr: 0.05, jaccard: 0.5, no_umap: true}
    "pathfinder_timeout":  1800,    # secondes
    "use_deqms":           False,
    "deqms_min_r2":        0.10,   # R2 min variance~comptage (sous-ensemble count>1)
    "deqms_max_pseudocount_pct": 50.0,  # % max de proteines a count<=1 tolere
    "deqms_force":         False,  # bypass le diagnostic, force DEqMS meme si defavorable
    "batch_column":        None,   # colonne ExperimentalDesign.csv a controler comme covariable
    # Chemins (peuvent être surchargés)
    "tsv_path":            "report.pg_matrix.tsv",
    "design_path":         "ExperimentalDesign.csv",
    "pr_path":             "report.pr_matrix.tsv",
    "out_dir":             "proteomics_output",
}

# Clés dérivées calculées automatiquement (non stockées dans le YAML)
_COMPUTED = {"volcano_lfc_min"}


# ── Helpers de sérialisation ────────────────────────────────────────────────────

def _dumps(obj: dict) -> str:
    """Sérialise en YAML si disponible, sinon JSON indenté."""
    if _YAML_OK:
        return yaml.dump(obj, allow_unicode=True, sort_keys=False,
                         default_flow_style=False)
    return json.dumps(obj, ensure_ascii=False, indent=2)


def _loads(text: str) -> dict:
    """Désérialise YAML ou JSON (auto-détection)."""
    stripped = text.lstrip()
    if stripped.startswith("{") or stripped.startswith("["):
        return json.loads(text)
    if _YAML_OK:
        return yaml.safe_load(text)
    # Pas de yaml installé et pas du JSON → erreur claire
    raise RuntimeError(
        "PyYAML non installé et le fichier ne semble pas être du JSON.\n"
        "  → pip install pyyaml"
    )


# ── Résolution des clés dérivées ────────────────────────────────────────────────

def _resolve(params: dict) -> dict:
    """Calcule les clés dérivées à partir des clés brutes."""
    import numpy as np
    params["volcano_lfc_min"] = float(np.log2(params["volcano_ratio_min"]))
    return params


# ── Validation ──────────────────────────────────────────────────────────────────

def _validate(params: dict) -> list[str]:
    """Retourne la liste des erreurs (vide = OK)."""
    errors = []
    for p_key in ("volcano_p_thresh", "anova_p_thresh"):
        v = params.get(p_key)
        if not (isinstance(v, (int, float)) and 0 < v <= 1):
            errors.append(f"  {p_key} doit être dans ]0, 1] (valeur : {v!r})")
    if params.get("volcano_ratio_min", 0) < 1:
        errors.append(f"  volcano_ratio_min doit être ≥ 1 "
                      f"(valeur : {params.get('volcano_ratio_min')!r})")
    if str(params.get("volcano_y_axis", "pvalue")).lower() not in ("pvalue", "padj"):
        errors.append(f"  volcano_y_axis doit être 'pvalue' ou 'padj' "
                      f"(valeur : {params.get('volcano_y_axis')!r})")
    try:
        if int(params.get("pca_n_drivers", 20)) < 0:
            raise ValueError
    except (TypeError, ValueError):
        errors.append(f"  pca_n_drivers doit être un entier >= 0 "
                      f"(valeur : {params.get('pca_n_drivers')!r})")
    if params.get("n_heatmap_clusters", 0) < 2:
        errors.append(f"  n_heatmap_clusters doit être ≥ 2")
    if params.get("n_iter_robustness", 0) < 0:
        errors.append(f"  n_iter_robustness doit être ≥ 0 (0 = désactivé)")
    try:
        int(params.get("seed", 42))
    except (TypeError, ValueError):
        errors.append(f"  seed doit être un entier")
    if params.get("impute_method") not in ("auto", "qrilc", "mixed", "mixed_legacy"):
        errors.append(f"  impute_method doit être 'auto', 'qrilc', 'mixed' ou 'mixed_legacy'")
    backend = params.get("go_backend", "gprofiler")
    if backend not in ("gprofiler", "string"):
        errors.append(f"  go_backend doit être 'gprofiler' ou 'string' (valeur : {backend!r})")
    _tx = params.get("go_species_taxid")
    if backend == "string" and _tx is not None and str(_tx).lower() != "auto":
        try:
            int(_tx)
        except (TypeError, ValueError):
            errors.append(f"  go_species_taxid doit être un entier (NCBI taxid) "
                          f"ou 'auto', valeur : {_tx!r}")
    _ct = params.get("contrasts", "__auto__")
    if _ct not in (None, "all", "__auto__"):
        _items = [_ct] if isinstance(_ct, str) else _ct
        if not isinstance(_items, list) or not all(
                isinstance(x, str) and x.count("_vs_") == 1 for x in _items):
            errors.append(f"  contrasts : liste de motifs 'A_vs_B' attendue "
                          f"(ou 'all'), valeur : {_ct!r}")
    if params.get("enrichment_background", "quantified") not in ("genome", "quantified"):
        errors.append(f"  enrichment_background doit être 'quantified' ou 'genome'")
    if params.get("string_background") not in (None, "genome", "quantified"):
        errors.append(f"  string_background doit être 'genome', 'quantified' ou absent")
    if str(params.get("primary_statistic", "dpc")).lower() not in ("dpc", "imputation"):
        errors.append(f"  primary_statistic doit être 'dpc' ou 'imputation' "
                      f"(valeur : {params.get('primary_statistic')!r})")
    for k in ("dpc_sensitivity", "differential_detection", "export_matrices"):
        if not isinstance(params.get(k, True), bool):
            errors.append(f"  {k} doit être true ou false (valeur : {params.get(k)!r})")
    if str(params.get("dpc_level", "auto")).lower() not in ("auto", "precursor", "protein"):
        errors.append(f"  dpc_level doit être 'auto', 'precursor' ou 'protein'")
    if str(params.get("gsea_organism", "human")).lower() not in ("human", "mouse"):
        errors.append(f"  gsea_organism doit être 'human' ou 'mouse' "
                      f"(valeur : {params.get('gsea_organism')!r})")
    if str(params.get("gsea_rank_p", "pvalue")).lower() not in ("pvalue", "volcano"):
        errors.append(f"  gsea_rank_p doit être 'pvalue' ou 'volcano'")
    _gs = params.get("gsea_gene_sets")
    if _gs is not None and not (isinstance(_gs, str) or (
            isinstance(_gs, list) and all(isinstance(x, str) for x in _gs))):
        errors.append(f"  gsea_gene_sets : liste de .gmt, 'msigdb:<collection>' ou "
                      f"noms Enrichr attendue (valeur : {_gs!r})")
    try:
        if not 0 < float(params.get("gsea_fdr", 0.25)) <= 1:
            raise ValueError
    except (TypeError, ValueError):
        errors.append(f"  gsea_fdr doit être dans ]0, 1]")
    try:
        if int(params.get("gsea_permutations", 1000)) < 100:
            raise ValueError
    except (TypeError, ValueError):
        errors.append(f"  gsea_permutations doit être un entier >= 100")
    from pathfinder_bridge import validate_pathfinder_params
    errors += validate_pathfinder_params(params)
    return errors


# ── Chargement depuis fichier ───────────────────────────────────────────────────

def load_config(path: str) -> dict:
    """
    Charge un fichier YAML ou JSON de configuration.
    Complète les clés manquantes avec _DEFAULTS.
    Valide et lève ValueError si incohérent.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Fichier de config introuvable : {path}")

    with open(path, "r", encoding="utf-8") as f:
        raw = _loads(f.read())

    if not isinstance(raw, dict):
        raise ValueError(f"Le fichier de config doit être un dictionnaire (trouvé : {type(raw).__name__})")

    # Fusion avec les defaults (les clés du fichier ont priorité)
    params = {**_DEFAULTS, **raw}

    errors = _validate(params)
    if errors:
        raise ValueError("Config invalide :\n" + "\n".join(errors))

    return _resolve(params)


# ── Sauvegarde ──────────────────────────────────────────────────────────────────

def save_config(params: dict, path: str, comment: str = "") -> None:
    """
    Sauvegarde les paramètres dans un fichier YAML (ou JSON si PyYAML absent).
    Exclut les clés calculées (_COMPUTED) et ajoute un en-tête horodaté.
    """
    # On ne stocke que les clés sérialisables (pas les clés dérivées)
    out = {k: v for k, v in params.items()
           if k not in _COMPUTED and k in _DEFAULTS}

    ext = ".yaml" if _YAML_OK else ".json"
    # Forcer l'extension correcte si l'utilisateur n'a pas mis d'extension
    base, file_ext = os.path.splitext(path)
    if file_ext.lower() not in (".yaml", ".yml", ".json"):
        path = base + ext

    header_lines = [
        f"# Pipeline Protéomique — Config générée le {datetime.now().strftime('%Y-%m-%d %H:%M')}",
    ]
    if comment:
        header_lines.append(f"# {comment}")
    header_lines.append("")
    header = "\n".join(header_lines)

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        if _YAML_OK:
            f.write(header)
        f.write(_dumps(out))

    print(f"  [SAVE] Config saved: {path}")


# ── Affichage récapitulatif ─────────────────────────────────────────────────────

def print_config_summary(params: dict) -> None:
    """Affiche un récapitulatif lisible des paramètres chargés."""
    import numpy as np
    v_stat  = "p.adj (FDR)" if params["volcano_use_padj"] else "raw p.value"
    a_stat  = "p.adj (FDR)" if params["anova_use_padj"]   else "raw p.value"
    fdr_txt = "global (whole study)" if params["fdr_global"] else "per contrast"
    rob_txt = ("disabled" if params["n_iter_robustness"] == 0
               else f"{params['n_iter_robustness']} iterations")
    imp_txt = {"qrilc": "QRILC (pure MNAR)", "mixed": "Mixed (QRILC + kNN)",
               "mixed_legacy": "Mixed, legacy rule (QRILC + kNN per condition)",
               "auto": "Auto (Mixed if >= 20% MAR, else QRILC)"}.get(
               params.get("impute_method", "auto"), str(params.get("impute_method")))
    if params.get("go_backend", "gprofiler") == "string":
        go_txt = (f"STRING, taxid {params['go_species_taxid']} "
                  f"(background: {params.get('string_background') or params.get('enrichment_background', 'quantified')})"
                  if params.get("go_species_taxid") else "no (STRING without taxid)")
    else:
        go_txt = (f"gProfiler, {params['go_organism']} (background: "
                  f"{params.get('enrichment_background', 'quantified')})"
                  if params.get("go_organism") else "no")
    wgcna_txt = "yes" if params.get("make_wgcna") else "no"
    dash_txt  = "yes" if params.get("make_dashboard") else "no"
    sens = [n for k, n in (("dpc_sensitivity", "imputation-free DPC"),
                           ("differential_detection", "differential detection"))
            if params.get(k, True)]
    sens_txt  = " + ".join(sens) if sens else "no"
    pf_txt    = ("yes" + (" (+ Publications, online)" if params.get("pathfinder_publications")
                          else " (offline)")) if params.get("make_pathfinder") else "no"
    deqms_txt = "yes" if params.get("use_deqms") else "no"

    print("\n  [OK] Parameters:")
    print(f"     Volcanos/Robustness -> {v_stat} < {params['volcano_p_thresh']}"
          f"  |  ratio >= {params['volcano_ratio_min']}"
          f"  (log2FC >= {params['volcano_lfc_min']:.3f})")
    print(f"     Volcano Y axis      -> -log10("
          f"{'p.value' if str(params.get('volcano_y_axis', 'pvalue')).lower() == 'pvalue' else v_stat})")
    print(f"     ANOVA/Heatmap       -> {a_stat} < {params['anova_p_thresh']}")
    print(f"     Heatmap clusters    -> {params['n_heatmap_clusters']}")
    print(f"     Robustness          -> {rob_txt}")
    print(f"     FDR correction      -> {fdr_txt}")
    _ct = params.get("contrasts", "__auto__")
    ct_txt = ("all pairs (question if > 30)" if _ct == "__auto__"
              else "all pairs" if _ct in (None, "all")
              else ", ".join([_ct] if isinstance(_ct, str) else _ct))
    print(f"     Contrasts           -> {ct_txt}")
    _ps = str(params.get("primary_statistic", "dpc")).lower()
    print(f"     Primary statistic   -> "
          + ("imputation-free DPC, precursor level (limpa method); imputed analysis "
             "kept as secondary" if _ps == "dpc" else "imputation + limma/DEqMS"))
    print(f"     Imputation          -> {imp_txt}")
    print(f"     GO enrichment       -> {go_txt}")
    if params.get("run_gsea"):
        _gorg = str(params.get("gsea_organism") or "human").lower()
        _gsets = params.get("gsea_gene_sets")
        _rk = ("raw p" if str(params.get("gsea_rank_p", "pvalue")).lower() == "pvalue"
               else "volcano p")
        print(f"     GSEA                -> {_gorg} gene sets"
              + (f" ({len(_gsets) if isinstance(_gsets, list) else 1} custom source(s))"
                 if _gsets else " (defaults)") + f", ranked on {_rk}")
    if params.get("qc_only"):
        print(f"     Mode                -> QC ONLY (raw data + M&M + QC figures)")
    print(f"     WGCNA               -> {wgcna_txt}")
    print(f"     Dashboard           -> {dash_txt}")
    print(f"     Missing values      -> {sens_txt} "
          + ("(comparison with the imputed analysis)" if _ps == "dpc"
             else "(added to the imputed analysis)"))
    print(f"     Pathfinder          -> {pf_txt}")
    print(f"     DEqMS               -> {deqms_txt}")


# ── Parsing des arguments CLI ───────────────────────────────────────────────────

def parse_cli_args() -> argparse.Namespace:
    """
    Parse les arguments de ligne de commande.
    Appelé UNE seule fois au début de main().
    """
    parser = argparse.ArgumentParser(
        description="Pipeline protéomique LFQ DIA — Proteogen",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "--config", "-c",
        metavar="CONFIG.yaml",
        help="Charger une configuration YAML/JSON existante (court-circuite les questions).",
    )
    parser.add_argument(
        "--save-config",
        metavar="NOM.yaml",
        nargs="?",
        const="__AUTO__",  # présent sans valeur → nom auto
        help=(
            "Sauvegarder la config après les questions interactives.\n"
            "  Sans argument : nom automatique (projet_YYYYMMDD.yaml)\n"
            "  Avec argument : chemin spécifié."
        ),
    )
    parser.add_argument(
        "--tsv",
        metavar="report.pg_matrix.tsv",
        default=None,
        help="Chemin du fichier pg_matrix.tsv (surcharge la config).",
    )
    parser.add_argument(
        "--design",
        metavar="ExperimentalDesign.csv",
        default=None,
        help="Chemin du fichier ExperimentalDesign.csv (surcharge la config).",
    )
    parser.add_argument(
        "--out-dir",
        metavar="proteomics_output",
        default=None,
        help="Dossier de sortie (surcharge la config).",
    )
    parser.add_argument(
        "--qc-only",
        action="store_true",
        help=("Mode QC seul : Excel avec données brutes, M&M et figures QC, sans "
              "statistiques (activé automatiquement si aucune condition n'a de "
              "réplicat)."),
    )
    parser.add_argument(
        "--pathfinder",
        action="store_true",
        help=("Lancer la synthèse Pathfinder en fin de run (make_pathfinder: true), "
              "dans un processus séparé ; sorties dans <out_dir>/pathfinder/."),
    )
    parser.add_argument(
        "--batch-column",
        metavar="batch",
        default=None,
        help=("Nom de colonne dans ExperimentalDesign.csv à contrôler comme "
              "covariable nuisance dans le design (batch, plaque, ordre "
              "d'injection catégorisé...). Surcharge la config."),
    )
    return parser.parse_args()


# ── Proposition de rechargement de la config précédente ────────────────────────

def maybe_reload_last_config(out_dir: str) -> Optional[dict]:
    """
    Si un last_config.yaml existe dans out_dir, propose à l'utilisateur
    de le recharger pour éviter de rerépondre aux questions.
    Retourne le dict params si accepté, None sinon.
    """
    # Cherche dans out_dir ET dans le répertoire courant
    candidates = [
        os.path.join(out_dir, "last_config.yaml"),
        os.path.join(out_dir, "last_config.json"),
        "last_config.yaml",
        "last_config.json",
    ]
    found = next((p for p in candidates if os.path.exists(p)), None)
    if not found:
        return None

    mtime = datetime.fromtimestamp(os.path.getmtime(found))
    print(f"\n  [RELOAD] Previous config found: {found}")
    print(f"     (generated on {mtime.strftime('%Y-%m-%d %H:%M')})")

    rep = input("  Reload this config? (Y/n) -> ").strip().lower()
    if rep in ("", "o", "oui", "y", "yes"):
        try:
            params = load_config(found)
            print("  [OK] Config reloaded.")
            print_config_summary(params)
            confirm = input("\n  Continue with these parameters? (Y/n) -> ").strip().lower()
            if confirm in ("", "o", "oui", "y", "yes"):
                return params
            else:
                print("  -> Interactive reconfiguration.")
                return None
        except Exception as e:
            print(f"  [WARN] Could not load config ({e}). "
                  f"Interactive reconfiguration.")
            return None
    return None


# ── Point d'entrée principal (appelé depuis main()) ────────────────────────────

def resolve_config(ask_params_fn, ask_go_params_fn,
                   go_available: bool, dash_available: bool,
                   pr_path: str) -> dict:
    """
    Logique centrale de résolution de la configuration :

    1. Parse les args CLI.
    2. Si --config → charger le fichier, compléter les flags optionnels manquants.
    3. Sinon, proposer de recharger last_config.yaml.
    4. Sinon, lancer les questions interactives (ask_params_fn + ask_go_params_fn).
    5. Si --save-config → sauvegarder.
    6. Toujours sauvegarder last_config.yaml dans out_dir.

    Retourne le dict params complet (avec clés dérivées).
    """
    args = parse_cli_args()

    print("\n" + "="*60)
    print("  PROTEOMICS PIPELINE — Statistical threshold configuration")
    print("="*60)

    # -- A. Load from --config --------------------------------------------------
    if args.config:
        print(f"\n  [LOAD] Loading config: {args.config}")
        try:
            params = load_config(args.config)
        except (FileNotFoundError, ValueError, RuntimeError) as e:
            print(f"  [ERROR] {e}")
            sys.exit(1)

        # Surchargez les chemins CLI si fournis
        if args.tsv:     params["tsv_path"]    = args.tsv
        if args.design:  params["design_path"] = args.design
        if args.out_dir: params["out_dir"]     = args.out_dir
        if args.batch_column: params["batch_column"] = args.batch_column
        if getattr(args, "qc_only", False): params["qc_only"] = True
        if getattr(args, "pathfinder", False): params["make_pathfinder"] = True

        # Les flags optionnels liés à la présence de fichiers/modules
        # peuvent ne pas être dans la config — on les complète
        if "use_deqms" not in params:
            params["use_deqms"] = False
        if "make_wgcna" not in params:
            params["make_wgcna"] = False
        if "make_dashboard" not in params:
            params["make_dashboard"] = dash_available
        if "go_organism" not in params:
            params["go_organism"] = None
        if "run_gsea" not in params:
            params["run_gsea"] = False
        if "batch_column" not in params:
            params["batch_column"] = None

        print_config_summary(params)
        return params

    # ── B. Proposition de rechargement last_config ─────────────────────────────
    out_dir = args.out_dir or _DEFAULTS["out_dir"]
    reloaded = maybe_reload_last_config(out_dir)
    if reloaded is not None:
        # Surchargez les chemins CLI si fournis même en cas de rechargement
        if args.tsv:     reloaded["tsv_path"]    = args.tsv
        if args.design:  reloaded["design_path"] = args.design
        if args.out_dir: reloaded["out_dir"]      = args.out_dir
        if args.batch_column: reloaded["batch_column"] = args.batch_column
        if getattr(args, "qc_only", False): reloaded["qc_only"] = True
        if getattr(args, "pathfinder", False): reloaded["make_pathfinder"] = True
        return reloaded

    # ── C. Questions interactives ──────────────────────────────────────────────
    # ask_params_fn() retourne uniquement les clés stats. On fusionne _DEFAULTS
    # en premier pour garantir tsv_path, design_path, pr_path, out_dir, etc.
    # Les réponses interactives ont priorité via le second spread.
    params = {**_DEFAULTS, **ask_params_fn()}

    # Surchargez les chemins CLI si fournis (priorité maximale)
    if args.tsv:     params["tsv_path"]    = args.tsv
    if args.design:  params["design_path"] = args.design
    if args.out_dir: params["out_dir"]     = args.out_dir
    if args.batch_column: params["batch_column"] = args.batch_column
    if getattr(args, "qc_only", False): params["qc_only"] = True

    # GO — toutes les clés renvoyées par ask_go_params() sont reportées dans
    # params (sinon le choix STRING serait perdu et last_config.yaml aussi).
    params["go_organism"] = None
    params["run_gsea"] = False
    if go_available:
        go_result = ask_go_params_fn()
        if go_result:
            params["go_organism"] = go_result.get("organism")
            params["run_gsea"] = bool(go_result.get("run_gsea", False))
            if go_result.get("gsea_organism"):
                params["gsea_organism"] = go_result["gsea_organism"]
            params["go_backend"] = go_result.get("backend", "gprofiler")
            params["go_species_taxid"] = go_result.get("species_taxid")
            params["string_caller_identity"] = (go_result.get("caller_identity")
                                                or _DEFAULTS["string_caller_identity"])
            params["enrichment_background"] = go_result.get("enrichment_background",
                                                            "quantified")
            params["string_background"] = go_result.get("string_background")

    # WGCNA
    rep = input("\n  Run the WGCNA co-expression analysis? "
                "(longest step) (y/N) -> ").strip().lower()
    params["make_wgcna"] = rep in ("o", "oui", "y", "yes")

    # Dashboard
    params["make_dashboard"] = False
    if dash_available:
        rep = input("\n  Generate the interactive HTML dashboard at the end? (Y/n) -> "
                    ).strip().lower()
        params["make_dashboard"] = rep in ("", "o", "oui", "y", "yes")

    # Pathfinder — question posée seulement si un clone est trouvé
    if getattr(args, "pathfinder", False):
        params["make_pathfinder"] = True
    else:
        from pathfinder_bridge import locate_pathfinder
        params["make_pathfinder"] = False
        _pf = locate_pathfinder(params)
        if _pf:
            rep = input(f"\n  Run the Pathfinder multi-contrast synthesis at the end?\n"
                        f"  ({_pf}) (y/N) -> ").strip().lower()
            params["make_pathfinder"] = rep in ("o", "oui", "y", "yes")

    # DEqMS
    params["use_deqms"] = False
    if os.path.exists(pr_path):
        rep = input(
            f"\n  pr_matrix detected ({pr_path}). ALSO compute DEqMS "
            f"(peptide-count weighting) alongside limma? (Y/n) -> "
        ).strip().lower()
        params["use_deqms"] = rep in ("", "o", "oui", "y", "yes")
    else:
        print(f"\n  [INFO] {pr_path} not found — DEqMS unavailable, limma only.")

    # ── D. Sauvegarde optionnelle --save-config ────────────────────────────────
    if args.save_config is not None:
        if args.save_config == "__AUTO__":
            ts   = datetime.now().strftime("%Y%m%d_%H%M")
            name = f"config_{ts}.yaml"
            save_path = os.path.join(params["out_dir"], name)
        else:
            save_path = args.save_config
        save_config(params, save_path,
                    comment="Généré par --save-config")

    # ── E. Sauvegarde automatique last_config (toujours) ──────────────────────
    _save_last_config(params)

    return params


def _save_last_config(params: dict) -> None:
    """Sauvegarde silencieuse de last_config.yaml dans out_dir."""
    out_dir = params.get("out_dir", _DEFAULTS["out_dir"])
    os.makedirs(out_dir, exist_ok=True)
    ext  = ".yaml" if _YAML_OK else ".json"
    path = os.path.join(out_dir, f"last_config{ext}")
    try:
        save_config(params, path,
                    comment="Sauvegarde automatique — dernier run")
    except Exception as e:
        # Non bloquant : la sauvegarde last_config ne doit jamais planter le pipeline
        print(f"  [WARN] Could not save last_config ({e})")


# ── Exemple de fichier config (affiché avec --help ou --example) ───────────────

CONFIG_EXAMPLE = """\
# Pipeline Protéomique — Exemple de configuration YAML
# Utilisation : python deimos.py --config config_example.yaml

# ── Seuils statistiques ──────────────────────────────────────────────────────
volcano_use_padj:    false        # true = FDR (p.adj), false = p-value brute
volcano_p_thresh:    0.05
volcano_ratio_min:   1.5          # ratio linéaire (ex: 1.5 = 50% de changement)
volcano_y_axis:      pvalue       # axe Y : pvalue (p brute, défaut) | padj (statistique du seuil)
pca_n_drivers:       20           # protéines motrices annotées sur le loading plot (PC1±, PC2±)

anova_use_padj:      false
anova_p_thresh:      0.05

n_heatmap_clusters:  3

# ── Options d'analyse ────────────────────────────────────────────────────────
n_iter_robustness:   100          # 0 = désactivé
fdr_global:          false        # true = correction BH sur toutes les p-values
contrasts:           __auto__     # 'all', ou liste de motifs, ex :
                                  #   - "Live_{s}_vs_Heat_killed_{s}"   ({s} = même souche des deux côtés)
                                  #   - "Live_*_vs_Live_*"              (* = libre)
impute_method:       auto         # 'auto' (choix par le diagnostic), 'qrilc', 'mixed' ou 'mixed_legacy'
primary_statistic:   dpc          # 'dpc' (sans imputation, précurseurs) ou 'imputation'
seed:                42           # graine de l'imputation (résultats reproductibles)

# ── Modules optionnels ───────────────────────────────────────────────────────
go_organism:         null          # ex: 'bnapus', 'hsapiens', null = désactivé
go_backend:          gprofiler     # 'gprofiler' ou 'string' (bactéries / non-modèles)
go_species_taxid:    auto          # si go_backend = string : auto, ou taxid de SOUCHE (ex: 511145 = E. coli K-12 MG1655)
enrichment_background: quantified  # univers de l'ORA : 'quantified' (protéines testées) ou 'genome'
string_background:   null          # null = suit enrichment_background ; 'genome' ou 'quantified' pour forcer STRING
export_matrices:     true          # dossier matrices/ : log2 avec NA, imputée, DPC (Mfuzz, MOFA+/MEFISTO, multi-omique)
run_gsea:            false         # GSEA pré-classée (gseapy), complément de l'ORA
gsea_organism:       human         # human (Enrichr) | mouse (MSigDB souris : MH, M2 Reactome/WikiPathways, M5 GO)
gsea_gene_sets:      null          # null = défaut de l'organisme ; ou liste : fichiers .gmt locaux, "msigdb:m5.go.bp", noms Enrichr
gsea_msigdb_version: null          # null = 2025.1.Hs / 2025.1.Mm
gsea_rank_p:         pvalue        # classement -log10(p brute) x signe(LFC) ; 'volcano' = ancienne règle
gsea_fdr:            0.25
gsea_permutations:   1000
make_wgcna:          false
make_dashboard:      true
dpc_sensitivity:     true          # analyse différentielle sans imputation (ajoutée)
differential_detection: true       # protéines on/off : test de détection (ajouté)
dpc_level:           auto          # auto (précurseurs si pr_matrix), precursor ou protein
make_pathfinder:     false         # true = synthèse Pathfinder en fin de run (--pathfinder)
pathfinder_path:     null          # clone Pathfinder ; null = $PATHFINDER_HOME puis ../Pathfinder
use_deqms:           false

# ── Chemins (optionnel — surchargeables aussi via CLI) ───────────────────────
tsv_path:            report.pg_matrix.tsv
design_path:         ExperimentalDesign.csv
pr_path:             report.pr_matrix.tsv
out_dir:             proteomics_output
"""
