# ==============================================================================
# deimos.py — Orchestrateur principal
# Deimos — DIA Expression Integrated Multi-Omics Suite
# ==============================================================================
# Dépendances : pandas, numpy, scipy, statsmodels, sklearn, umap-learn,
#               matplotlib, seaborn, openpyxl, limma_ebayes (local)
# ==============================================================================

import os
import sys
import warnings
import re
import time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import to_hex
import seaborn as sns
from itertools import combinations
from math import ceil
from scipy import stats
from scipy.stats import norm, pearsonr
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from scipy.spatial.distance import squareform
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import umap
from openpyxl import load_workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Font, PatternFill, Alignment
import openpyxl

warnings.filterwarnings("ignore")

# adjustText émet un message FancyArrowPatch via logging (pas un warning Python) ;
# on coupe son logger pour garder une console propre. Sans effet sur le rendu.
import logging
logging.getLogger("adjustText").setLevel(logging.ERROR)

# Module eBayes local
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from limma_ebayes import (lm_fit, contrasts_fit, ebayes, top_table,
                           spectra_count_ebayes,
                           make_all_contrasts, make_design_matrix,
                           make_paired_design_matrix, detect_control_condition)

# Module GO/gProfiler optionnel (import protégé : si absent, le pipeline tourne)
try:
    from go_enrichment import (ask_go_params, run_go_enrichment,
                               export_go_sheets,
                               run_go_enrichment_clusters,
                               export_go_cluster_sheets,
                               diagnose_gprofiler_coverage,
                               plan_string_mapping,
                               download_string_proteome,
                               download_uniprot_fasta)
    _GO_AVAILABLE = True
except ImportError:
    _GO_AVAILABLE = False

# Module dashboard optionnel (import protégé)
try:
    from dashboard_integration import run_dashboard
    _DASHBOARD_AVAILABLE = True
except ImportError:
    _DASHBOARD_AVAILABLE = False

# Module Perseverance optionnel (recherche d'orthologues, import protégé)
try:
    from rbh import compute_rbh
    from deimos_to_perseverance import (export_query_fasta, detect_fasta_roles,
                                        build_ortholog_map)
    _PERSEVERANCE_AVAILABLE = True
except ImportError:
    _PERSEVERANCE_AVAILABLE = False
try:   # isolé : une ancienne copie sans ce helper ne doit pas désactiver Perseverance
    from deimos_to_perseverance import _fasta_accessions
except ImportError:
    _fasta_accessions = None

# Module config YAML réutilisable
from config import resolve_config

# Contrat Deimos -> Pathfinder (onglet _manifest) et lancement de Pathfinder
# Sensibilité aux valeurs manquantes (DPC) : analyses AJOUTÉES, non bloquantes
try:
    from dpc_sensitivity import run_missingness_sensitivity, estimate_dpc_intercept
    _DPC_AVAILABLE = True
except ImportError:
    _DPC_AVAILABLE = False

from pathfinder_bridge import (write_manifest, run_pathfinder_step,
                               locate_pathfinder, pathfinder_version)


# ==============================================================================
# 0. PARAMÈTRES INTERACTIFS
# ==============================================================================

def ask_params() -> dict:
    """
    Asks the user 2 questions at launch and returns the thresholds.
    The volcano thresholds also govern the robustness score and the facet volcano.
    """
    def _ask_choice(prompt, valid):
        """Pose une question à choix jusqu'à réponse valide.
        Tolère une (ou des) première(s) ligne(s) vide(s) sans réafficher le
        prompt en double (buffer d'entrée résiduel fréquent sous PowerShell) :
        une entrée vide fait simplement re-lire l'entrée, pas ré-imprimer.
        """
        sys.stdout.write(prompt)
        sys.stdout.flush()
        while True:
            ans = input().strip()
            if ans in valid:
                return ans
            if ans == "":
                # ligne vide parasite : on re-lit sans réafficher le prompt
                continue
            # réponse non vide mais invalide : on réaffiche le prompt
            sys.stdout.write(prompt)
            sys.stdout.flush()

    def _ask_float(prompt):
        while True:
            raw = input(prompt).strip()
            if raw == "":
                continue
            try:
                return float(raw)
            except ValueError:
                print("  Invalid input, try again.")

    print("\n" + "="*60)
    print("  PROTEOMICS PIPELINE — Statistical threshold configuration")
    print("="*60)

    # --- Question 1: Volcanos + Robustness ---
    print("\n[1/2] Individual volcanos, facet volcano & robustness score")
    v_type = _ask_choice("  Use (1) raw p.value  or  (2) p.adj / FDR [BH] ? -> ",
                         ("1", "2"))

    v_val = _ask_float("  Threshold value (e.g. 0.05, 0.01) -> ")
    v_ratio = _ask_float("  Minimum ratio (e.g. 1.5, 2.0) -> ")

    # --- Question 2: ANOVA / Heatmap ---
    print("\n[2/2] ANOVA & heatmaps (significant protein selection)")
    a_type = _ask_choice("  Use (1) raw p.value  or  (2) p.adj / FDR [BH] ? -> ",
                         ("1", "2"))

    a_val = _ask_float("  Threshold value (e.g. 0.05, 0.01) -> ")

    # Number of protein clusters (k-means) for the clustered heatmap
    n_clusters = None
    while n_clusters is None:
        raw = input("  Number of protein clusters for the heatmap "
                    "[default 3] -> ").strip()
        if raw == "":
            n_clusters = 3
        else:
            try:
                n_clusters = int(raw)
                if n_clusters < 2:
                    print("  At least 2 clusters.")
                    n_clusters = None
            except ValueError:
                print("  Invalid input (integer expected), try again.")

    # Robustness score: optional + number of iterations
    n_iter_rob = None
    while n_iter_rob is None:
        raw = input("  Robustness score: number of iterations "
                    "[default 100, 0 = disabled] -> ").strip()
        if raw == "":
            n_iter_rob = 100
        else:
            try:
                n_iter_rob = int(raw)
                if n_iter_rob < 0:
                    print("  Enter an integer >= 0 (0 = disabled).")
                    n_iter_rob = None
            except ValueError:
                print("  Invalid input (integer expected), try again.")

    # FDR correction: per-contrast (default) or global (whole study)
    fdr_global = None
    while fdr_global is None:
        raw = input("  FDR correction: [1] per contrast (default) "
                    "or [2] global (whole study) -> ").strip()
        if raw in ("", "1"):
            fdr_global = False
        elif raw == "2":
            fdr_global = True
        else:
            print("  Answer: 1 or 2.")

    # Missing-value imputation method
    imp_method = None
    while imp_method is None:
        print("\n  Missing-value imputation:")
        print("    [1] Auto (default) — chosen by the missingness diagnostic:")
        print("        Mixed if >= 20% of missing values are MAR, QRILC otherwise")
        print("    [2] QRILC (pure MNAR — every missing value imputed low)")
        print("    [3] Mixed (QRILC for proteins absent from a whole condition, kNN otherwise)")
        raw = input("  -> ").strip()
        if raw in ("", "1"):
            imp_method = "auto"
        elif raw == "2":
            imp_method = "qrilc"
        elif raw == "3":
            imp_method = "mixed"
        else:
            print("  Answer: 1, 2 or 3.")

    # Statistique principale
    prim = None
    while prim is None:
        print("\n  Primary differential statistic:")
        print("    [1] Imputation-free DPC (default) — limpa method, from the precursors")
        print("        (pr_matrix); the imputed analysis is kept as secondary")
        print("    [2] Imputation + limma/DEqMS (behaviour before 10/2026)")
        raw = input("  -> ").strip()
        if raw in ("", "1"):
            prim = "dpc"
        elif raw == "2":
            prim = "imputation"
        else:
            print("  Answer: 1 or 2.")

    params = {
        "primary_statistic": prim,
        "volcano_use_padj":  v_type == "2",
        "volcano_p_thresh":  v_val,
        "volcano_lfc_min":   np.log2(v_ratio),
        "volcano_ratio_min": v_ratio,
        "anova_use_padj":    a_type == "2",
        "anova_p_thresh":    a_val,
        "n_heatmap_clusters": n_clusters,
        "n_iter_robustness": n_iter_rob,
        "fdr_global": fdr_global,
        "impute_method": imp_method,
        "seed": 42,
    }

    print("\n  [OK] Parameters saved:")
    print(f"     Volcanos/Robustness -> {'p.adj' if params['volcano_use_padj'] else 'p.value'} < {v_val}  |  ratio >= {v_ratio} (log2FC >= {params['volcano_lfc_min']:.3f})")
    print(f"     ANOVA/Heatmap       -> {'p.adj' if params['anova_use_padj'] else 'p.value'} < {a_val}")
    print(f"     Heatmap clusters    -> {n_clusters}")
    print(f"     Robustness          -> {'disabled' if n_iter_rob == 0 else str(n_iter_rob) + ' iterations'}")
    _fdr_txt = "global (whole study)" if fdr_global else "per contrast"
    print(f"     FDR correction      -> {_fdr_txt}")
    print(f"     Primary statistic   -> {dict(dpc='Imputation-free DPC (limpa method)', imputation='Imputation + limma/DEqMS')[prim]}")
    print(f"     Imputation          -> {dict(auto='Auto (diagnostic-driven)', qrilc='QRILC (MNAR)', mixed='Mixed (MNAR+MAR)')[imp_method]}")
    print()
    return params


# ==============================================================================
# 1. DIAGNOSTIC — Vérification cohérence labels TSV ↔ Design
# ==============================================================================

def _extract_labels_from_tsv(tsv_path: str) -> tuple[list[str], list[str]]:
    """
    Lit uniquement la ligne d'en-tête du TSV et extrait :
    - raw_cols  : noms de colonnes bruts (après la 6ème)
    - clean_labels : labels nettoyés par le même regex que load_data
    """
    with open(tsv_path, "r", encoding="utf-8") as f:
        header = f.readline().rstrip("\n").split("\t")

    raw_cols = header[6:]
    clean_labels = []
    for c in raw_cols:
        m = re.search(r"(Sple-[^_]+)_", c)
        clean_labels.append(m.group(1) if m else c)

    return raw_cols, clean_labels


def diagnose_labels(tsv_path: str, design_path: str) -> bool:
    """
    Vérifie la cohérence entre les labels du TSV et ceux du design.
    Affiche un rapport détaillé et retourne True si tout est OK.

    Checks :
    1. Fichiers lisibles
    2. Colonnes obligatoires dans le design (label, condition, replicate)
    3. Labels design présents dans le TSV
    4. Labels TSV non couverts par le design
    5. Doublons dans chaque côté
    6. Suggestion de correspondances proches (distance de Levenshtein légère)
    """
    print("\n" + "="*60)
    print("  DIAGNOSTIC — Label check")
    print("="*60)

    errors   = []
    warnings = []
    ok       = True

    # --- 1. File readability ---
    for path, label in [(tsv_path, "pg_matrix.tsv"), (design_path, "ExperimentalDesign.csv")]:
        if not os.path.exists(path):
            errors.append(f"File not found: {path}")
            ok = False

    if not ok:
        for e in errors:
            print(f"  [ERROR] {e}")
        print("\n  [STOP] Cannot continue without the input files.")
        return False

    # --- 2. Required columns in the design ---
    design = pd.read_csv(design_path, sep=";")
    required_cols = {"label", "condition", "replicate"}
    missing_cols  = required_cols - set(design.columns)
    if missing_cols:
        errors.append(f"Missing columns in the design: {missing_cols}")
        ok = False

    # --- 3. Extract TSV labels ---
    try:
        raw_cols, tsv_labels = _extract_labels_from_tsv(tsv_path)
    except Exception as e:
        errors.append(f"Unable to read the TSV header: {e}")
        ok = False
        for e in errors:
            print(f"  [ERROR] {e}")
        return False

    design_labels = design["label"].astype(str).tolist() if "label" in design.columns else []

    # --- 4. Duplicates ---
    tsv_dupes    = [l for l in set(tsv_labels)    if tsv_labels.count(l)    > 1]
    design_dupes = [l for l in set(design_labels) if design_labels.count(l) > 1]
    if tsv_dupes:
        warnings.append(f"Duplicate labels in the TSV after cleaning: {tsv_dupes}")
    if design_dupes:
        errors.append(f"Duplicate labels in the design: {design_dupes}")
        ok = False

    # --- 5. Matching ---
    set_tsv    = set(tsv_labels)
    set_design = set(design_labels)

    matched        = set_tsv & set_design
    only_in_design = set_design - set_tsv   # in design but absent from TSV
    only_in_tsv    = set_tsv - set_design   # in TSV but absent from design

    # --- Report ---
    print(f"\n  TSV       : {len(tsv_labels)} columns detected ({len(set_tsv)} unique)")
    print(f"  Design    : {len(design_labels)} rows ({len(set_design)} unique)")
    print(f"  [OK] Matched: {len(matched)}")

    if only_in_design:
        ok = False
        print(f"\n  [ERROR] In the design but MISSING from the TSV ({len(only_in_design)}):")
        for lbl in sorted(only_in_design):
            suggestion = _closest_label(lbl, tsv_labels)
            hint = f"  -> looks like: '{suggestion}'" if suggestion else ""
            print(f"     - '{lbl}'{hint}")
        errors.append(f"{len(only_in_design)} design label(s) not found in the TSV")

    if only_in_tsv:
        print(f"\n  [WARN] In the TSV but MISSING from the design ({len(only_in_tsv)}):")
        for lbl in sorted(only_in_tsv):
            print(f"     - '{lbl}'")
        warnings.append(f"{len(only_in_tsv)} TSV column(s) not covered by the design (will be ignored)")

    # --- Raw columns for failed labels (debugging aid) ---
    if only_in_design:
        print(f"\n  [INFO] Raw column names in the TSV (before regex cleaning):")
        for raw, clean in zip(raw_cols, tsv_labels):
            marker = "[!] " if clean in only_in_design else "   "
            print(f"     {marker}raw: '{raw}'  ->  cleaned: '{clean}'")

    # --- Warnings ---
    if warnings:
        print()
        for w in warnings:
            print(f"  [WARN] {w}")

    # --- Conclusion ---
    print()
    if ok and not errors:
        print(f"  [OK] Labels consistent — {len(matched)} samples ready for analysis.\n")
    else:
        print("  [STOP] Errors detected — fix the design or the column names before re-running.\n")
        print("  [TIP] Hints:")
        print("     - The label in the design must match the 'Sple-XXX' part")
        print("       extracted from the raw TSV column name.")
        print("     - Example: TSV column '...250630-Sple-135A_Slot1-28...'")
        print("                -> expected design label: 'Sple-135A'")
        print("     - Also check the design separator (must be ';')\n")

    return ok and not errors


def _closest_label(target: str, candidates: list[str], max_dist: int = 4) -> str:
    """
    Retourne le candidat le plus proche par distance de Levenshtein simple.
    Retourne None si la distance minimale dépasse max_dist.
    """
    def levenshtein(a, b):
        if len(a) < len(b):
            return levenshtein(b, a)
        if not b:
            return len(a)
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a):
            curr = [i + 1]
            for j, cb in enumerate(b):
                curr.append(min(prev[j + 1] + 1,
                                curr[j] + 1,
                                prev[j] + (ca != cb)))
            prev = curr
        return prev[-1]

    if not candidates:
        return None
    dists = [(levenshtein(target, c), c) for c in candidates]
    best_dist, best_cand = min(dists)
    return best_cand if best_dist <= max_dist else None


# ==============================================================================
# 1. LECTURE ET NETTOYAGE DES DONNÉES
# ==============================================================================

def load_data(tsv_path: str, design_path: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Lit le pg_matrix.tsv et le design expérimental."""
    print("[IO] Reading raw files...")

    tsv = pd.read_csv(tsv_path, sep="\t")

    # Nettoyage noms de colonnes (équivalent sub R)
    new_cols = []
    for c in tsv.columns:
        m = re.search(r"(Sple-[^_]+)_", c)
        new_cols.append(m.group(1) if m else c)
    tsv.columns = new_cols

    # Identifier les colonnes LFQ (colonnes numériques après col 6)
    meta_cols = list(tsv.columns[:6])
    lfq_cols  = list(tsv.columns[6:])
    lfq_renamed = [f"LFQ.intensity.{c}" for c in lfq_cols]
    rename_map = dict(zip(lfq_cols, lfq_renamed))
    tsv = tsv.rename(columns=rename_map)

    # Colonnes ID et name
    tsv["ID"]   = tsv["Protein.Names"].astype(str).str.split(";").str[0]
    tsv["name"] = tsv["Protein.Group"].astype(str).str.split(";").str[0]

    # Retirer contaminants cRAP
    mask_crap = (tsv["Protein.Group"].astype(str).str.startswith("cRAP") |
                 tsv["Protein.Names"].astype(str).str.startswith("cRAP"))
    tsv = tsv[~mask_crap].reset_index(drop=True)

    # Design
    design = pd.read_csv(design_path, sep=";")

    print(f"  -> {len(tsv)} proteins loaded | {len(design)} samples in the design")
    return tsv, design


def detect_species_tags(tsv: pd.DataFrame, col: str = "Protein.Names") -> pd.Series:
    """
    Extrait un tag d'organisme depuis le suffixe '_TAG' de Protein.Names
    (convention type UniProt : GENE_SPECIESTAG, ex. '..._MAGGI', '..._OSHVF').
    Générique : ne présuppose aucune liste fixe d'organismes.

    Retourne une Series alignée sur l'index de tsv, NaN si aucun suffixe
    reconnu (protéine sans tag exploitable — ni perdue ni mal classée).
    """
    first_entry = tsv[col].astype(str).str.split(";").str[0]
    tags = first_entry.str.extract(r"_([A-Za-z0-9]{3,10})$")[0]
    # Contaminants (cRAP-, CON__, contam_...) : leurs suffixes _HUMAN/_BOVIN
    # (kératines, trypsine...) ne sont pas des organismes de l'étude —
    # sinon la question du split multi-espèces est posée à tort.
    pg = (tsv["Protein.Group"].astype(str) if "Protein.Group" in tsv.columns
          else first_entry)
    contam = (pg.str.lower().str.startswith(("crap", "con_", "contam"))
              | first_entry.str.lower().str.startswith(("crap", "con_", "contam")))
    tags[contam] = np.nan
    return tags


def ask_species_split(tag_counts: pd.Series) -> bool:
    """
    Signale la présence de plusieurs organismes dans Protein.Names et demande
    s'il faut lancer une analyse DEP complète et indépendante par organisme
    (recommandé : FDR, imputation et normalisation propres à chaque compartiment
    plutôt que mélangés dans une seule matrice hôte+pathogène).
    """
    print("\n" + "="*60)
    print("  Plusieurs organismes détectés dans Protein.Names :")
    for tag, n in tag_counts.items():
        print(f"    _{tag} : {n} protein group(s)")
    print("="*60)
    while True:
        raw = input("  Run a SEPARATE analysis per organism? [Y/n] -> ").strip().lower()
        if raw in ("", "y", "yes", "o", "oui"):
            return True
        if raw in ("n", "no", "non"):
            return False
        print("  Answer: Y or N.")


def ask_run_perseverance(coverage_diag: "dict | None" = None) -> bool:
    """Demande si Perseverance (recherche d'orthologues par RBH) doit être
    lancé après les analyses statistiques, avant le GO. Surchargeable en
    non-interactif via params['run_perseverance']=True/False.

    coverage_diag : résultat de diagnose_gprofiler_coverage(), si go_organism
                   était configuré — informe la question sans décider à la
                   place de l'utilisateur (le défaut proposé s'ajuste, mais
                   la question reste posée dans tous les cas)."""
    print("\n" + "="*60)
    print("  Perseverance : recherche d'orthologues par RBH (DIAMOND)")
    print("  Utile si l'espèce n'est pas/mal couverte par gProfiler —")
    print("  traduit les protéines significatives vers une espèce de")
    print("  référence bien annotée avant l'enrichissement GO.")
    if coverage_diag and coverage_diag.get("available"):
        print(f"  Diagnostic : {coverage_diag['recommendation']}")
    print("="*60)
    default_yes = bool(coverage_diag and coverage_diag.get("reliable") is False)
    prompt = "  Lancer Perseverance avant le GO ? [Y/n] -> " if default_yes \
        else "  Lancer Perseverance avant le GO ? [y/N] -> "
    while True:
        raw = input(prompt).strip().lower()
        if raw == "":
            return default_yes
        if raw in ("y", "yes", "o", "oui"):
            return True
        if raw in ("n", "no", "non"):
            return False
        print("  Answer: Y or N.")


def _scan_fasta_files(directory: str) -> list:
    if not directory or not os.path.isdir(directory):
        return []
    exts = (".fasta", ".fa", ".faa")
    return sorted(os.path.join(directory, f) for f in os.listdir(directory)
                 if f.lower().endswith(exts))


def ask_fasta_paths(candidates: list) -> "tuple[str, str]":
    """Demande les deux chemins FASTA quand l'auto-scan ne trouve pas
    exactement 2 fichiers, ou si l'utilisateur veut les préciser."""
    if candidates:
        print(f"  Fichiers FASTA trouvés dans le dossier scanné : {candidates}")
    a = input("  Chemin du 1er FASTA (recherche OU référence, peu importe l'ordre) -> ").strip()
    b = input("  Chemin du 2e FASTA -> ").strip()
    return a, b


def ask_reference_organism() -> str:
    print("  Code organisme gProfiler pour l'espèce de RÉFÉRENCE (celle du "
          "2e FASTA, bien annotée) — ex: 'athaliana', 'hsapiens', 'mmusculus'.")
    return input("  Organisme de référence -> ").strip()


def run_perseverance_step(df_results: pd.DataFrame, params: dict, out_dir: str
                          ) -> "tuple[pd.DataFrame | None, dict | None]":
    """
    Orchestration complète de l'étape Perseverance, insérée après toutes les
    analyses statistiques et avant le GO :
      1. Demande (ou lit en config) si Perseverance doit tourner.
      2. Localise les 2 FASTA (scan auto d'un dossier, ou chemins explicites).
      3. Détecte automatiquement quel FASTA correspond à CE run Deimos
         (recouvrement avec Protein.Group) et lequel est la référence.
      4. RBH (DIAMOND) — recherche d'orthologues uniquement, pas de transfert
         de GO (Perseverance ne sert ici qu'à faire le blastp réciproque).
      5. Construit la table de correspondance protéine/orthologue (à
         exporter) et le dict de traduction pour le GO.

    Returns
    -------
    (correspondence_df, go_override) — (None, None) si désactivé/échec.
    go_override : dict prêt à fusionner dans go_params
                 ({"organism": ..., "ortholog_map": ..., "run_gsea": ...})
    """
    if not _PERSEVERANCE_AVAILABLE:
        return None, None

    cfg_run = params.get("run_perseverance", "__auto__")
    if cfg_run is False:
        return None, None
    elif cfg_run == "__auto__":
        coverage_diag = None
        _org = params.get("go_organism")
        if _org and _GO_AVAILABLE:
            print(f"\n[DIAG] Vérification de la couverture gProfiler pour "
                  f"'{_org}' avant de proposer Perseverance...")
            id_col = "name" if "name" in df_results.columns else df_results.columns[0]
            coverage_diag = diagnose_gprofiler_coverage(
                df_results[id_col].tolist(), _org)
            if coverage_diag.get("available"):
                print(f"  [DIAG] {coverage_diag['recommendation']}")
            else:
                print(f"  [DIAG] {coverage_diag['recommendation']}")
        if not ask_run_perseverance(coverage_diag):
            return None, None
    elif not cfg_run:
        return None, None
    else:
        print(f"\n[CONFIG] run_perseverance={bool(cfg_run)} (from config)")
        _org = params.get("go_organism")
        if _org and _GO_AVAILABLE and bool(cfg_run) is False:
            # Purement informatif : la decision est deja fixee par la config,
            # mais utile de savoir a posteriori si gProfiler direct etait
            # effectivement une option raisonnable.
            coverage_diag = diagnose_gprofiler_coverage(
                df_results[df_results.columns[0]].tolist(), _org)
            if coverage_diag.get("available"):
                print(f"  [DIAG, info] {coverage_diag['recommendation']}")

    print("\n[STEP] Perseverance — recherche d'orthologues (RBH/DIAMOND)...")

    fasta_a = params.get("perseverance_fasta_a")
    fasta_b = params.get("perseverance_fasta_b")
    if not (fasta_a and fasta_b):
        scan_dir = params.get("perseverance_fasta_dir") or os.path.dirname(
            os.path.abspath(params.get("tsv_path", ".")))
        candidates = _scan_fasta_files(scan_dir)
        if len(candidates) == 2:
            fasta_a, fasta_b = candidates
            print(f"  [AUTO] 2 FASTA trouvés dans {scan_dir} : "
                  f"{[os.path.basename(c) for c in candidates]}")
        else:
            fasta_a, fasta_b = ask_fasta_paths(candidates)

    if not (os.path.isfile(fasta_a) and os.path.isfile(fasta_b)):
        print(f"  [WARN] FASTA introuvable(s) ({fasta_a}, {fasta_b}) — "
              f"Perseverance ignoré.")
        return None, None

    id_col = "name" if "name" in df_results.columns else df_results.columns[0]
    protein_groups = df_results[id_col].astype(str).tolist()

    roles = detect_fasta_roles(fasta_a, fasta_b, protein_groups)
    if roles["ambiguous"]:
        print("  [WARN] Rôles ambigus — confirmation nécessaire.")
        confirm = input(
            f"  FASTA de recherche proposé : {roles['search_fasta']} "
            f"(entrée pour valider, ou taper le bon chemin) -> ").strip()
        if confirm:
            roles["search_fasta"] = confirm
            roles["reference_fasta"] = (fasta_b if confirm == fasta_a else fasta_a)

    search_fasta = roles["search_fasta"]
    reference_fasta = roles["reference_fasta"]
    print(f"  [OK] FASTA de recherche (Protein.Group) : {os.path.basename(search_fasta)}")
    print(f"  [OK] FASTA de référence (orthologie)     : {os.path.basename(reference_fasta)}")

    persev_dir = os.path.join(out_dir, "perseverance")
    _makedirs(persev_dir)
    query_fasta = os.path.join(persev_dir, "query.fasta")
    mapping_tsv = os.path.join(persev_dir, "mapping.tsv")
    export_query_fasta(search_fasta, protein_groups, query_fasta, mapping_tsv)

    min_identity = params.get("perseverance_min_identity", 25.0)
    min_coverage = params.get("perseverance_min_coverage", 50.0)
    try:
        rbh_df = compute_rbh(query_fasta, reference_fasta, persev_dir,
                             min_identity=min_identity, min_coverage=min_coverage)
    except (RuntimeError, OSError) as e:   # OSError : DIAMOND introuvable (WinError 2)
        print(f"  [ERREUR] Perseverance/DIAMOND a échoué ({e}) — étape ignorée, "
              f"le pipeline continue sans orthologues.")
        return None, None

    if rbh_df.empty:
        print("  [WARN] Aucun orthologue trouvé (RBH vide) — vérifier les FASTA "
              "ou assouplir --min-identity/--min-coverage.")
        return None, None

    ortholog_map = build_ortholog_map(rbh_df, mapping_tsv)
    print(f"  [OK] {len(ortholog_map)} orthologue(s) identifié(s) sur "
          f"{len(protein_groups)} protéines du run.")

    reference_organism = params.get("perseverance_reference_organism")
    if not reference_organism:
        if not _GO_AVAILABLE:
            print("  [WARN] gprofiler-official non installé — impossible de "
                  "poursuivre en GO avec les orthologues. Table de correspondance "
                  "tout de même exportée.")
        else:
            reference_organism = ask_reference_organism()

    # Table de correspondance à exporter (une ligne par orthologue trouvé)
    mapping = pd.read_csv(mapping_tsv, sep="\t")
    corr = mapping.merge(rbh_df, left_on="accession", right_on="query_id", how="inner")
    corr["protein_id"] = corr["protein_group"].str.split(";").str[0]
    corr = corr.sort_values("bitscore", ascending=False).drop_duplicates("protein_id", keep="first")
    correspondence_df = corr[["protein_id", "reference_id", "pident", "coverage", "confidence"]].rename(
        columns={"reference_id": "ortholog_id"}).reset_index(drop=True)

    go_override = None
    if reference_organism:
        go_override = {"organism": reference_organism, "ortholog_map": ortholog_map,
                       "run_gsea": params.get("run_gsea", False)}

    return correspondence_df, go_override


def run_string_ortholog_step(df_results: pd.DataFrame, params: dict,
                             go_params: dict, out_dir: str
                             ) -> "tuple[pd.DataFrame | None, dict | None]":
    """
    Mode orthologie du backend STRING (décidé au pré-vol) : l'organisme est
    dans STRING mais pas les accessions du run (STRING indexe une autre
    souche). RBH DIAMOND entre les protéines quantifiées et le protéome
    STRING, dont les en-têtes sont les identifiants STRING : l'enrichissement
    STRING se fait directement dessus, puis les résultats sont retraduits
    vers les accessions du run (go_enrichment.string_maps_from_orthologs).

    Returns (correspondence_df, {"ortholog_map": ...}) ou (None, None).
    """
    if not _PERSEVERANCE_AVAILABLE:
        print("  [WARN] Modules rbh/deimos_to_perseverance absents — "
              "orthologie STRING impossible.")
        return None, None
    taxid = go_params.get("species_taxid")
    caller = go_params.get("caller_identity") or "Proteogen"
    print(f"\n[STEP] Orthologie vers STRING (RBH DIAMOND) — protéome {taxid}...")
    work = os.path.join(out_dir, "string_orthologs")
    _makedirs(work)
    data_dir = os.path.dirname(os.path.abspath(params.get("tsv_path", ".")))
    scan_dirs = list(dict.fromkeys([data_dir, os.getcwd()]))

    # 1. Protéome de référence STRING : config > dossier des données > téléchargement
    ref = params.get("string_reference_fasta")
    if ref and not os.path.isfile(ref):
        print(f"  [WARN] string_reference_fasta introuvable ({ref}).")
        ref = None
    if not ref:
        for d in scan_dirs:
            for f in _scan_fasta_files(d):
                with open(f, encoding="utf-8", errors="replace") as fh:
                    if fh.readline().startswith(f">{taxid}."):
                        ref = f
                        break
            if ref:
                print(f"  [AUTO] Protéome STRING trouvé : {ref}")
                break
    if not ref:
        ref = download_string_proteome(taxid, work, caller)
    if not ref:
        return None, None

    # 2. Séquences des protéines quantifiées : FASTA de recherche local si
    #    trouvé (>= 50 % des protéines), sinon téléchargement UniProt
    id_col = "name" if "name" in df_results.columns else df_results.columns[0]
    protein_groups = df_results[id_col].astype(str).tolist()
    wanted = {pg.split(";")[0].strip() for pg in protein_groups}
    best, best_ov = None, 0.0
    for d in (scan_dirs if _fasta_accessions is not None else []):
        for f in _scan_fasta_files(d):
            if os.path.abspath(f) == os.path.abspath(ref):
                continue
            try:
                ov = len(wanted & _fasta_accessions(f)) / max(len(wanted), 1)
            except Exception:
                continue
            if ov > best_ov:
                best, best_ov = f, ov
    if best and best_ov >= 0.5:
        search = best
        print(f"  [AUTO] FASTA de recherche : {os.path.basename(best)} "
              f"({best_ov:.0%} des protéines du run)")
    else:
        search = os.path.join(work, "uniprot_sequences.fasta")
        print("  [AUTO] FASTA de recherche non trouvé localement — séquences "
              "téléchargées depuis UniProt...")
        n = download_uniprot_fasta(sorted(wanted), search)
        print(f"  [OK] {n} séquences UniProt.")
        if n == 0:
            return None, None

    query_fasta = os.path.join(work, "query.fasta")
    mapping_tsv = os.path.join(work, "mapping.tsv")
    export_query_fasta(search, protein_groups, query_fasta, mapping_tsv)

    # 3. RBH
    try:
        rbh = compute_rbh(query_fasta, ref, work,
                          min_identity=params.get("perseverance_min_identity", 25.0),
                          min_coverage=params.get("perseverance_min_coverage", 50.0))
    except (RuntimeError, OSError) as e:
        print(f"  [ERREUR] DIAMOND a échoué ({e}) — GO STRING ignoré.")
        return None, None
    if rbh.empty:
        print("  [WARN] Aucun orthologue RBH trouvé.")
        return None, None

    ortholog_map = build_ortholog_map(rbh, mapping_tsv)
    n_high = int((rbh["confidence"] == "high").sum())
    print(f"  [OK] {len(ortholog_map)}/{len(protein_groups)} protéines avec un "
          f"orthologue STRING (identité médiane {rbh['pident'].median():.0f} %, "
          f"{n_high} paires de confiance haute).")

    mapping = pd.read_csv(mapping_tsv, sep="\t")
    corr = mapping.merge(rbh, left_on="accession", right_on="query_id", how="inner")
    corr["protein_id"] = corr["protein_group"].astype(str).str.split(";").str[0]
    corr = (corr.sort_values("bitscore", ascending=False)
            .drop_duplicates("protein_id", keep="first"))
    correspondence_df = corr[["protein_id", "reference_id", "pident", "coverage",
                              "confidence"]].rename(
        columns={"reference_id": "string_id"}).reset_index(drop=True)
    return correspondence_df, {"ortholog_map": ortholog_map}


def export_perseverance_sheet(wb, correspondence_df: pd.DataFrame, _write_df,
                              sheet_name: str = "Orthologues_Perseverance") -> None:
    """Ajoute l'onglet de correspondance protéine/orthologue au classeur Excel."""
    if correspondence_df is None or correspondence_df.empty:
        return
    ws = wb.create_sheet(sheet_name)
    _write_df(ws, correspondence_df)


def build_peptide_count_table(pr_path: str, protein_names: list,
                              count_level: str = "peptide",
                              sample_labels: "list | None" = None,
                              pg_path: "str | None" = None) -> "pd.Series | None":
    """
    Construit la count table DEqMS depuis le report.pr_matrix.tsv de DIA-NN.

    Pour chaque Protein.Group, compte le nombre de peptides (ou précurseurs)
    distincts quantifiés (valeur non-NA et > 0) dans CHAQUE run, puis prend le
    MINIMUM across runs — c'est le comptage utilisé par DEqMS pour modéliser la
    variance a priori (Zhu et al. 2020).

    Parameters
    ----------
    pr_path       : chemin vers report.pr_matrix.tsv
    protein_names : liste des 'name' (1er Protein.Group) des protéines filtrées,
                    pour aligner et ordonner le comptage
    count_level   : 'peptide' (Stripped.Sequence distinctes, défaut DEqMS LFQ)
                    ou 'precursor' (Precursor.Id distincts)
    sample_labels : labels des échantillons ANALYSÉS : le minimum est pris sur
                    leurs runs seulement (appariement par le pg_matrix, cf.
                    _precursor_columns). Sans cela, ou si l'appariement échoue,
                    tous les runs du fichier sont utilisés (comportement antérieur),
                    y compris ceux exclus du design.
    pg_path       : pg_matrix de la même recherche (appariement des runs)

    Returns
    -------
    pd.Series indexée par 'name', valeurs = min count across runs (≥ 1).
    None si le fichier est absent ou illisible.
    """
    if not pr_path or not os.path.exists(pr_path):
        print(f"  [INFO] pr_matrix not found ({pr_path}) — DEqMS disabled.")
        return None

    try:
        print(f"  [IO] Reading pr_matrix for peptide counting...")
        pr = pd.read_csv(pr_path, sep="\t")

        # Identifier la colonne de regroupement protéine
        if "Protein.Group" not in pr.columns:
            print("  [WARN] 'Protein.Group' column absent from pr_matrix — DEqMS disabled.")
            return None

        # Colonne identifiant le niveau de comptage
        if count_level == "precursor":
            id_col = "Precursor.Id"
        else:
            id_col = "Stripped.Sequence"
        if id_col not in pr.columns:
            # Repli : si Stripped.Sequence absente, tenter Precursor.Id puis Modified.Sequence
            for alt in ["Stripped.Sequence", "Precursor.Id", "Modified.Sequence"]:
                if alt in pr.columns:
                    id_col = alt
                    break
            else:
                print("  [WARN] No peptide/precursor column found — DEqMS disabled.")
                return None

        # Colonnes d'intensité = celles qui contiennent un label d'échantillon (Sple.)
        # On nettoie les noms comme pour le pg_matrix
        run_cols = [c for c in pr.columns if re.search(r"Sple-[^_]+", c)]
        if not run_cols:
            # Repli : colonnes numériques non-méta
            meta_known = {"Protein.Group","Protein.Ids","Protein.Names","Genes",
                          "First.Protein.Description","Proteotypic","Stripped.Sequence",
                          "Modified.Sequence","Precursor.Id","Precursor.Charge"}
            run_cols = [c for c in pr.columns if c not in meta_known
                        and pd.api.types.is_numeric_dtype(pr[c])]
        if not run_cols:
            print("  [WARN] No intensity column detected in pr_matrix — DEqMS disabled.")
            return None
        if sample_labels:
            num = [c for c in pr.columns if pd.api.types.is_numeric_dtype(pr[c])]
            found, _notes = _precursor_columns(num, list(sample_labels), pg_path)
            if all(str(l) in found for l in sample_labels):
                run_cols = [found[str(l)] for l in sample_labels]
            else:
                n_miss = sum(str(l) not in found for l in sample_labels)
                print(f"  [WARN] DEqMS count: {n_miss} analysed sample(s) not matched in "
                      f"the pr_matrix — minimum taken over all its runs.")

        # 'name' protéine = 1er Protein.Group
        pr["_name"] = pr["Protein.Group"].astype(str).str.split(";").str[0]

        # Pour chaque run : compter les peptides distincts quantifiés (>0, non-NA) par protéine
        # On construit une matrice protéine × run de comptages
        per_run_counts = {}
        for col in run_cols:
            detected = pr[[ "_name", id_col, col]].copy()
            detected = detected[detected[col].notna() & (detected[col] > 0)]
            # nombre de id_col distincts par protéine dans ce run
            cnt = detected.groupby("_name")[id_col].nunique()
            per_run_counts[col] = cnt

        count_mat = pd.DataFrame(per_run_counts).fillna(0)
        # MIN across runs (caractéristique DEqMS)
        min_count = count_mat.min(axis=1)

        # Aligner sur protein_names ; protéines sans peptide → NaN (exclues de DEqMS)
        aligned = pd.Series(min_count, index=min_count.index).reindex(protein_names)
        n_ok = aligned.notna().sum()
        n_missing = aligned.isna().sum()
        print(f"  -> {count_level} counting: {n_ok} matched proteins "
              f"(min across runs), {n_missing} sans comptage")
        if n_ok == 0:
            print("  [WARN] No protein matched between pg and pr_matrix — DEqMS disabled.")
            return None

        return aligned

    except Exception as e:
        print(f"  [WARN] pr_matrix read error ({type(e).__name__}: {str(e)[:80]}) — DEqMS disabled.")
        return None


# ==============================================================================
# 2. CONSTRUCTION DE LA MATRICE D'EXPRESSION (log2 LFQ)
# ==============================================================================

def build_expression_matrix(tsv: pd.DataFrame, design: pd.DataFrame
                             ) -> tuple[pd.DataFrame, pd.DataFrame, list]:
    """
    Retourne :
    - expr_log2 : DataFrame (n_proteins × n_samples) en log2, NaN pour 0
    - meta      : colonnes d'annotation protéines
    - lfq_cols  : noms de colonnes LFQ correspondant au design
    """
    lfq_cols = [c for c in tsv.columns if c.startswith("LFQ.intensity.")]

    # Alignement design → colonnes LFQ
    # IMPORTANT : appariement EXACT et non par sous-chaîne. Après nettoyage, les
    # colonnes sont nommées 'LFQ.intensity.<label>'. Un test 'lbl in c' provoque
    # des collisions de préfixe numérique : 'Sple-2' est une sous-chaîne de
    # 'Sple-28' / 'Sple-29', 'Sple-3' de 'Sple-30', etc. → un même run pouvait
    # être attribué à plusieurs labels (doublon de colonnes, perte d'échantillon).
    sample_map = {}
    unmatched = []
    for _, row in design.iterrows():
        lbl = str(row["label"])
        target = f"LFQ.intensity.{lbl}"
        if target in lfq_cols:
            sample_map[lbl] = target
        else:
            # Repli : match par segment de fin exact (col se terminant par '.<lbl>'),
            # tolère un préfixe LFQ différent sans retomber dans la sous-chaîne.
            cand = [c for c in lfq_cols
                    if c == lbl or c.endswith(f".{lbl}") or c.endswith(f"-{lbl}")]
            if len(cand) == 1:
                sample_map[lbl] = cand[0]
            elif len(cand) > 1:
                sample_map[lbl] = min(cand, key=len)
            else:
                unmatched.append(lbl)

    if unmatched:
        print(f"  [WARN] {len(unmatched)} design label(s) without a matching "
              f"LFQ column: {unmatched}")

    ordered_lfq = [sample_map[lbl] for lbl in design["label"] if lbl in sample_map]
    design_filt = design[design["label"].isin(sample_map.keys())].reset_index(drop=True)

    mat = tsv[ordered_lfq].copy().astype(float)
    mat.replace(0, np.nan, inplace=True)
    mat = np.log2(mat)

    meta_cols_wanted = ["name", "Protein.Group", "Protein.Names", "Genes",
                       "First.Protein.Description",
                       "N.Sequences", "N.Proteotypic.Sequences"]
    for c in ("N.Sequences", "N.Proteotypic.Sequences"):
        if c not in tsv.columns:
            print(f"  [WARN] Colonne '{c}' absente du pg_matrix.tsv (metadonnee "
                  f"optionnelle, ex: ancien export DIA-NN) — remplie a NaN.")
            tsv[c] = np.nan
    meta = tsv[meta_cols_wanted].copy()

    return mat, meta, design_filt, ordered_lfq


# ==============================================================================
# 3. CONTRÔLE QUALITÉ
# ==============================================================================

def plot_qc(mat: pd.DataFrame, meta: pd.DataFrame, design: pd.DataFrame,
            out_dir: str) -> list[str]:
    """Génère les figures QC et retourne la liste des fichiers."""
    files = []
    conditions = design["condition"].values

    # --- Fréquence de détection ---
    n_detected = mat.notna().sum(axis=1)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(range(len(n_detected)), sorted(n_detected.values, reverse=True),
           color="#3498DB", edgecolor="none")
    ax.set_xlabel("Proteins (sorted)")
    ax.set_ylabel("Number of samples detected")
    ax.set_title("Detection frequency")
    fig.tight_layout()
    f = os.path.join(out_dir, "qc_frequency.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)
    files.append(f)

    # --- Nb protéines par échantillon ---
    n_per_sample = mat.notna().sum(axis=0)
    fig, ax = plt.subplots(figsize=(max(8, len(n_per_sample) * 0.4), 4))
    colors_cond = _condition_colors(conditions)
    bars = ax.bar(range(len(n_per_sample)), n_per_sample.values,
                  color=[colors_cond[c] for c in conditions], edgecolor="none")
    ax.set_xticks(range(len(n_per_sample)))
    ax.set_xticklabels(design["label"].values, rotation=90, fontsize=7)
    ax.set_ylabel("Number of proteins detected")
    ax.set_title("Proteins detected per sample")
    handles = [mpatches.Patch(color=v, label=k) for k, v in colors_cond.items()]
    ax.legend(handles=handles, fontsize=7, loc="lower right")
    fig.tight_layout()
    f = os.path.join(out_dir, "qc_numbers.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)
    files.append(f)

    # --- Normalisation (boxplots) ---
    fig, ax = plt.subplots(figsize=(max(10, len(mat.columns) * 0.4), 5))
    data_box = [mat[c].dropna().values.flatten() for c in mat.columns]
    ax.boxplot(data_box, patch_artist=True,
               boxprops=dict(facecolor="#AED6F1"),
               medianprops=dict(color="red"),
               whiskerprops=dict(color="grey"),
               flierprops=dict(marker=".", markersize=2, alpha=0.3))
    ax.set_xticks(range(1, len(mat.columns) + 1))
    ax.set_xticklabels(design["label"].values, rotation=90, fontsize=7)
    ax.set_ylabel("log2 LFQ intensity")
    ax.set_title("Intensity distribution (log2 LFQ)")
    fig.tight_layout()
    f = os.path.join(out_dir, "qc_normalization.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)
    files.append(f)

    # --- RLE plot (Relative Log Expression) ---
    # Diagnostic de normalisation résiduelle APRÈS DIA-NN (cross-run RT-dependent).
    # Pour chaque protéine, on soustrait sa médiane across-samples ; on boxplote
    # ces écarts par échantillon. Attendu si la normalisation tient : toutes les
    # boîtes centrées sur 0, de dispersion comparable. Un run dont la médiane RLE
    # s'écarte de 0 ou dont la boîte est anormalement étalée signale un effet
    # technique résiduel (le RLE neutralise le signal biologique commun, ce que
    # le boxplot de distribution brute ne fait pas). Aucune donnée n'est modifiée.
    rle = mat.sub(mat.median(axis=1), axis=0)   # écart à la médiane par protéine
    data_rle = [rle[c].dropna().values.flatten() for c in mat.columns]
    med_rle = np.array([np.median(d) if len(d) else np.nan for d in data_rle])
    cond_col = _condition_colors(conditions)
    fig, ax = plt.subplots(figsize=(max(10, len(mat.columns) * 0.4), 5))
    bp = ax.boxplot(data_rle, patch_artist=True, showfliers=False,
                    medianprops=dict(color="black", linewidth=1),
                    whiskerprops=dict(color="grey"))
    for patch, c in zip(bp["boxes"], conditions):
        patch.set_facecolor(cond_col[c]); patch.set_alpha(0.75)
    ax.axhline(0, color="red", linestyle="--", linewidth=0.8, zorder=0)
    ax.set_xticks(range(1, len(mat.columns) + 1))
    ax.set_xticklabels(design["label"].values, rotation=90, fontsize=7)
    ax.set_ylabel("Relative Log Expression (log2)")
    # Borne l'axe Y sur l'IQR agrégé pour rester lisible malgré les protéines extrêmes
    all_vals = np.concatenate([d for d in data_rle if len(d)])
    if all_vals.size:
        ylim = np.nanpercentile(np.abs(all_vals), 99)
        ax.set_ylim(-ylim, ylim)
    worst = np.nanmax(np.abs(med_rle)) if np.isfinite(med_rle).any() else 0.0
    ax.set_title(f"RLE plot — residual normalization check "
                 f"(max |median| = {worst:.2f} log2)")
    handles = [mpatches.Patch(color=v, label=k) for k, v in cond_col.items()]
    ax.legend(handles=handles, fontsize=7, loc="upper right")
    fig.tight_layout()
    f = os.path.join(out_dir, "qc_rle.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)
    files.append(f)

    # --- Missing values heatmap ---
    fig, ax = plt.subplots(figsize=(max(8, len(mat.columns) * 0.35),
                                    min(12, len(mat) * 0.02 + 2)))
    sns.heatmap(mat.isna().astype(int), cmap=["#2ECC71", "#E74C3C"],
                yticklabels=False, xticklabels=design["label"].values,
                ax=ax, cbar=False)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=90, fontsize=7)
    ax.set_title("Missing values (red = absent)")
    fig.tight_layout()
    f = os.path.join(out_dir, "qc_missval.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)
    files.append(f)

    return files


# ==============================================================================
# 4. FILTRATION ET IMPUTATION MINPROB
# ==============================================================================

def filter_missval(mat: pd.DataFrame, design: pd.DataFrame, thr: int = 1) -> pd.DataFrame:
    """
    Garde les protéines détectées dans au moins (max_n_replicates - thr)
    réplicats dans AU MOINS une condition.
    thr=1 → détectée dans tous sauf 1 réplicat max.
    """
    conditions = design["condition"].values
    keep = np.zeros(len(mat), dtype=bool)

    for cond in np.unique(conditions):
        cols = mat.columns[conditions == cond]
        n = len(cols)
        min_detect = max(1, n - thr)
        detected = mat[cols].notna().sum(axis=1) >= min_detect
        keep |= detected.values

    filtered = mat[keep].reset_index(drop=True)
    print(f"  -> Filtering: {keep.sum()}/{len(mat)} proteins kept (thr={thr})")
    return filtered, keep


def impute_minprob(mat: pd.DataFrame, q: float = 0.01, rng=None) -> pd.DataFrame:
    """
    Imputation MinProb : remplace les NaN par un tirage dans N(µ_low, σ_low²)
    centré sur le quantile q de la distribution des valeurs détectées.
    rng : générateur np.random optionnel (pour reproductibilité en parallèle).
    Sans rng, tirage stochastique global (comportement historique).
    """
    draw = (rng.normal if rng is not None else np.random.normal)
    mat_imp = mat.copy()
    for col in mat_imp.columns:
        vals = mat_imp[col].dropna().values
        if len(vals) < 3:
            continue
        mu_low = np.quantile(vals, q)
        sd_low = np.std(vals) * 0.3  # σ réduit comme dans DEP
        n_miss = int(mat_imp[col].isna().sum())
        if n_miss > 0:
            mat_imp.loc[mat_imp[col].isna(), col] = draw(mu_low, sd_low, n_miss)
    return mat_imp


def _qrilc_fit(obs: np.ndarray, p_miss: float, upper_q: float = 0.99):
    """
    Estimation QRILC des paramètres (µ, σ) de la distribution log2 COMPLÈTE
    (observées + manquantes) d'un échantillon, à partir des seules valeurs
    observées — Lazar et al. 2016, algorithme de imputeLCMD::impute.QRILC.

    Hypothèse : censure à gauche, i.e. les p_miss valeurs manquantes sont les
    plus basses. Le quantile p des OBSERVÉES correspond alors au quantile
    p_miss + p·(1 - p_miss) de la distribution complète. On régresse les
    quantiles observés sur les quantiles N(0,1) correspondants :
        q_obs(p) = µ + σ · Φ⁻¹(p_miss + p·(1 - p_miss))
    -> intercept = µ, pente = σ (fit OLS sur une grille de 100 quantiles).
    Contrairement à mean/sd des observées (µ biaisé vers le haut, σ vers le
    bas par la troncature), l'estimation est non biaisée sous censure à gauche.
    """
    from scipy.stats import norm
    probs_obs = np.linspace(0.001, upper_q, 100)
    q_obs = np.quantile(obs, probs_obs)
    z = norm.ppf(p_miss + probs_obs * (1.0 - p_miss))
    sigma, mu = np.polyfit(z, q_obs, 1)
    return float(mu), float(sigma)


def impute_qrilc(mat: pd.DataFrame, rng=None, tune_sigma: float = 1.0,
                 min_obs: int = 5) -> pd.DataFrame:
    """
    QRILC — Quantile Regression Imputation of Left-Censored data (Lazar 2016).

    Par échantillon :
      1. µ, σ de la distribution complète estimés par régression quantile
         (voir _qrilc_fit) ;
      2. seuil de censure = Φ⁻¹(p_miss ; µ, σ) ;
      3. tirage des manquantes dans N(µ, (tune_sigma·σ)²) TRONQUÉE à droite
         au seuil -> valeurs imputées toujours sous la limite de détection
         estimée, et d'autant plus basses que l'échantillon a peu de NA.

    Écart assumé vs imputeLCMD : le code R passe l'écart-type comme argument
    `sigma` de tmvtnorm::rtmvnorm, qui attend une VARIANCE ; ici on tire avec
    l'écart-type estimé, conformément au modèle décrit dans l'article.
    Repli : < min_obs valeurs observées ou fit dégénéré -> minimum observé.
    """
    from scipy.stats import norm, truncnorm
    if rng is None:
        rng = np.random.default_rng()
    mat_imp = mat.copy()
    for col in mat_imp.columns:
        s = mat_imp[col]
        na = s.isna().values
        n_miss = int(na.sum())
        if n_miss == 0:
            continue
        obs = s.values[~na].astype(float)
        if len(obs) < min_obs:
            if len(obs) > 0:
                mat_imp.loc[na, col] = obs.min()
            continue
        p_miss = n_miss / len(s)
        mu, sigma = _qrilc_fit(obs, p_miss)
        if not np.isfinite(sigma) or sigma <= 0:
            mat_imp.loc[na, col] = obs.min()
            continue
        sd = sigma * tune_sigma
        upper = norm.ppf(p_miss, loc=mu, scale=sigma)
        draws = truncnorm.rvs(-np.inf, (upper - mu) / sd, loc=mu, scale=sd,
                              size=n_miss, random_state=rng)
        mat_imp.loc[na, col] = draws
    return mat_imp


def impute_knn(mat: pd.DataFrame, k: int = 10) -> pd.DataFrame:
    """
    kNN — imputation MAR par k plus proches voisins (protéines au profil
    similaire). À réserver aux manquements aléatoires (non liés à l'intensité).
    Utilisé ici uniquement pour la composante MAR de l'imputation mixte.
    """
    from sklearn.impute import KNNImputer
    imputer = KNNImputer(n_neighbors=min(k, max(2, mat.shape[0] - 1)))
    arr = imputer.fit_transform(mat.values)
    return pd.DataFrame(arr, index=mat.index, columns=mat.columns)


def knn_component(mat: pd.DataFrame) -> "np.ndarray | None":
    """Composante kNN (MAR) de l'imputation mixte, ou None si le kNN échoue.
    Déterministe (ne dépend d'aucune graine) : calculable une seule fois pour
    plusieurs tirages de la même matrice."""
    try:
        return impute_knn(mat).values
    except Exception:                                                 # noqa: BLE001
        return None


def impute_mixed(mat: pd.DataFrame, design: pd.DataFrame, rng=None,
                 legacy: bool = False, knn_full: "np.ndarray | None" = None) -> pd.DataFrame:
    """
    Imputation MIXTE (MNAR + MAR), approche Perseus/MSnbase :
      • Une protéine ABSENTE de TOUS les réplicats d'au moins une condition →
        manquement MNAR (sous le seuil de détection) → QRILC pour TOUTES ses
        valeurs manquantes, y compris les manques partiels des autres conditions.
      • Une protéine sans absence totale (manques seulement partiels) → MAR → kNN.

    Pourquoi la ligne entière (correction 10/2026) : avec QRILC pour le groupe
    absent et kNN pour le manque partiel de l'autre groupe, le premier est placé
    bas et le second près des valeurs observées → écart net à faible variance,
    fabriqué par l'imputation (50 à 120 faux positifs par comparaison nulle sur
    données réelles). Une absence totale signale une protéine proche du seuil de
    détection : ses autres manques sont, eux aussi, plus probablement MNAR.

    legacy=True : comportement d'origine (décision condition par condition),
    conservé pour reproduire d'anciennes analyses (impute_method: mixed_legacy).

    knn_full : imputation kNN de `mat` déjà calculée (knn_component). Le kNN est
    déterministe : seule la part QRILC change d'un tirage à l'autre, donc les
    ré-imputations du score de robustesse le calculent une fois et le passent ici
    (résultat identique, et le kNN représente ~99 % du temps d'une itération).
    """
    if rng is None:
        rng = np.random.default_rng()
    conditions = design["condition"].values
    mat_arr = mat.values.copy()
    na_mask = np.isnan(mat_arr)

    # 1) Pré-calcul des deux imputations complètes
    qrilc_full = impute_qrilc(mat, rng=rng).values
    if knn_full is None:
        knn_full = knn_component(mat)
    if knn_full is None:
        knn_full = qrilc_full  # repli si kNN échoue (peu de protéines)

    # 2) Pour chaque NaN, décider MNAR (QRILC) ou MAR (kNN)
    out = mat_arr.copy()
    col_cond = np.array(conditions)
    if not legacy:
        whole_absent = np.zeros(mat_arr.shape[0], dtype=bool)
        for cond in np.unique(col_cond):
            whole_absent |= na_mask[:, col_cond == cond].all(axis=1)
        out[na_mask] = np.where(whole_absent[:, None], qrilc_full, knn_full)[na_mask]
        return pd.DataFrame(out, index=mat.index, columns=mat.columns)
    for i in range(mat_arr.shape[0]):
        if not na_mask[i].any():
            continue
        for cond in np.unique(col_cond):
            cidx = np.where(col_cond == cond)[0]
            sub = mat_arr[i, cidx]
            n_present = np.sum(~np.isnan(sub))
            miss_here = cidx[np.isnan(sub)]
            if len(miss_here) == 0:
                continue
            if n_present == 0:
                # Absence totale dans la condition → MNAR → QRILC
                out[i, miss_here] = qrilc_full[i, miss_here]
            else:
                # Partiellement présent → MAR → kNN
                out[i, miss_here] = knn_full[i, miss_here]
    return pd.DataFrame(out, index=mat.index, columns=mat.columns)


# Seuil du mode impute_method='auto' : part de NA « MAR » (protéine présente
# dans >= 1 réplicat de la condition) au-delà de laquelle on passe en MIXED.
AUTO_MIXED_MAR_PCT = 20.0


def impute(mat: pd.DataFrame, method: str = "qrilc",
           design: pd.DataFrame = None, rng=None,
           knn_full: "np.ndarray | None" = None) -> pd.DataFrame:
    """Dispatcher d'imputation. method ∈ {'mixed', 'mixed_legacy', 'qrilc', 'minprob'}.
    knn_full : composante kNN pré-calculée (knn_component), méthodes mixtes seulement."""
    if method in ("mixed", "mixed_legacy"):
        if design is None:
            print("  [WARN] Mixed imputation requires the design -> falling back to QRILC.")
            return impute_qrilc(mat, rng=rng)
        return impute_mixed(mat, design, rng=rng, legacy=(method == "mixed_legacy"),
                            knn_full=knn_full)
    elif method == "minprob":
        return impute_minprob(mat, rng=rng)
    else:  # qrilc (défaut)
        return impute_qrilc(mat, rng=rng)


def diagnose_missingness(mat: pd.DataFrame, design: pd.DataFrame,
                         out_dir: str) -> dict:
    """
    Diagnostic de la structure des valeurs manquantes pour objectiver le choix
    d'imputation (Mixte vs QRILC).

    Classe chaque valeur manquante :
      • MNAR : la protéine est absente de TOUS les réplicats de la condition
        (sous le seuil de détection → manquement lié à l'intensité).
      • MAR  : la protéine est présente dans ≥1 réplicat de la condition mais
        manquante dans d'autres (manquement vraisemblablement aléatoire).

    Produit :
      - un PNG (2 panneaux : part MNAR/MAR + intensité des protéines à trous)
      - un dict de métriques (part MNAR/MAR, recommandation)
    """
    conditions = design["condition"].values
    arr = mat.values
    na = np.isnan(arr)
    n_missing = int(na.sum())
    if n_missing == 0:
        print("  [INFO] No missing values — diagnostic not relevant.")
        return {"n_missing": 0, "recommendation": "Aucune imputation nécessaire"}

    # Classer chaque NaN en MNAR / MAR selon la présence dans la condition
    mnar_count = 0
    mar_count = 0
    uniq_conds = np.unique(conditions)
    for i in range(arr.shape[0]):
        if not na[i].any():
            continue
        for cond in uniq_conds:
            cidx = np.where(conditions == cond)[0]
            sub = arr[i, cidx]
            n_miss_here = int(np.isnan(sub).sum())
            if n_miss_here == 0:
                continue
            if np.sum(~np.isnan(sub)) == 0:
                mnar_count += n_miss_here     # absence totale → MNAR
            else:
                mar_count += n_miss_here       # partielle → MAR
    total = mnar_count + mar_count
    pct_mnar = 100 * mnar_count / total if total else 0
    pct_mar  = 100 * mar_count / total if total else 0

    # Intensité moyenne des protéines AVEC trous vs SANS trou (signature MNAR :
    # les protéines à trous doivent être globalement moins intenses)
    prot_has_na = na.any(axis=1)
    mean_int = np.nanmean(arr, axis=1)
    int_with_na = mean_int[prot_has_na]
    int_no_na   = mean_int[~prot_has_na]

    # --- Graphique ---
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    # Panneau 1 : répartition MNAR / MAR
    axes[0].bar(["MNAR\n(fully absent\nin a condition)",
                 "MAR\n(partial\nmissingness)"],
                [pct_mnar, pct_mar],
                color=["#E8684A", "#5B8FF9"], edgecolor="black", lw=0.5)
    axes[0].set_ylabel("% of missing values")
    axes[0].set_title(f"Missingness structure (n = {total:,} values)",
                      fontweight="bold", fontsize=11)
    for x, v in enumerate([pct_mnar, pct_mar]):
        axes[0].text(x, v + 1, f"{v:.0f} %", ha="center", fontweight="bold")
    axes[0].set_ylim(0, 105)

    # Panel 2: intensity distribution (proteins with gaps vs complete)
    bins = np.linspace(np.nanmin(mean_int), np.nanmax(mean_int), 40)
    axes[1].hist(int_no_na, bins=bins, alpha=0.6, label="No missing value",
                 color="#999999", density=True)
    axes[1].hist(int_with_na, bins=bins, alpha=0.6, label="With >=1 missing",
                 color="#E8684A", density=True)
    axes[1].set_xlabel("Mean log2 intensity")
    axes[1].set_ylabel("Density")
    axes[1].set_title("Intensity of proteins with gaps\n(left shift = MNAR signature)",
                      fontweight="bold", fontsize=11)
    axes[1].legend(fontsize=9)
    fig.suptitle("Missingness diagnostic — imputation choice",
                 fontsize=13, fontweight="bold", y=1.02)
    fig.tight_layout()
    f = os.path.join(out_dir, "diagnostic_missingness.png")
    fig.savefig(f, dpi=150, bbox_inches="tight")
    plt.close(fig)

    # --- Recommandation automatique ---
    delta_int = float(np.nanmedian(int_no_na) - np.nanmedian(int_with_na))
    if pct_mar >= 20:
        reco = ("MIXED imputation recommended: non-negligible MAR fraction "
                f"({pct_mar:.0f}%) -> kNN beneficial on these partial missing values.")
    elif delta_int > 0.5:
        reco = ("QRILC (MNAR) is sufficient: missingness predominantly MNAR "
                f"({pct_mnar:.0f}%) and proteins with gaps clearly less "
                f"intense (median delta = {delta_int:.2f} log2).")
    else:
        reco = (f"Missingness at {pct_mnar:.0f}% MNAR / {pct_mar:.0f}% MAR. "
                "QRILC is appropriate; Mixed adds marginal benefit.")

    metrics = {
        "n_missing": n_missing,
        "pct_mnar": round(pct_mnar, 1),
        "pct_mar": round(pct_mar, 1),
        "delta_intensity": round(delta_int, 3),
        "recommendation": reco,
        "plot": f,
    }
    print(f"  [STATS] Missingness: {pct_mnar:.0f}% MNAR / {pct_mar:.0f}% MAR "
          f"| delta intensity(complete-gaps) = {delta_int:.2f} log2")
    print(f"     -> {reco}")
    return metrics


def diagnose_deqms_reliability(sigma2: np.ndarray, pep_count: np.ndarray,
                               out_dir: str, min_r2: float = 0.10,
                               max_pseudocount_pct: float = 50.0) -> dict:
    """
    Diagnostic de fiabilité de DEqMS pour objectiver son activation.

    La prémisse de DEqMS (Zhu et al. 2020) est que la variance résiduelle
    dépend du nombre de peptides quantifiés par protéine. Cette relation n'est
    identifiable que si (a) suffisamment de protéines ont un comptage > 1 et
    (b) la relation variance~comptage explique une part non négligeable de la
    variance observée. Sans ça, l'ajustement loess est mal contraint (bascule
    entre implémentations, quasi-singularités) et DEqMS n'apporte pas de gain
    fiable sur limma seul.

    Parameters
    ----------
    sigma2               : variance résiduelle par protéine (fit['sigma']**2,
                            issu du lm_fit AVANT contrasts_fit/eBayes)
    pep_count             : comptage peptidique par protéine (même ordre),
                            NaN autorisé pour les protéines sans comptage
    min_r2                : R² minimum de la régression log(variance) ~
                            log2(comptage) sur le sous-ensemble informatif
                            (comptage > 1) pour juger la relation exploitable
    max_pseudocount_pct   : % maximum de protéines à comptage <= 1 (pseudo-
                            comptées) au-delà duquel le signal est jugé trop
                            dégénéré, même si le R² sur le sous-ensemble
                            informatif est correct

    Returns
    -------
    dict : pct_pseudocount, n_informative, r2, reliable (bool),
           recommendation (str), plot (path ou None)
    """
    sigma2 = np.asarray(sigma2, dtype=float)
    pep_count = np.asarray(pep_count, dtype=float)
    valid = np.isfinite(pep_count) & np.isfinite(sigma2) & (sigma2 > 0)
    n_total = len(pep_count)
    pct_pseudocount = 100 * float(np.mean(~valid | (pep_count <= 1)))

    informative = valid & (pep_count > 1)
    n_informative = int(informative.sum())

    if n_informative < 30:
        r2 = None
        reliable = False
        reco = (f"Trop peu de protéines informatives (n={n_informative}) pour "
                "évaluer la relation variance~comptage — DEqMS non fiable ici.")
    else:
        x = np.log2(pep_count[informative])
        y = np.log(sigma2[informative])
        r, _ = pearsonr(x, y)
        r2 = float(r ** 2)
        reliable = (pct_pseudocount < max_pseudocount_pct) and (r2 >= min_r2)
        if reliable:
            reco = (f"Relation variance~comptage exploitable (R²={r2:.3f} sur "
                    f"{n_informative} protéines informatives, "
                    f"{pct_pseudocount:.0f}% pseudocomptées) — DEqMS activé.")
        elif r2 < min_r2:
            reco = (f"R²={r2:.3f} < seuil ({min_r2}) : la variance n'est pas "
                    "expliquée par le comptage peptidique sur ce run — DEqMS "
                    "désactivé (limma seul utilisé). Forcer avec deqms_force: true.")
        else:
            reco = (f"{pct_pseudocount:.0f}% de protéines pseudocomptées "
                    f"(seuil {max_pseudocount_pct:.0f}%) : trop de protéines "
                    "sans signal de comptage exploitable — DEqMS désactivé. "
                    "Forcer avec deqms_force: true.")

    # --- Graphique diagnostic (dans le même style que diagnose_missingness) ---
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    axes[0].bar(["Informatives\n(count > 1)", "Pseudocomptées\n(count <= 1)"],
                [100 - pct_pseudocount, pct_pseudocount],
                color=["#5B8FF9", "#E8684A"], edgecolor="black", lw=0.5)
    axes[0].set_ylabel("% des protéines")
    axes[0].set_title(f"Comptage peptidique (n = {n_total:,} protéines)",
                      fontweight="bold", fontsize=11)
    axes[0].set_ylim(0, 105)

    if n_informative >= 30:
        axes[1].scatter(x, y, s=8, alpha=0.35, color="#5B8FF9")
        order = np.argsort(x)
        b = np.polyfit(x, y, 1)
        axes[1].plot(np.sort(x), np.polyval(b, np.sort(x)), color="#E8684A", lw=2)
        axes[1].set_title(f"Variance ~ comptage (R²={r2:.3f})",
                          fontweight="bold", fontsize=11)
    else:
        axes[1].text(0.5, 0.5, "Trop peu de protéines\ninformatives",
                    ha="center", va="center", transform=axes[1].transAxes)
    axes[1].set_xlabel("log2(comptage peptidique)")
    axes[1].set_ylabel("log(variance résiduelle)")
    fig.suptitle("Diagnostic de fiabilité DEqMS", fontsize=13,
                fontweight="bold", y=1.02)
    fig.tight_layout()
    f = os.path.join(out_dir, "diagnostic_deqms.png")
    fig.savefig(f, dpi=150, bbox_inches="tight")
    plt.close(fig)

    metrics = {
        "pct_pseudocount": round(pct_pseudocount, 1),
        "n_informative": n_informative,
        "r2": round(r2, 3) if r2 is not None else None,
        "reliable": reliable,
        "recommendation": reco,
        "plot": f,
    }
    print(f"  [STATS] DEqMS diagnostic: {pct_pseudocount:.0f}% pseudocomptées, "
          f"R²={f'{r2:.3f}' if r2 is not None else 'N/A'} sur {n_informative} "
          "protéines informatives")
    print(f"     -> {reco}")
    return metrics


def plot_imputation(mat_filt: pd.DataFrame, mat_imp: pd.DataFrame,
                    out_dir: str) -> str:
    """Superposition avant/après imputation."""
    fig, ax = plt.subplots(figsize=(7, 4))
    vals_before = mat_filt.values.flatten()
    vals_before = vals_before[~np.isnan(vals_before)]
    vals_after  = mat_imp.values.flatten()

    ax.hist(vals_before, bins=80, alpha=0.6, color="#3498DB", label="Before imputation", density=True)
    ax.hist(vals_after,  bins=80, alpha=0.6, color="#E74C3C", label="After imputation", density=True)
    ax.set_xlabel("log2 LFQ intensity")
    ax.set_ylabel("Density")
    ax.set_title("Effect of imputation (reference draw)")
    ax.legend()
    fig.tight_layout()
    f = os.path.join(out_dir, "qc_imputation.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)
    return f


# ==============================================================================
# 5. ANALYSE DIFFÉRENTIELLE — eBayes + Robustness
# ==============================================================================

def _contrast_regex(template: str) -> "re.Pattern":
    """'Live_{s}' -> ^Live_(?P<s>.+?)$ ; '*' = n'importe quoi (non contraint)."""
    out, pos = [], 0
    for m in re.finditer(r"\{(\w+)\}|\*", template):
        out.append(re.escape(template[pos:m.start()]))
        out.append(f"(?P<{m.group(1)}>.+?)" if m.group(1) else ".+?")
        pos = m.end()
    out.append(re.escape(template[pos:]))
    return re.compile("^" + "".join(out) + "$")


def select_contrasts(contrast_mat: np.ndarray, contrast_names: list,
                     group_names: list, spec) -> "tuple[np.ndarray, list]":
    """
    Restreint les contrastes à ceux demandés (clé YAML `contrasts`).

    spec : liste de chaînes 'A_vs_B' (noms tels qu'ils apparaissent dans les
           contrastes / l'Excel), avec en option :
             {x} : même valeur des deux côtés  -> "Live_{s}_vs_Heat_killed_{s}"
                   (= vivant vs tué, au sein de chaque souche)
             *   : n'importe quelle valeur      -> "Live_*_vs_Live_*"
           L'ORIENTATION demandée est respectée (numérateur_vs_dénominateur) :
           une paire absente dans ce sens est obtenue en inversant le signe.
           Une paire demandée deux fois (A_vs_B et B_vs_A) n'est gardée qu'une fois.
    Returns (contrast_mat restreinte, noms). ValueError si rien ne correspond.
    """
    if isinstance(spec, str):
        spec = [spec]
    labels = [g.replace(".", "_") for g in group_names]
    n = len(labels)
    n_rows = contrast_mat.shape[0]
    ordered = [(i, j) for i in range(n) for j in range(i + 1, n)]
    ordered += [(j, i) for (i, j) in ordered]      # sens par défaut d'abord
    chosen, seen = [], set()
    for item in spec:
        parts = str(item).split("_vs_")
        if len(parts) != 2:
            raise ValueError(f"contraste '{item}' : format attendu 'A_vs_B'.")
        rl, rr = _contrast_regex(parts[0]), _contrast_regex(parts[1])
        n_hit = 0
        for i, j in ordered:
            ml, mr = rl.match(labels[i]), rr.match(labels[j])
            if not (ml and mr):
                continue
            dl, dr = ml.groupdict(), mr.groupdict()
            if any(dl[k] != dr[k] for k in dl.keys() & dr.keys()):
                continue
            n_hit += 1
            key = frozenset((i, j))
            if key in seen:
                continue
            seen.add(key)
            chosen.append((i, j))
        if n_hit == 0:
            print(f"  [WARN] contraste '{item}' : aucune paire de conditions ne correspond.")
    if not chosen:
        raise ValueError("aucun contraste retenu. Conditions disponibles : "
                         + ", ".join(labels))
    mat = np.zeros((n_rows, len(chosen)))
    names = []
    for k, (i, j) in enumerate(chosen):
        mat[i, k], mat[j, k] = 1, -1
        names.append(f"{labels[i]}_vs_{labels[j]}")
    return mat, names


def suggest_contrast_pattern(group_names: list) -> "str | None":
    """Design factoriel 'ETAT_SOUCHE' complet (ex. Live/Heat_killed x 12
    souches) -> propose la comparaison des états au sein de chaque souche :
    'Live_{s}_vs_Heat_killed_{s}'. None si pas de structure factorielle."""
    labels = [g.replace(".", "_") for g in group_names]
    if not all("_" in l for l in labels):
        return None
    split = [l.rsplit("_", 1) for l in labels]
    prefixes = list(dict.fromkeys(p for p, _ in split))
    suffixes = list(dict.fromkeys(s for _, s in split))
    if (2 <= len(prefixes) <= 4 and len(suffixes) >= 2
            and len(labels) == len(prefixes) * len(suffixes)
            and {(p, s) for p, s in split} == {(p, s) for p in prefixes for s in suffixes}):
        return f"{prefixes[0]}_{{s}}_vs_{prefixes[1]}_{{s}}"
    return None


def resolve_contrasts(contrast_mat, contrast_names, group_names, params: dict):
    """Applique params['contrasts'] :
      - liste / chaîne : sélection (select_contrasts) ;
      - 'all' ou None  : tous les contrastes ;
      - '__auto__' (défaut) : tous, mais au-delà de 30 contrastes, question
        avec une proposition déduite des noms de conditions. Le choix est
        réécrit dans params (et last_config.yaml) pour les runs suivants."""
    spec = params.get("contrasts", "__auto__")
    if spec in (None, "all", "ALL", "", []):
        return contrast_mat, contrast_names
    if spec == "__auto__":
        if len(contrast_names) <= 30:
            return contrast_mat, contrast_names
        sugg = suggest_contrast_pattern(group_names)
        print(f"\n[MODEL] {len(contrast_names)} contrastes (toutes les paires de "
              f"{len(group_names)} conditions).")
        if sugg:
            n_s = len(select_contrasts(contrast_mat, contrast_names, group_names,
                                       [sugg])[1])
            print(f"  Proposition : {sugg}  ({n_s} contrastes)")
        print("  Entrée = " + ("proposition" if sugg else "tous") +
              " | 'all' = tous | ou motif(s) séparés par des virgules "
              "(ex: Live_{s}_vs_Heat_killed_{s}, Live_*_vs_Live_*)")
        rep = input("  Contrastes -> ").strip()
        if rep.lower() == "all" or (not rep and not sugg):
            params["contrasts"] = "all"
            return contrast_mat, contrast_names
        spec = [x.strip() for x in (rep or sugg).split(",") if x.strip()]
        params["contrasts"] = spec
        try:
            from config import _save_last_config
            _save_last_config(params)
        except Exception:
            pass
    mat, names = select_contrasts(contrast_mat, contrast_names, group_names, spec)
    print(f"[MODEL] Contrastes retenus ({len(names)}/{len(contrast_names)}) : "
          f"{names[:4]}{'...' if len(names) > 4 else ''}")
    return mat, names


_SUBJECT_COLS = ("subject", "pair", "patient", "individual")
_SUBJECT_LIKE = ("animal", "donor", "mouse", "rat", "sujet", "individu",
                 "subject_id", "patient_id", "donor_id", "animal_id")


def pseudoreplication_check(design: pd.DataFrame) -> "dict | None":
    """
    Avertissement (n'altère pas le modèle) : un même sujet a-t-il plusieurs
    échantillons dans la MÊME condition ? Si oui, ces échantillons ne sont pas
    des réplicats indépendants (pseudo-réplication) : limma les traite comme
    tels -> variance résiduelle sous-estimée, p-values trop optimistes.
    'nested' = chaque sujet n'est que dans une condition -> la comparaison
    porte ENTRE sujets : l'unité statistique est le sujet.
    """
    if design is None or "condition" not in design.columns:
        return None
    subj_col = next((c for c in _SUBJECT_COLS if c in design.columns), None)
    if subj_col is None:
        return None
    ok = design[subj_col].notna()
    subj = (design.loc[ok, subj_col].astype(str).str.strip()
            .str.replace(r"\.0$", "", regex=True))
    df = pd.DataFrame({"s": subj.values,
                       "c": design.loc[ok, "condition"].astype(str).values})
    counts = df.groupby(["s", "c"]).size()
    rep = counts[counts >= 2]
    if rep.empty:
        return None
    ex_s, ex_c = rep.index[0]
    return {"subj_col": subj_col, "n_cells": int(len(rep)),
            "n_subjects": int(rep.index.get_level_values(0).nunique()),
            "n_samples": int(rep.sum()),
            "example": (ex_s, ex_c, int(rep.iloc[0])),
            "nested": bool((df.groupby("s")["c"].nunique() == 1).all())}


def warn_design(design: pd.DataFrame) -> "dict | None":
    """Affiche les avertissements de design (pseudo-réplication, colonne
    'sujet' non reconnue). Retourne le résultat de pseudoreplication_check."""
    pr = pseudoreplication_check(design)
    if pr:
        s, c, n = pr["example"]
        print(f"  [WARN] PSEUDO-REPLICATION : {pr['n_subjects']} sujet(s) ont "
              f"plusieurs échantillons dans la même condition "
              f"(ex. {pr['subj_col']} '{s}' x '{c}' : {n} échantillons).")
        print("         Deimos les traite comme des réplicats indépendants : "
              "variance sous-estimée, p-values trop optimistes.")
        if pr["nested"]:
            print("         Chaque sujet n'est que dans une condition : la "
                  "comparaison porte ENTRE sujets, l'unité statistique est le sujet.")
        print("         Pistes : moyenner les répétitions par sujet x condition "
              "avant Deimos, ou un modèle à effet aléatoire sujet "
              "(dream / duplicateCorrelation).")
    elif (design is not None
          and not any(c in design.columns for c in _SUBJECT_COLS)):
        like = [c for c in design.columns if c.lower() in _SUBJECT_LIKE]
        if like:
            print(f"  [WARN] Colonne {like} présente mais non utilisée comme sujet "
                  f"(noms reconnus : {', '.join(_SUBJECT_COLS)}). Si elle identifie "
                  f"l'individu, renommez-la 'subject' pour l'appariement et le "
                  f"contrôle de pseudo-réplication.")
    return pr


def run_differential_analysis(mat_imp: pd.DataFrame, mat_filt: pd.DataFrame,
                               meta: pd.DataFrame, design: pd.DataFrame,
                               params: dict, out_dir: str, n_iter: int = 100,
                               pep_count: "pd.Series | None" = None,
                               model_out: "dict | None" = None
                               ) -> tuple[pd.DataFrame, list[str]]:
    """
    1. Modèle linéaire eBayes sur données imputées (référence)
    2. Si pep_count fourni : calcule AUSSI DEqMS (variance ~ nb peptides) en parallèle
    3. Robustness score (n_iter imputations stochastiques, seuils volcanos)
    4. Scatter plots par contraste
    5. Retourne df_results (une ligne par protéine, toutes stats) + noms contrastes
    """
    conditions = design["condition"].values
    expr = mat_imp.values.astype(float)          # (n_prot × n_samples)

    # --- Design matrix : apparié (~0 + condition + subject) si colonne 'subject'
    #     présente et valide, sinon modèle standard (~0 + condition). ---
    paired = False
    subj_col = None
    for cand in ("subject", "pair", "patient", "individual"):
        if cand in design.columns:
            subj_col = cand
            break
    if subj_col is not None:
        # Alerte si des valeurs 'subject' sont manquantes (NaN) : cela vient
        # souvent d'un séparateur erroné dans le CSV (virgule au lieu de ';')
        # qui décale les colonnes et vide 'subject' sur certaines lignes.
        n_missing = design[subj_col].isna().sum()
        if n_missing > 0:
            miss_labels = design.loc[design[subj_col].isna(), "label"].tolist() \
                          if "label" in design.columns else []
            print(f"  [WARN] {n_missing} sample(s) have an EMPTY 'subject' value "
                  f"{miss_labels} — check your CSV separator (';' expected). "
                  f"These samples cannot be paired.")
        # Normalisation robuste des identifiants de sujet : on retire les
        # espaces parasites et le suffixe '.0' des identifiants numériques lus
        # comme flottants (1.0 -> 1). Sans ça, '1.0' et '1.0 ' (espace) sont vus
        # comme DEUX sujets distincts et l'appariement se casse silencieusement.
        raw_subj = design[subj_col].astype(str).str.strip()
        raw_subj = raw_subj.str.replace(r"\.0$", "", regex=True)  # 1.0 -> 1
        subjects = raw_subj.values
        n_raw = design[subj_col].astype(str).str.strip().nunique()
        n_clean = pd.Series(subjects).nunique()
        if n_clean < n_raw:
            print(f"  [INFO] Subject IDs normalized: {n_raw} -> {n_clean} "
                  f"unique subjects (removed spacing/'.0' variants).")

        # Apparié seulement si au moins un sujet couvre >= 2 conditions
        # (sinon 'subject' redondant avec les échantillons -> non identifiable).
        pairing = pd.DataFrame({"s": subjects, "c": conditions})
        n_cond_per_subj = pairing.groupby("s")["c"].nunique()
        n_subj = pairing["s"].nunique()
        # Avertir si certains sujets ne couvrent qu'une condition (appariement
        # partiel — ils ne bénéficient pas de la correction inter-sujets).
        lonely = n_cond_per_subj[n_cond_per_subj < 2]
        if len(lonely) > 0 and (n_cond_per_subj >= 2).any():
            print(f"  [WARN] {len(lonely)} subject(s) appear in only ONE "
                  f"condition: {list(lonely.index)} — they are not paired.")
        if (n_cond_per_subj >= 2).any() and n_subj >= 2 and n_subj < len(subjects):
            paired = True

    # --- Contrôle de design (avertissement seulement, modèle inchangé) ---
    warn_design(design)

    # --- Détection auto d'une condition "contrôle" -> dénominateur systématique
    #     dans tous les contrastes ("exp_vs_ctl" plutôt que "ctl_vs_exp"),
    #     par défaut. Surchargeable/désactivable via params (control_condition
    #     explicite, ou control_condition=False pour désactiver totalement).
    _cfg_ctl = params.get("control_condition", "__auto__")
    if _cfg_ctl is False:
        control_condition = None
    elif _cfg_ctl and _cfg_ctl != "__auto__":
        control_condition = detect_control_condition(
            list(dict.fromkeys(conditions.tolist())), explicit=_cfg_ctl)
    else:
        control_condition = detect_control_condition(
            list(dict.fromkeys(conditions.tolist())),
            synonyms=params.get("control_synonyms"))
    if control_condition:
        print(f"[MODEL] Condition contrôle détectée : '{control_condition}' "
              f"-> dénominateur systématique (ex: exp_vs_{control_condition}).")

    if paired:
        design_mat, group_names, all_cols = make_paired_design_matrix(
            conditions.tolist(), subjects.tolist(), control_condition=control_condition)
        contrast_mat, contrast_names = make_all_contrasts(
            group_names, n_total_cols=len(all_cols))
        n_subj_terms = len(all_cols) - len(group_names)
        print(f"\n[MODEL] PAIRED design (~0 + condition + subject): "
              f"{n_subj} subjects, {n_subj_terms} subject terms absorbed.")
    else:
        design_mat, group_names = make_design_matrix(
            conditions.tolist(), control_condition=control_condition)
        contrast_mat, contrast_names = make_all_contrasts(group_names)

    # --- Sélection des contrastes (clé YAML `contrasts`) : appliquée ICI,
    #     avant le modèle, donc propagée à tout l'aval (FDR, robustesse,
    #     volcanos, UpSet, GO, Excel, dashboard). ---
    try:
        contrast_mat, contrast_names = resolve_contrasts(
            contrast_mat, contrast_names, group_names, params)
    except ValueError as e:
        print(f"\n  [ERROR] contrasts : {e}")
        sys.exit(1)

    # Exposé à l'appelant (analyses de sensibilité : MÊME design et contrastes)
    if model_out is not None:
        model_out.update({"design_mat": design_mat, "contrast_mat": contrast_mat,
                          "contrast_names": list(contrast_names),
                          "n_groups": len(group_names)})

    print(f"[MODEL] {len(contrast_names)} contrasts generated: "
          f"{contrast_names[:5]}{'...' if len(contrast_names)>5 else ''}")

    # --- Modèle de référence (limma eBayes) ---
    fdr_global = params.get("fdr_global", False)
    fit   = lm_fit(expr, design_mat)
    fit_c = contrasts_fit(fit, contrast_mat)
    fit_e = ebayes(fit_c, fdr_global=fdr_global)
    print(f"  [OK] limma eBayes model computed "
          f"(FDR {'global' if fdr_global else 'per contrast'})")

    # --- Diagnostic de fiabilité DEqMS (objective l'activation, comme le
    #     diagnostic de missingness objective le choix d'imputation) ---
    deqms_diag = None
    if pep_count is not None:
        names_order = meta["name"].values if "name" in meta.columns else None
        pc_for_diag = (pep_count.reindex(names_order).values
                       if names_order is not None else pep_count.values)
        deqms_diag = diagnose_deqms_reliability(
            fit["sigma"] ** 2, pc_for_diag, out_dir,
            min_r2=params.get("deqms_min_r2", 0.10),
            max_pseudocount_pct=params.get("deqms_max_pseudocount_pct", 50.0),
        )
        deqms_force = params.get("deqms_force", False)
        if not deqms_diag["reliable"] and not deqms_force:
            print("  [WARN] DEqMS diagnostic unfavorable — disabling DEqMS "
                  "for this run (set deqms_force: true to override).")
            pep_count = None

    # --- Modèle DEqMS (optionnel, en parallèle) ---
    fit_dq = None
    use_deqms = pep_count is not None
    if use_deqms:
        # Aligner le comptage sur l'ordre des protéines (df_results utilise meta['name'])
        names_order = meta["name"].values if "name" in meta.columns else None
        if names_order is not None:
            pc_aligned = pep_count.reindex(names_order).values
        else:
            pc_aligned = pep_count.values
        # Remplacer NaN par 1 (count minimal) pour permettre le fit, mais marquer invalides
        # Comptage DEqMS = minimum across échantillons + 1 (pseudo-comptage appliqué
        # à toutes les protéines, comme la vignette LFQ de DEqMS) ; protéine sans
        # peptide dans le pr_matrix = 0 + 1.
        pc_for_fit = np.nan_to_num(np.asarray(pc_aligned, float), nan=0.0) + 1.0
        try:
            fit_dq = spectra_count_ebayes(fit_c, pc_for_fit,
                                          fdr_global=fdr_global)
            print(f"  [OK] DEqMS model computed (df_prior={fit_dq['df_prior']:.2f}; "
                  f"{fit_dq.get('loess_engine', 'loess')})")
            if model_out is not None:
                model_out["deqms"] = {"df_prior": fit_dq["df_prior"],
                                      "engine": fit_dq.get("loess_engine", "loess")}
        except Exception as e:
            print(f"  [WARN] DEqMS failed ({type(e).__name__}) — limma only will be used.")
            fit_dq = None
            use_deqms = False

    # --- Intensités moyennes par condition (pour scatter) ---
    # IMPORTANT : les noms de contrastes utilisent des underscores (make_all_contrasts
    # fait group.replace(".", "_")). On construit donc cond_means avec la MÊME
    # convention pour éviter tout désalignement quand une condition contient un
    # séparateur (ex. "EP-HS-10" -> groupe "EP.HS.10" -> clé contraste "EP_HS_10").
    cond_means = condition_means(expr, conditions)

    # --- Initialisation du df résultats ---
    df_results = meta.iloc[mat_filt.index if hasattr(mat_filt, 'index') else range(len(meta))].copy()
    df_results = df_results.reset_index(drop=True)

    scatter_files = []

    for i, cname in enumerate(contrast_names):
        tt = top_table(fit_e, i, protein_names=df_results["name"].values)

        # Le fold-change (_diff) vient toujours de limma : DEqMS ne modifie pas
        # l'estimation du logFC, seulement la variance résiduelle (donc la p-value).
        df_results[f"{cname}_diff"] = tt["logFC"].values

        if use_deqms and fit_dq is not None:
            # DEqMS FAIT FOI : ses p-values occupent les colonnes principales
            # (_p.val / _p.adj) utilisées par volcanos / UpSet / GO / robustesse.
            # limma est conservé en colonnes secondaires (_limma) pour comparaison.
            tt_dq = top_table(fit_dq, i, protein_names=df_results["name"].values)
            df_results[f"{cname}_p.val"]      = tt_dq["P.Value"].values
            df_results[f"{cname}_p.adj"]      = tt_dq["adj.P.Val"].values
            df_results[f"{cname}_p.val_limma"] = tt["P.Value"].values
            df_results[f"{cname}_p.adj_limma"] = tt["adj.P.Val"].values
            p_for_pi = tt_dq["P.Value"].values
        else:
            # limma seul (pas de comptage peptidique disponible)
            df_results[f"{cname}_p.val"] = tt["P.Value"].values
            df_results[f"{cname}_p.adj"] = tt["adj.P.Val"].values
            p_for_pi = tt["P.Value"].values

        df_results[f"Pi_Score_{cname}"] = (np.abs(tt["logFC"].values) *
                                           (-np.log10(np.maximum(p_for_pi, 1e-10))))

    # Comptage peptidique en colonne (traçabilité)
    # Avec primary_statistic: dpc, cette analyse imputée devient secondaire
    # (bascule faite après coup si la DPC est disponible, cf. run_pipeline_core).
    _lbl = ("Imputed-analysis statistic"
            if str(params.get("primary_statistic", "dpc")).lower() == "dpc"
            else "Primary statistic")
    if use_deqms and fit_dq is not None:
        df_results["Peptide_Count_min"] = pc_aligned     # brut (sans pseudo-comptage)
        print(f"  [INFO] {_lbl} = DEqMS (variance ~ peptide count); "
              "limma kept in _limma columns.")
    else:
        if deqms_diag is None:
            _why = "no peptide count available for DEqMS"
        elif not deqms_diag["reliable"] and not params.get("deqms_force", False):
            _why = "DEqMS disabled by the diagnostic above"
        else:
            _why = "DEqMS fit failed"
        print(f"  [INFO] {_lbl} = limma eBayes ({_why}).")

    # --- Robustness score (optionnel) ---
    # OPTIMISATION : une seule imputation sert pour TOUS les contrastes à chaque
    # itération (le fit eBayes produit tous les contrastes d'un coup). On passe
    # ainsi de (n_iter × n_contrasts) imputations à n_iter au total, et on
    # parallélise les itérations sur les cœurs disponibles.
    if n_iter and n_iter > 0:
        print(f"\n[...] Robustness score ({n_iter} iterations, shared imputations)...")
        n_prot = len(mat_filt)
        n_contr = len(contrast_names)
        p_key   = "adj.P.Val" if params["volcano_use_padj"] else "P.Value"
        lfc_min = params["volcano_lfc_min"]
        p_thr   = params["volcano_p_thresh"]
        imp_method = params.get("impute_method", "qrilc")
        base_seed  = int(params.get("seed", 42))
        # Graines des itérations dérivées de la graine de base (indépendantes du
        # tirage de référence, reproductibles, sans collision).
        iter_seeds = [int(x) for x in np.random.SeedSequence(base_seed)
                      .generate_state(n_iter, dtype=np.uint32)]
        # Imputation mixte : la composante kNN est déterministe (identique à chaque
        # tirage) et coûte ~99 % d'une itération -> calculée une seule fois ; seule
        # la part QRILC est re-tirée. Résultat identique au recalcul à chaque tirage.
        knn_cache = None
        if imp_method in ("mixed", "mixed_legacy"):
            _t0 = time.time()
            knn_cache = knn_component(mat_filt)
            print(f"    kNN component computed once ({time.time() - _t0:.0f} s), "
                  f"reused by the {n_iter} draws")

        def _one_iteration(seed):
            """Une imputation + fit → matrice (n_prot × n_contr) de succès 0/1.

            IMPORTANT : si DEqMS est la statistique principale (use_deqms), on
            réapplique DEqMS à chaque itération pour que le robustness teste la
            MÊME statistique que celle affichée dans les colonnes _p.val/_p.adj.
            Le comptage peptidique (pep_count) ne dépend pas de l'imputation des
            intensités : on le réutilise tel quel à chaque tirage.
            """
            rng = np.random.default_rng(seed)
            # MÊME méthode que le tirage de référence (qrilc / mixed) : le score
            # mesure la stabilité de la statistique affichée, pas celle d'une
            # autre imputation.
            mat_imp_tmp = impute(mat_filt, method=imp_method, design=design,
                                 rng=rng, knn_full=knn_cache)
            expr_tmp = mat_imp_tmp.values.astype(float)
            fit_tmp   = lm_fit(expr_tmp, design_mat)
            fit_tmp_c = contrasts_fit(fit_tmp, contrast_mat)
            fit_tmp_e = ebayes(fit_tmp_c, fdr_global=params.get("fdr_global", False))

            # Statistique de référence pour le critère de succès
            if use_deqms and fit_dq is not None:
                try:
                    fit_ref = spectra_count_ebayes(
                        fit_tmp_c, pc_for_fit,
                        fdr_global=params.get("fdr_global", False))
                except Exception:
                    fit_ref = fit_tmp_e   # repli limma si DEqMS échoue sur ce tirage
            else:
                fit_ref = fit_tmp_e

            out = np.zeros((n_prot, n_contr), dtype=np.int8)
            for i in range(n_contr):
                tt_tmp = top_table(fit_ref, i)
                passed = ((np.abs(tt_tmp["logFC"].values) >= lfc_min) &
                          (tt_tmp[p_key].values < p_thr))
                out[:, i] = passed.astype(np.int8)
            return out

        # Parallélisation (threads : numpy/scipy libèrent le GIL sur l'algèbre)
        success_total = np.zeros((n_prot, n_contr), dtype=np.int32)
        try:
            from concurrent.futures import ThreadPoolExecutor
            import os as _os
            n_workers = min(8, (_os.cpu_count() or 2))
            done = 0
            with ThreadPoolExecutor(max_workers=n_workers) as ex:
                for res in ex.map(_one_iteration, iter_seeds):
                    success_total += res
                    done += 1
                    if done % 10 == 0 or done == n_iter:
                        print(f"    {done}/{n_iter} iterations", end="\r")
            print()
        except Exception as e:
            # Repli séquentiel si la parallélisation échoue
            print(f"  (parallelization unavailable: {e} -> sequential)")
            for k in range(n_iter):
                success_total += _one_iteration(iter_seeds[k])
                if (k + 1) % 10 == 0:
                    print(f"    {k+1}/{n_iter}", end="\r")
            print()

        for i, cname in enumerate(contrast_names):
            df_results[f"Robustness_Score_{cname}"] = success_total[:, i]
        print("  [OK] Robustness score computed for all contrasts")
    else:
        print("\n[SKIP] Robustness score disabled (n_iter=0)")

    # --- Scatter plots (indépendants de la robustesse) ---
    scatter_files = plot_contrast_scatters(df_results, contrast_names, cond_means,
                                           params, out_dir)

    return df_results, contrast_names, scatter_files


def plot_contrast_scatters(df_results: pd.DataFrame, contrast_names: list,
                           cond_means: dict, params: dict, out_dir: str) -> list:
    """Scatter intensité moyenne g1 vs g2 par contraste, statut selon la règle des
    volcanos (volcano_status) appliquée aux colonnes principales de df_results."""
    scatter_files = []
    for i, cname in enumerate(contrast_names):
        try:
            g1, g2 = cname.split("_vs_")
            if g1 in cond_means and g2 in cond_means:
                x_vals = cond_means[g1]
                y_vals = cond_means[g2]
                # Même règle que les volcanos (statistique et seuil choisis)
                lfc, _, _, up, down = volcano_status(df_results, cname, params)

                status = np.full(len(lfc), "Not changed", dtype=object)
                status[up] = "Up regulated"
                status[down] = "Down regulated"

                col_map = {"Up regulated": "#f3a583",
                           "Down regulated": "#92dadd",
                           "Not changed": "#bdbdbd"}

                fig, ax = plt.subplots(figsize=(6, 6))
                for s, col in col_map.items():
                    mask = status == s
                    ax.scatter(x_vals[mask], y_vals[mask], c=col, s=12,
                               alpha=0.5, label=s)
                lims = [min(x_vals.min(), y_vals.min()),
                        max(x_vals.max(), y_vals.max())]
                ax.plot(lims, lims, "k--", lw=0.8, alpha=0.5)
                r = params["volcano_lfc_min"]
                ax.plot(lims, [l + r for l in lims], ":", color="grey", lw=0.7)
                ax.plot(lims, [l - r for l in lims], ":", color="grey", lw=0.7)
                ax.set_xlabel(f"log2 Intensity — {g1}")
                ax.set_ylabel(f"log2 Intensity — {g2}")
                ax.set_title(f"Scatter : {g1} vs {g2}")
                ax.legend(fontsize=8)
                fig.tight_layout()
                f_scat = os.path.join(out_dir, f"scatter_{cname}.png")
                fig.savefig(f_scat, dpi=150)
                plt.close(fig)
                scatter_files.append(f_scat)
        except Exception as e:
            print(f"  [WARN] Scatter {cname}: {e}")

    return scatter_files


# ==============================================================================
# 6. VOLCANO PLOTS
# ==============================================================================

P_FLOOR = 1e-300   # p = 0 (sous-dépassement) affichée à ce plancher, marqueur triangle


def volcano_status(df_results: pd.DataFrame, cname: str, params: dict):
    """Règle DEP des volcanos pour un contraste, partagée par les volcanos, le facet et
    les scatters : statistique choisie (p.adj ou p brute) < seuil ET |log2FC| >= seuil
    (même règle que l'UpSet et le score de robustesse).
    Retourne (lfc, p_raw, p_stat, up, down)."""
    p_key = "p.adj" if params["volcano_use_padj"] else "p.val"
    lfc = df_results[f"{cname}_diff"].to_numpy(float)
    p_raw = df_results[f"{cname}_p.val"].to_numpy(float)
    p_stat = df_results[f"{cname}_{p_key}"].to_numpy(float)
    passed = p_stat < params["volcano_p_thresh"]
    up = passed & (lfc >= params["volcano_lfc_min"])
    down = passed & (lfc <= -params["volcano_lfc_min"])
    return lfc, p_raw, p_stat, up, down


def volcano_axis(df_results: pd.DataFrame, cname: str, params: dict):
    """Axe Y du volcano et position de la ligne de seuil sur cet axe.

    volcano_y_axis: pvalue (défaut) -> -log10(p brute), comme volcanoplot() de limma :
      le nuage garde sa forme en V même sans protéine significative. Si le seuil
      porte sur la p.adj, la ligne est placée à la p brute équivalente du contraste
      (entre la plus grande p brute qui passe et la plus petite qui ne passe pas ;
      BH est monotone en p). Aucune protéine ne passe -> pas de ligne.
    volcano_y_axis: padj -> -log10 de la statistique du seuil (comportement antérieur).
    Retourne (p_axis, cut, label) ; cut = None si aucune protéine ne passe."""
    _, p_raw, p_stat, _, _ = volcano_status(df_results, cname, params)
    thresh = params["volcano_p_thresh"]
    use_padj = bool(params["volcano_use_padj"])
    if str(params.get("volcano_y_axis", "pvalue")).lower() == "padj" or not use_padj:
        return (p_stat, thresh,
                "p.adj" if use_padj else "p.value")
    ok = np.isfinite(p_raw) & np.isfinite(p_stat)
    passed = ok & (p_stat < thresh)
    if not passed.any():
        return p_raw, None, "p.value"
    hi = float(np.max(p_raw[passed]))
    above = p_raw[ok & ~passed & (p_raw > hi)]
    cut = float(np.sqrt(hi * np.min(above))) if above.size else hi
    return p_raw, cut, "p.value"


def _neglog10(p):
    return -np.log10(np.maximum(np.asarray(p, float), P_FLOOR))


def plot_volcanoes(df_results: pd.DataFrame, contrast_names: list,
                   params: dict, out_dir: str) -> tuple[list[str], str]:
    """
    Génère les volcanos individuels + le facet volcano universel.
    Seuils = seuils volcanos (= seuils robustness). Axe Y : cf. volcano_axis.
    """
    thresh = params["volcano_p_thresh"]
    lfc    = params["volcano_lfc_min"]
    stat_name = "p.adj" if params["volcano_use_padj"] else "p.value"
    rule_txt = f"{stat_name} < {thresh} & |log2FC| >= {lfc:.2f}"
    indiv_files = []

    col_map = {"Up regulated":    "#E74C3C",
               "Down regulated":  "#3498DB",
               "Not significant": "#BDBDBD"}

    def _threshold_line(ax, cut, y_name, fontsize, style, label=True):
        if cut is None:
            ax.text(0.5, 0.97, f"no protein at {stat_name} < {thresh}",
                    transform=ax.transAxes, ha="center", va="top",
                    fontsize=fontsize, color="#7F8C8D", style="italic")
            return
        ax.axhline(-np.log10(cut), **style)
        if label and y_name != stat_name:
            ax.text(0.99, -np.log10(cut), f" {stat_name} < {thresh}  (p ≈ {cut:.1e})",
                    transform=ax.get_yaxis_transform(), ha="right", va="bottom",
                    fontsize=fontsize, color="#7F8C8D",
                    bbox=dict(facecolor="white", alpha=0.75, lw=0, pad=0.6))

    # --- Volcanos individuels ---
    for cname in contrast_names:
        if f"{cname}_diff" not in df_results.columns:
            continue
        d, _, _, up, down = volcano_status(df_results, cname, params)
        p_axis, cut, y_name = volcano_axis(df_results, cname, params)
        nm = df_results["name"].values

        status = np.full(len(d), "Not significant", dtype=object)
        status[up] = "Up regulated"
        status[down] = "Down regulated"
        y_all = _neglog10(p_axis)
        floored = np.asarray(p_axis, float) < P_FLOOR

        fig, ax = plt.subplots(figsize=(7, 6))
        for s, col in col_map.items():
            mask = (status == s) & ~floored
            ax.scatter(d[mask], y_all[mask],
                       c=col, s=12, alpha=0.7, label=s)
            mask_f = (status == s) & floored
            if mask_f.any():
                ax.scatter(d[mask_f], y_all[mask_f], c=col, s=30, marker="^",
                           alpha=0.9, edgecolors="black", linewidths=0.4)

        # --- Labels des significatifs (anti-chevauchement) ---
        sig_mask = status != "Not significant"
        xs = d[sig_mask]
        ys = y_all[sig_mask]
        ns = nm[sig_mask]

        # Limiter aux plus marquants pour la lisibilité (comme geom_text_repel/max.overlaps).
        # Score = distance au point (0,seuil) → priorise forts |FC| et faibles p.
        MAX_LABELS = 40
        if len(ns) > MAX_LABELS:
            score = np.abs(xs) + ys
            keep = np.argsort(score)[::-1][:MAX_LABELS]
            xs, ys, ns = xs[keep], ys[keep], ns[keep]

        texts = []
        for xi, yi, ni in zip(xs, ys, ns):
            texts.append(ax.text(xi, yi, ni, fontsize=5, alpha=0.85))

        # adjustText si disponible (équivalent de ggrepel), sinon léger décalage
        try:
            from adjustText import adjust_text
            adjust_text(texts, ax=ax,
                        arrowprops=dict(arrowstyle="-", color="grey", lw=0.4,
                                        shrinkA=4, shrinkB=2),
                        expand_points=(1.4, 1.6), expand_text=(1.2, 1.4),
                        force_text=(0.4, 0.6), only_move={"text": "xy"})
        except ImportError:
            # Repli : petit décalage diagonal pour limiter le recouvrement
            for t in texts:
                t.set_position((t.get_position()[0] + 0.05,
                                t.get_position()[1] + 0.02))

        ax.axvline(-lfc, ls="--", lw=0.8, color="grey")
        ax.axvline( lfc, ls="--", lw=0.8, color="grey")
        _threshold_line(ax, cut, y_name, 6, dict(ls="--", lw=0.8, color="grey"))
        if floored.any():
            ax.text(0.01, 0.99, f"▲ p < {P_FLOOR:.0e}", transform=ax.transAxes,
                    ha="left", va="top", fontsize=6, color="#7F8C8D")
        ax.set_xlabel("log2 Fold Change")
        ax.set_ylabel(f"-log10({y_name})")
        ax.set_title(f"{cname.replace('_vs_', ' vs ')}\n"
                     f"Up {int(up.sum())} | Down {int(down.sum())}  ({rule_txt})",
                     fontsize=10)
        ax.legend(fontsize=7, loc="best", framealpha=0.85)
        fig.tight_layout()
        f = os.path.join(out_dir, f"volc_{cname}.png")
        fig.savefig(f, dpi=150)
        plt.close(fig)
        indiv_files.append(f)

    # --- Facet volcano universel ---
    n_c    = len(contrast_names)
    n_cols = 4
    n_rows = (n_c + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols,
                             figsize=(n_cols * 4, n_rows * 3.5))
    axes = np.array(axes).flatten()
    facet_y = "p.value"

    for idx, cname in enumerate(contrast_names):
        ax = axes[idx]
        if f"{cname}_diff" not in df_results.columns:
            ax.set_visible(False)
            continue

        d, _, _, up, down = volcano_status(df_results, cname, params)
        p_axis, cut, facet_y = volcano_axis(df_results, cname, params)
        colors_pt = np.where(up, "#E74C3C", np.where(down, "#3498DB", "#DDDDDD"))
        ax.scatter(d, _neglog10(p_axis), c=colors_pt, s=4, alpha=0.6)
        ax.axvline(-lfc, ls=":", lw=0.6, color="black", alpha=0.4)
        ax.axvline( lfc, ls=":", lw=0.6, color="black", alpha=0.4)
        _threshold_line(ax, cut, facet_y, 5,
                        dict(ls=":", lw=0.6, color="black", alpha=0.4), label=False)
        ax.set_title(f"{cname.replace('_vs_', ' vs ')}  (↑{int(up.sum())} ↓{int(down.sum())})",
                     fontsize=7, fontweight="bold", color="white",
                     bbox=dict(facecolor="#34495E", boxstyle="round,pad=0.2"))
        ax.set_xlabel("log2FC", fontsize=7)
        ax.set_ylabel(f"-log10({facet_y})", fontsize=7)
        ax.tick_params(labelsize=6)

    for idx in range(n_c, len(axes)):
        axes[idx].set_visible(False)

    # Légende globale
    patches = [mpatches.Patch(color="#E74C3C", label="Up"),
               mpatches.Patch(color="#3498DB", label="Down"),
               mpatches.Patch(color="#DDDDDD", label="NS")]
    fig.legend(handles=patches, loc="lower right", fontsize=9, ncol=3)
    line_txt = ("" if facet_y == stat_name else
                f" | dotted line = p.value equivalent to {stat_name} < {thresh}")
    fig.suptitle(f"Facet Volcano — {n_c} comparisons | "
                 f"threshold {rule_txt}{line_txt}", fontsize=11, fontweight="bold")
    fig.tight_layout(rect=[0, 0.02, 1, 0.97])

    f_facet = os.path.join(out_dir, "all_volcano_plots_grid.png")
    fig.savefig(f_facet, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  [OK] Facet volcano saved ({n_c} contrasts)")

    return indiv_files, f_facet


# ==============================================================================
# 7. PCA + ELLIPSES
# ==============================================================================

def _pca_fit(mat_imp: pd.DataFrame) -> dict:
    """PCA des échantillons (protéines centrées-réduites), partagée par le score plot
    et le loading plot : mêmes axes, mêmes signes.
    coords : échantillons × PC ; loadings : protéines × PC (vecteurs propres)."""
    expr = mat_imp.T.values  # (n_samples × n_proteins)
    # Imputation des éventuels NaN résiduels pour la PCA
    expr_imp = np.array(expr, dtype=float)
    if np.isnan(expr_imp).any():                    # moyenne par protéine (0 si vide)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            mu = np.nan_to_num(np.nanmean(expr_imp, axis=0))
        expr_imp = np.where(np.isnan(expr_imp), mu, expr_imp)
    expr_scaled = StandardScaler().fit_transform(expr_imp)
    pca = PCA(n_components=min(10, expr_scaled.shape[1], expr_scaled.shape[0]))
    coords = pca.fit_transform(expr_scaled)
    return {"coords": coords, "var_exp": pca.explained_variance_ratio_,
            "loadings": pca.components_.T}


def plot_pca(mat_imp: pd.DataFrame, design: pd.DataFrame, out_dir: str,
             data_label: str = "imputed data") -> list[str]:
    """PCA sur les données imputées, avec et sans ellipses de confiance."""
    fit = _pca_fit(mat_imp)
    coords, var_exp = fit["coords"], fit["var_exp"]

    conditions = design["condition"].values
    labels     = design["label"].values
    cmap       = _condition_colors(conditions)
    colors_pt  = [cmap[c] for c in conditions]

    files = []
    for with_ellipse in [False, True]:
        fig, ax = plt.subplots(figsize=(9, 7))
        for cond in np.unique(conditions):
            mask = conditions == cond
            ax.scatter(coords[mask, 0], coords[mask, 1],
                       color=cmap[cond], label=cond, s=60, alpha=0.85, zorder=3)
            # Labels
            for xi, yi, li in zip(coords[mask, 0], coords[mask, 1], labels[mask]):
                ax.annotate(li, (xi, yi), fontsize=6, alpha=0.7,
                            xytext=(3, 3), textcoords="offset points")
            if with_ellipse and mask.sum() >= 3:
                _draw_ellipse(ax, coords[mask, 0], coords[mask, 1],
                              color=cmap[cond], alpha=0.15)

        ax.set_xlabel(f"PC1 ({var_exp[0]*100:.1f}%)")
        ax.set_ylabel(f"PC2 ({var_exp[1]*100:.1f}%)")
        ax.set_title(f"PCA — {data_label}" + (" (95% ellipses)" if with_ellipse else ""))
        ax.legend(fontsize=7, bbox_to_anchor=(1.01, 1), loc="upper left")
        ax.axhline(0, color="grey", lw=0.5)
        ax.axvline(0, color="grey", lw=0.5)
        fig.tight_layout()
        suffix = "_ellipses" if with_ellipse else ""
        f = os.path.join(out_dir, f"plot_pca{suffix}.png")
        fig.savefig(f, dpi=150, bbox_inches="tight")
        plt.close(fig)
        files.append(f)

    return files


def pca_drivers(L: np.ndarray, coords: np.ndarray, conditions, n_total: int) -> dict:
    """Protéines qui tirent la PCA dans chaque direction : les loadings les plus
    positifs / négatifs sur PC1 et PC2 (n_total réparti entre les 4 directions).
    Pour chaque direction, les conditions dont les échantillons sont le plus de ce côté
    du score plot (moyenne de score la plus élevée dans ce sens, 2 au plus).
    Retourne {'PC1+': {'idx': [...], 'conditions': [...]}, ...} ({} si n_total = 0)."""
    if n_total <= 0 or L.shape[1] < 2:
        return {}
    n_per = max(1, int(round(n_total / 4)))
    conditions = np.asarray(conditions)
    conds = list(dict.fromkeys(conditions))
    out = {}
    for k, pc in ((0, "PC1"), (1, "PC2")):
        order = np.argsort(L[:, k])
        mean_sc = np.array([coords[conditions == c, k].mean() for c in conds])
        for sign, idx in (("+", order[::-1][:n_per]), ("-", order[:n_per])):
            sgn = 1 if sign == "+" else -1
            side = [conds[i] for i in np.argsort(-sgn * mean_sc)[:2] if sgn * mean_sc[i] > 0]
            out[f"{pc}{sign}"] = {"idx": [int(i) for i in idx], "conditions": side}
    return out


def _place_driver_labels(ax, L: np.ndarray, drivers: dict, labels, colors: dict,
                         fontsize: float = 6.5, gap_px: float = 16.0) -> list:
    """Étiquettes des protéines motrices placées hors du nuage de points, sans
    chevauchement et sans dépendance (adjustText échoue quand les étiquettes sont
    tassées contre le bord des axes) : PC1+ / PC1- en colonne à droite / à gauche,
    PC2+ / PC2- en ligne au-dessus / en dessous (deux rangées décalées si la place
    manque), chaque étiquette reliée à son point par un trait. Les étiquettes suivent
    l'ordre des points, de sorte que les traits ne se croisent pas. Les limites des
    axes sont élargies pour les contenir. Une protéine présente dans deux directions
    n'est étiquetée qu'une fois (première direction). Retourne les objets annotation."""
    fig = ax.figure
    x0, x1 = float(np.min(L[:, 0])), float(np.max(L[:, 0]))
    y0, y1 = float(np.min(L[:, 1])), float(np.max(L[:, 1]))
    W, H = (x1 - x0) or 1.0, (y1 - y0) or 1.0
    seen, grp = set(), {}
    for d in ("PC1+", "PC1-", "PC2+", "PC2-"):
        grp[d] = [int(i) for i in drivers.get(d, {}).get("idx", []) if int(i) not in seen]
        seen.update(grp[d])
    if not seen:
        return []
    rend = fig.canvas.get_renderer()
    size = {}
    for i in seen:
        t = ax.text(0, 0, labels[i], fontsize=fontsize, fontweight="bold")
        bb = t.get_window_extent(renderer=rend)
        size[i] = (bb.width, bb.height)
        t.remove()
    abb = ax.get_window_extent(renderer=rend)
    AW, AH = max(abb.width, 1.0), max(abb.height, 1.0)
    h = max(s[1] for s in size.values())
    pad = 4.0
    mx, my = 0.03 * W, 0.04 * H                  # marge entre le nuage et les étiquettes

    def _col_w(d):
        return (max(size[i][0] for i in grp[d]) + gap_px + pad) if grp[d] else 0.0

    def _limits(nrow_t, nrow_b):
        ext_x = _col_w("PC1-") + _col_w("PC1+")
        ext_y = sum((n * 1.35 * h + gap_px + pad) if n else 0.0 for n in (nrow_t, nrow_b))
        rx = (W + 2 * mx) / max(1.0 - ext_x / AW, 0.35)      # plage x (données)
        ry = (H + 2 * my) / max(1.0 - ext_y / AH, 0.35)
        return rx / AW, ry / AH                               # données par pixel

    def _rows(d, sx):          # 1 rangée si les étiquettes tiennent sur la largeur, sinon 2
        if not grp[d]:
            return 0
        slot_px = (W / len(grp[d])) / sx
        return 1 if max(size[i][0] for i in grp[d]) + 6 <= slot_px else 2

    sx, sy = _limits(1 if grp["PC2+"] else 0, 1 if grp["PC2-"] else 0)
    nt, nb = _rows("PC2+", sx), _rows("PC2-", sx)
    sx, sy = _limits(nt, nb)
    nt, nb = _rows("PC2+", sx), _rows("PC2-", sx)             # stable après 2 passes
    sx, sy = _limits(nt, nb)
    ax.set_xlim(x0 - mx - _col_w("PC1-") * sx, x1 + mx + _col_w("PC1+") * sx)
    ax.set_ylim(y0 - my - ((nb * 1.35 * h + gap_px + pad) * sy if nb else 0.0),
                y1 + my + ((nt * 1.35 * h + gap_px + pad) * sy if nt else 0.0))

    arrow = dict(arrowstyle="-", color="grey", lw=0.4, shrinkA=0, shrinkB=2)
    out = []

    def _ann(i, tx, ty, ha, va):
        out.append(ax.annotate(labels[i], xy=(L[i, 0], L[i, 1]), xytext=(tx, ty),
                               textcoords="data", ha=ha, va=va, fontsize=fontsize,
                               fontweight="bold", color=colors.get(i, "#333333"),
                               arrowprops=arrow, zorder=5, annotation_clip=False))

    dy = 1.45 * h * sy
    for d, xt, ha in (("PC1+", x1 + mx + gap_px * sx, "left"),
                      ("PC1-", x0 - mx - gap_px * sx, "right")):
        idx = sorted(grp[d], key=lambda i: -L[i, 1])          # de haut en bas
        if not idx:
            continue
        span = dy * (len(idx) - 1)
        top_y = float(np.mean(L[idx, 1])) + span / 2
        top_y = min(max(top_y, y0 + span), y1) if span <= H else y1
        for k, i in enumerate(idx):
            _ann(i, xt, top_y - k * dy, ha, "center")
    for d, yt, va, sgn in (("PC2+", y1 + my + gap_px * sy, "bottom", 1),
                           ("PC2-", y0 - my - gap_px * sy, "top", -1)):
        idx = sorted(grp[d], key=lambda i: L[i, 0])           # de gauche à droite
        if not idx:
            continue
        nrow = nt if d == "PC2+" else nb
        slot = W / len(idx)
        for k, i in enumerate(idx):
            yk = yt + sgn * (k % 2 if nrow == 2 else 0) * 1.35 * h * sy
            _ann(i, x0 + (k + 0.5) * slot, yk, "center", va)
    return out


def plot_pca_loadings(mat_imp: pd.DataFrame, meta: pd.DataFrame, design: pd.DataFrame,
                      df_results: pd.DataFrame, contrast_names: list,
                      cluster_mapping: list, params: dict, out_dir: str,
                      n_drivers: "int | None" = None):
    """Score plot (échantillons) et loading plot (protéines) côte à côte, sur la même
    PCA que plot_pca : une protéine à droite en B est plus abondante dans les
    échantillons à droite en A.

    Couleur des protéines :
      - un seul contraste (2 conditions) : règle des volcanos (plus abondante dans
        A / dans B / non significative) ;
      - sinon : protéines significatives à l'ANOVA colorées par la condition où
        elles sont le plus abondantes (couleurs du score plot) ; gris = non
        significatives. Le cluster de la heatmap ANOVA est donné dans la table.
    Protéines motrices : les n_drivers (clé pca_n_drivers, défaut 20) aux loadings les
    plus extrêmes, répartis entre les quatre directions PC1+, PC1-, PC2+, PC2- ; elles
    sont cerclées et étiquetées, et listées sous la figure avec leur description et
    les conditions situées de ce côté du score plot.
    Retourne (figure, loadings PC1-PC3 par protéine, scores PC1-PC3 par échantillon) ;
    (None, None, None) en cas d'échec. Les deux tables sont écrites dans l'Excel
    (PCA_Loadings, PCA_Scores) et relues par le dashboard (même PCA, mêmes axes)."""
    try:
        fit = _pca_fit(mat_imp)
    except Exception as e:                                            # noqa: BLE001
        print(f"  [WARN] PCA loadings skipped ({type(e).__name__}: {e})")
        return None, None, None
    coords, var_exp, L = fit["coords"], fit["var_exp"], fit["loadings"]
    if L.shape[1] < 2:
        return None, None, None
    def _txt(s):
        # Cellules vides -> "" : avec pandas >= 3, astype(str) garde les NaN (float)
        # au lieu de les écrire "nan" ; fillna avant la conversion couvre les deux.
        return (pd.Series(s).fillna("").astype(str).str.strip()
                .replace({"nan": "", "None": "", "NaN": ""}).to_numpy(dtype=object))

    names = (_txt(meta["name"]) if "name" in meta.columns
             else np.asarray(mat_imp.index).astype(str).astype(object))
    genes = _txt(meta["Genes"]) if "Genes" in meta.columns else names
    genes = np.array([g.split(";")[0].strip() for g in genes], dtype=object)
    genes = np.where(genes == "", names, genes)
    desc_col = next((c for c in ("First.Protein.Description", "Protein.Names")
                     if c in meta.columns), None)
    descs = (_txt(meta[desc_col]) if desc_col
             else np.full(len(names), "", dtype=object))
    if n_drivers is None:
        n_drivers = int(params.get("pca_n_drivers", 20) or 0)

    # --- groupes de protéines ---
    group = np.full(len(names), "", dtype=object)
    two_cols = {}
    if len(contrast_names) == 1 and f"{contrast_names[0]}_diff" in df_results.columns:
        c = contrast_names[0]
        a_cond, b_cond = c.split("_vs_")
        _, _, _, up, down = volcano_status(df_results, c, params)
        res_names = df_results["name"].astype(str).values
        status = dict(zip(res_names, np.where(up, f"Higher in {a_cond}",
                                              np.where(down, f"Higher in {b_cond}", ""))))
        group = np.array([status.get(n, "") for n in names], dtype=object)
        palette = {f"Higher in {a_cond}": "#E74C3C", f"Higher in {b_cond}": "#3498DB"}
        two_cols = {a_cond: "#E74C3C", b_cond: "#3498DB"}     # mêmes couleurs en A et B
        grey_label = "No change (volcano rule)"
        rule = (f"{'p.adj' if params['volcano_use_padj'] else 'p.value'} < "
                f"{params['volcano_p_thresh']} & ratio >= {params['volcano_ratio_min']}")
    else:
        # protéines significatives à l'ANOVA, colorées par la condition où leur
        # abondance moyenne est maximale (mêmes couleurs que le score plot A)
        cm = dict(cluster_mapping or [])
        sig = np.array([n in cm for n in names])
        conds_u = list(dict.fromkeys(design["condition"].values))
        X = mat_imp.values
        means = np.column_stack([np.nanmean(X[:, design["condition"].values == c], axis=1)
                                 for c in conds_u])
        peak = np.array(conds_u, dtype=object)[np.nanargmax(np.nan_to_num(means, nan=-np.inf),
                                                            axis=1)]
        group = np.where(sig, peak, "").astype(object)
        cmap_c = _condition_colors(design["condition"].values)
        palette = {f"{c}": cmap_c[c] for c in conds_u}
        grey_label = "Not significant (ANOVA)"
        rule = "colour = condition of highest abundance"

    drivers = pca_drivers(L, coords, design["condition"].values, n_drivers)
    drv_tag = np.full(len(names), "", dtype=object)
    for d, info in drivers.items():
        for r, i in enumerate(info["idx"], 1):
            drv_tag[i] = (drv_tag[i] + "; " if drv_tag[i] else "") + f"{d} #{r}"
    loadings = pd.DataFrame({"name": names, "Genes": genes, "Description": descs,
                             **{f"PC{k + 1}_loading": L[:, k] for k in range(min(3, L.shape[1]))},
                             "group": np.where(group == "", grey_label, group),
                             "driver": drv_tag})
    if cluster_mapping:
        loadings["ANOVA_cluster"] = pd.Series(names).map(dict(cluster_mapping)).fillna("").values
    loadings["PC1_PC2_norm"] = np.hypot(L[:, 0], L[:, 1])

    conditions = design["condition"].values
    labels = design["label"].values
    cmap = _condition_colors(conditions)
    if len(contrast_names) == 1 and set(two_cols) >= set(conditions):
        cmap = dict(two_cols)
    n_per = max((len(v["idx"]) for v in drivers.values()), default=0)
    h_tab = (0.3 + 0.15 * n_per) if n_per else 0
    fig = plt.figure(figsize=(16.5, 6.5 + h_tab))
    gs = fig.add_gridspec(2 if n_per else 1, 2, width_ratios=[1, 1.25],
                          height_ratios=[6.5, h_tab] if n_per else [1], hspace=0.28)
    axA, axB = fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1])
    # A — échantillons
    for cond in dict.fromkeys(conditions):
        m = conditions == cond
        axA.scatter(coords[m, 0], coords[m, 1], color=cmap[cond], label=cond, s=55,
                    alpha=0.9, zorder=3)
    s_txt = [axA.text(xi, yi, li, fontsize=6, alpha=0.75, zorder=4)
             for xi, yi, li in zip(coords[:, 0], coords[:, 1], labels)]
    axA.axhline(0, color="grey", lw=0.5); axA.axvline(0, color="grey", lw=0.5)
    axA.set_xlabel(f"PC1 ({var_exp[0]*100:.1f}% of variance)")
    axA.set_ylabel(f"PC2 ({var_exp[1]*100:.1f}%)")
    axA.set_title("A. Score plot — samples", loc="left", fontweight="bold")
    axA.legend(fontsize=7, loc="best", framealpha=0.85,
               ncol=1 if len(set(conditions)) <= 8 else 2)

    # B — protéines
    grey = group == ""
    axB.scatter(L[grey, 0], L[grey, 1], s=4, color="#C8C8C8", alpha=0.5, lw=0,
                label=f"{grey_label} ({int(grey.sum())})", rasterized=True, zorder=1)
    for g, col in palette.items():
        m = group == g
        if m.any():
            axB.scatter(L[m, 0], L[m, 1], s=9, color=col, alpha=0.8, lw=0,
                        label=f"{g} ({int(m.sum())})", rasterized=True, zorder=2)
    def _dark(c):              # couleurs claires de tab20 illisibles en texte : assombries
        r, g, b_ = matplotlib.colors.to_rgb(c)
        return (r * 0.6, g * 0.6, b_ * 0.6)
    top = sorted({int(i) for v in drivers.values() for i in v["idx"]})
    if top:
        axB.scatter(L[top, 0], L[top, 1], s=34, facecolors="none", edgecolors="black",
                    linewidths=0.8, zorder=4, label=f"Driving proteins ({len(top)})")
    axB.axhline(0, color="grey", lw=0.5); axB.axvline(0, color="grey", lw=0.5)
    axB.set_xlabel("Loading on PC1"); axB.set_ylabel("Loading on PC2")
    axB.set_title(f"B. Loading plot — proteins ({rule})", loc="left", fontweight="bold")
    axB.legend(fontsize=7, loc="upper left", bbox_to_anchor=(1.01, 1), framealpha=0.85,
               markerscale=2, borderaxespad=0)
    if n_per:
        axT = fig.add_subplot(gs[1, :]); axT.axis("off")
        for j, (d, info) in enumerate(drivers.items()):
            x0 = j / 4
            side = ", ".join(info["conditions"])
            axT.text(x0, 1.0, f"{d}  (→ {side})" if side else d, transform=axT.transAxes,
                     fontsize=7.5, fontweight="bold", va="top")
            for r, i in enumerate(info["idx"], 1):
                d_txt = descs[i] if len(descs[i]) <= 34 else descs[i][:33] + "…"
                axT.text(x0, 1.0 - r / (n_per + 0.6),
                         f"{r}. {genes[i]}  {d_txt}", transform=axT.transAxes, fontsize=6.5,
                         va="top", color=_dark(palette.get(group[i], "#555555")))
    fig.text(0.5, 0.0, "Same PCA, same axes: a protein on the right in B is more abundant in "
             "the samples on the right in A (and likewise for the other directions). Circled: "
             "the proteins with the most extreme loadings in each direction (listed below, "
             "with the conditions lying on that side of the score plot).",
             ha="center", va="top", fontsize=8, color="#555555")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            fig.tight_layout(rect=[0, 0.02, 1, 1])
    except Exception:                                                 # noqa: BLE001
        pass
    # après tight_layout : les placements sont calculés sur la taille finale des axes
    try:                        # réplicats groupés : étiquettes d'échantillons écartées
        from adjustText import adjust_text
        adjust_text(s_txt, x=coords[:, 0], y=coords[:, 1], ax=axA,
                    arrowprops=dict(arrowstyle="-", color="grey", lw=0.3))
    except Exception:                                                 # noqa: BLE001
        from matplotlib.transforms import ScaledTranslation
        for t in s_txt:         # sans adjustText : décalage fixe de 3 pt, comme avant
            t.set_transform(axA.transData
                            + ScaledTranslation(3 / 72, 3 / 72, fig.dpi_scale_trans))
    if top:
        _place_driver_labels(axB, L, drivers, genes,
                             {i: _dark(palette.get(group[i], "#555555")) for i in top})
    f = os.path.join(out_dir, "plot_pca_loadings.png")
    fig.savefig(f, dpi=150, bbox_inches="tight")
    plt.close(fig)
    loadings = loadings.sort_values("PC1_PC2_norm", ascending=False).reset_index(drop=True)
    npc = min(3, coords.shape[1])
    scores = pd.DataFrame({"label": labels, "condition": conditions,
                           **{f"PC{k + 1}": coords[:, k] for k in range(npc)},
                           **{f"PC{k + 1}_var_pct": float(var_exp[k] * 100) for k in range(npc)}})
    return f, loadings, scores


def _draw_ellipse(ax, x, y, color, alpha=0.2, level=0.95):
    """Ellipse de confiance sur données 2D."""
    from matplotlib.patches import Ellipse
    from scipy.stats import chi2
    cov = np.cov(x, y)
    vals, vecs = np.linalg.eigh(cov)
    order = vals.argsort()[::-1]
    vals, vecs = vals[order], vecs[:, order]
    angle = np.degrees(np.arctan2(*vecs[:, 0][::-1]))
    chi2_val = chi2.ppf(level, df=2)
    width, height = 2 * np.sqrt(vals * chi2_val)
    ell = mpatches.Ellipse(xy=(x.mean(), y.mean()),
                           width=width, height=height,
                           angle=angle, color=color, alpha=alpha)
    ax.add_patch(ell)


# ==============================================================================
# 8. HEATMAP DE CORRÉLATION
# ==============================================================================

def plot_correlation_heatmap(mat_imp: pd.DataFrame, design: pd.DataFrame,
                              out_dir: str) -> str:
    """Heatmap de corrélation de Pearson inter-échantillons."""
    corr = np.corrcoef(mat_imp.values.T)  # (n_samples × n_samples)
    labels = design["label"].values
    conditions = design["condition"].values
    cmap = _condition_colors(conditions)

    fig, ax = plt.subplots(figsize=(max(8, len(labels) * 0.45),
                                    max(7, len(labels) * 0.4)))
    im = ax.imshow(corr, cmap="RdBu_r", vmin=corr.min() * 0.95, vmax=1.0)

    # Annotations
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, f"{corr[i,j]:.2f}", ha="center", va="center",
                    fontsize=max(5, 8 - len(labels) // 5), color="black")

    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=90, fontsize=7)
    ax.set_yticklabels(labels, fontsize=7)

    # Barre de couleur condition (annotation en haut)
    for j, cond in enumerate(conditions):
        ax.add_patch(mpatches.Rectangle((j - 0.5, -1.5), 1, 0.8,
                                         color=cmap[cond], clip_on=False))

    plt.colorbar(im, ax=ax, fraction=0.03)
    ax.set_title("Pearson correlation between samples")
    fig.tight_layout()
    f = os.path.join(out_dir, "heatmap_correlation.png")
    fig.savefig(f, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return f


# ==============================================================================
# 9. UMAP
# ==============================================================================

def plot_umap(mat_imp: pd.DataFrame, meta: pd.DataFrame,
              design: pd.DataFrame, out_dir: str) -> str:
    """UMAP sur la matrice imputée transposée (échantillons en lignes)."""
    expr = mat_imp.T.values
    imp  = SimpleImputer(strategy="mean")
    expr_imp = imp.fit_transform(expr)

    n_samples = expr_imp.shape[0]
    # L'initialisation spectrale de UMAP exige plus de points que de
    # dimensions (k >= N -> TypeError) : sous 5 échantillons, UMAP n'a de
    # toute façon pas de sens -> étape sautée, sans interrompre le pipeline.
    if n_samples < 5:
        print(f"  [SKIP] UMAP : {n_samples} échantillons (minimum 5).")
        return None, None
    n_neighbors = min(5, n_samples - 1)

    cfg = umap.UMAP(n_neighbors=n_neighbors, min_dist=0.1, random_state=42)
    try:
        emb = cfg.fit_transform(expr_imp)
    except Exception as e:
        print(f"  [SKIP] UMAP ({type(e).__name__}: {str(e)[:70]}) — pipeline continue.")
        return None, None

    conditions = design["condition"].values
    labels     = design["label"].values
    cmap       = _condition_colors(conditions)

    fig, ax = plt.subplots(figsize=(11, 7))
    for cond in np.unique(conditions):
        mask = conditions == cond
        ax.scatter(emb[mask, 0], emb[mask, 1],
                   color=cmap[cond], label=cond, s=60, alpha=0.85, zorder=3)
        for xi, yi, li in zip(emb[mask, 0], emb[mask, 1], labels[mask]):
            ax.annotate(li, (xi, yi), fontsize=6, alpha=0.7,
                        xytext=(3, 3), textcoords="offset points")

    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")
    n_prot = mat_imp.shape[0]
    n_cond = len(np.unique(conditions))
    ax.set_title(f"Proteome UMAP projection\n"
                 f"n = {n_prot} proteins | {n_cond} conditions")
    ax.legend(fontsize=7, bbox_to_anchor=(1.01, 1), loc="upper left")
    fig.tight_layout()
    f = os.path.join(out_dir, "umap_plot.png")
    fig.savefig(f, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("  [OK] UMAP generated")
    # Coordonnées UMAP par échantillon (pour la feuille Excel + dashboard)
    umap_coords = pd.DataFrame({
        "label":     labels,
        "condition": conditions,
        "UMAP1":     emb[:, 0],
        "UMAP2":     emb[:, 1],
    })
    return f, umap_coords


# ==============================================================================
# 10. ANOVA GLOBALE + HEATMAPS
# ==============================================================================

def run_anova_heatmaps(mat_imp: pd.DataFrame, meta: pd.DataFrame,
                       design: pd.DataFrame, params: dict, out_dir: str
                       ) -> tuple[pd.DataFrame, str, str, str, np.ndarray, list]:
    """
    ANOVA one-way par protéine (F-test sur le modèle limma global).
    Heatmaps classique + clusters. Retourne les fichiers et le mapping cluster.
    """
    from scipy.stats import f as fdist

    conditions = design["condition"].values
    groups = np.unique(conditions)
    expr = mat_imp.values.astype(float)  # (n_prot × n_samples)

    # F-test par protéine (one-way ANOVA via OLS)
    n_prot, n_samp = expr.shape
    n_groups = len(groups)
    df_between = n_groups - 1
    df_within  = n_samp - n_groups

    grand_mean = expr.mean(axis=1, keepdims=True)
    ss_between = np.zeros(n_prot)
    ss_within  = np.zeros(n_prot)

    for g in groups:
        idx = np.where(conditions == g)[0]
        gm = expr[:, idx].mean(axis=1, keepdims=True)
        ss_between += len(idx) * ((gm.flatten() - grand_mean.flatten()) ** 2)
        ss_within  += ((expr[:, idx] - gm) ** 2).sum(axis=1)

    ms_between = ss_between / df_between
    ms_within  = np.maximum(ss_within / df_within, 1e-12)
    f_stat = ms_between / ms_within
    p_vals = fdist.sf(f_stat, df_between, df_within)     # exact in the tail (1 - cdf underflows)

    # BH correction
    from limma_ebayes import _bh_correction
    p_adj  = _bh_correction(p_vals)

    df_anova = meta.copy().reset_index(drop=True)
    df_anova["F.stat"]    = f_stat
    df_anova["p.value"]   = p_vals
    df_anova["p.adj"]     = p_adj
    df_anova["significant"] = False

    p_key_col = "p.adj" if params["anova_use_padj"] else "p.value"
    df_anova["significant"] = df_anova[p_key_col] < params["anova_p_thresh"]
    df_anova = df_anova.sort_values("p.value").reset_index(drop=True)

    sig_names = df_anova.loc[df_anova["significant"], "name"].values
    print(f"  -> ANOVA: {len(sig_names)} significant proteins "
          f"({'p.adj' if params['anova_use_padj'] else 'p.value'} < {params['anova_p_thresh']})")

    hm_classic = hm_clusters = hm_violin = None
    cluster_mapping = []
    mat_zscore = None

    if len(sig_names) > 0:
        sig_idx = meta.index[meta["name"].isin(sig_names)].tolist()
        mat_sig = expr[sig_idx, :]
        mat_z   = (mat_sig - mat_sig.mean(axis=1, keepdims=True)) / np.maximum(
                   mat_sig.std(axis=1, keepdims=True), 1e-8)
        mat_zscore = mat_z

        sample_labels = design["label"].values
        cmap_cond = _condition_colors(conditions)

        # --- Heatmap classique (clustering hiérarchique pur) ---
        hm_classic = _draw_heatmap_pch(
            mat_z, sig_names, sample_labels, conditions, cmap_cond,
            title=f"ANOVA significant proteins "
                  f"(n={len(sig_names)}, {p_key_col} < {params['anova_p_thresh']})",
            out_path=os.path.join(out_dir, "heatmap_annotated.png"),
            show_row_names=len(sig_names) <= 80
        )

        # --- Heatmap clusters (split par k-means) ---
        # Sécurité : au moins ~3 protéines par cluster, sinon on réduit le
        # nombre de clusters (évite les clusters vides/singletons qui font
        # planter le dendrogramme de PyComplexHeatmap).
        n_sig = len(sig_names)
        n_req = params.get("n_heatmap_clusters", 3)
        n_row_clusters = max(2, min(n_req, n_sig // 3)) if n_sig >= 6 else 1
        n_col_clusters = min(4, len(groups))
        if n_row_clusters < n_req:
            print(f"  [WARN] {n_sig} significant proteins -> {n_row_clusters} "
                  f"clusters (instead of {n_req}) to avoid empty clusters.")
        row_order, col_order, row_labels = _cluster_heatmap(
            mat_z, n_row_clusters, n_col_clusters
        )

        hm_clusters = _draw_heatmap_pch(
            mat_z, sig_names, sample_labels, conditions, cmap_cond,
            title=f"Clusters ANOVA (n={len(sig_names)})",
            out_path=os.path.join(out_dir, "heatmap_clusters.png"),
            show_row_names=len(sig_names) <= 80,
            row_split_labels=row_labels
        )

        # Mapping cluster → protéines
        for ci in np.unique(row_labels):
            prots_c = sig_names[row_labels == ci]
            cluster_mapping.extend([(p, f"Cluster_{ci+1}") for p in prots_c])

        df_anova["Cluster_ID"] = df_anova["name"].map(
            dict(cluster_mapping)).fillna("")

        # --- Violin / Boxplot par cluster ---
        hm_violin = _plot_cluster_violin(
            mat_z, sig_names, row_labels, conditions, design,
            out_path=os.path.join(out_dir, "plt_clusters_profiles.png")
        )

    return df_anova, hm_classic, hm_clusters, hm_violin, mat_zscore, cluster_mapping, sig_names


def _draw_heatmap_pch(mat_z, row_names, sample_labels, conditions, cmap_cond,
                      title, out_path, show_row_names=True,
                      row_split_labels=None):
    """
    Heatmap Z-score avec PyComplexHeatmap : clustering hiérarchique (lignes +
    colonnes), dendrogrammes, annotation des conditions, split optionnel par
    cluster k-means. Rendu proche de ComplexHeatmap (R).
    Repli automatique sur _draw_heatmap si PyComplexHeatmap est indisponible.
    """
    try:
        import PyComplexHeatmap as pch
    except ImportError:
        print("  [WARN] PyComplexHeatmap NOT INSTALLED -> basic heatmap without clustering.")
        print("      Install it for ComplexHeatmap-style rendering: "
              "pip install PyComplexHeatmap")
        return _draw_heatmap(mat_z, row_names, sample_labels, conditions,
                             cmap_cond, title, out_path,
                             show_row_names=show_row_names,
                             row_cluster_labels=(np.sort(row_split_labels)
                                                 if row_split_labels is not None else None))

    n_prot, n_samp = mat_z.shape
    df = pd.DataFrame(mat_z, index=list(row_names), columns=list(sample_labels))

    # Annotation des conditions (barre colorée en haut)
    cond_series = pd.Series(list(conditions), index=list(sample_labels))
    col_anno = pch.HeatmapAnnotation(
        Condition=pch.anno_simple(cond_series, colors=cmap_cond,
                                  height=4, legend=True,
                                  add_text=False),
        axis=1, verbose=0, label_side="right",
        label_kws={"fontsize": 9, "fontweight": "bold",
                   "horizontalalignment": "left"},
    )

    # Split des lignes par cluster (k-means) + annotation de cluster à gauche
    row_split = None
    left_anno = None
    if row_split_labels is not None:
        # Sécurité : si trop peu de protéines ou un cluster singleton/vide,
        # le dendrogramme par cluster plante (matrice de distance vide).
        # On désactive alors le split (heatmap simple, clustering global).
        import collections as _coll
        counts = _coll.Counter(row_split_labels)
        if len(row_split_labels) >= 6 and all(v >= 2 for v in counts.values()):
            cluster_names = [f"C{l + 1}" for l in row_split_labels]
            row_split = pd.Series(cluster_names, index=list(row_names))
            # Couleurs distinctes par cluster (palette douce)
            uniq = sorted(set(cluster_names))
            clust_palette = dict(zip(
                uniq,
                ["#5B8FF9", "#F6BD16", "#5AD8A6", "#E8684A",
                 "#9270CA", "#FF9D4D", "#269A99", "#FF99C3"][:len(uniq)]))
            left_anno = pch.HeatmapAnnotation(
                Cluster=pch.anno_simple(row_split, colors=clust_palette,
                                        height=4, legend=True, add_text=True,
                                        text_kws={"fontsize": 8, "color": "black"}),
                axis=0, verbose=0, label_side="top",
                label_kws={"fontsize": 9, "fontweight": "bold"},
            )

    fig_h = max(6, min(n_prot * 0.18 + 3, 28))
    fig_w = max(9, n_samp * 0.40 + 5)
    plt.figure(figsize=(fig_w, fig_h))
    try:
        pch.ClusterMapPlotter(
            data=df,
            top_annotation=col_anno,
            left_annotation=left_anno,
            row_cluster=True, col_cluster=True,
            row_split=row_split,
            row_split_gap=2.2,
            col_split_gap=1.2,
            # Dendrogramme de lignes affiché MÊME avec split (clustering
            # hiérarchique à l'intérieur de chaque cluster)
            row_dendrogram=True,
            col_dendrogram=True,
            show_rownames=show_row_names, show_colnames=True,
            row_names_side="right",
            cmap="RdBu_r", vmin=-2.5, vmax=2.5, center=0,
            label="Z-score", legend=True,
            xticklabels_kws={"labelrotation": 90, "labelsize": 7},
            yticklabels_kws={"labelsize": 6},
            verbose=0,
        )
        plt.suptitle(title, fontsize=12, fontweight="bold", y=1.01)
        plt.savefig(out_path, dpi=160, bbox_inches="tight",
                    facecolor="white")
        plt.close("all")
        return out_path
    except Exception as e:
        plt.close("all")
        import traceback
        print(f"  [WARN] PyComplexHeatmap failed: {type(e).__name__}: {str(e)[:150]}")
        print("      → repli sur heatmap matplotlib basique.")
        for line in traceback.format_exc().strip().splitlines()[-3:]:
            print(f"        {line.strip()}")
        return _draw_heatmap(mat_z, row_names, sample_labels, conditions,
                             cmap_cond, title, out_path,
                             show_row_names=show_row_names,
                             row_cluster_labels=(np.sort(row_split_labels)
                                                 if row_split_labels is not None else None))


def _draw_heatmap(mat_z, row_names, sample_labels, conditions, cmap_cond,
                  title, out_path, show_row_names=True, row_cluster_labels=None):
    """Heatmap Z-score matplotlib (repli si PyComplexHeatmap absent)."""
    n_prot, n_samp = mat_z.shape
    fig_h = max(6, min(n_prot * 0.18 + 2, 25))
    fig_w = max(8, n_samp * 0.35 + 3)

    fig = plt.figure(figsize=(fig_w, fig_h))
    gs  = fig.add_gridspec(2, 2, height_ratios=[0.04, 1],
                           width_ratios=[1, 0.05], hspace=0.01)
    ax_ann  = fig.add_subplot(gs[0, 0])
    ax_heat = fig.add_subplot(gs[1, 0])
    ax_cbar = fig.add_subplot(gs[1, 1])

    # Annotation condition
    cond_colors = [cmap_cond[c] for c in conditions]
    for j, col in enumerate(cond_colors):
        ax_ann.add_patch(mpatches.Rectangle((j, 0), 1, 1, color=col))
    ax_ann.set_xlim(0, n_samp)
    ax_ann.set_ylim(0, 1)
    ax_ann.axis("off")
    ax_ann.set_title(title, fontsize=9, pad=3)

    # Heatmap
    im = ax_heat.imshow(mat_z, aspect="auto", cmap="RdBu_r",
                        vmin=-2.5, vmax=2.5, interpolation="nearest")
    ax_heat.set_xticks(range(n_samp))
    ax_heat.set_xticklabels(sample_labels, rotation=90, fontsize=6)
    if show_row_names:
        ax_heat.set_yticks(range(n_prot))
        ax_heat.set_yticklabels(row_names, fontsize=6)
    else:
        ax_heat.set_yticks([])

    # Séparateurs clusters
    if row_cluster_labels is not None:
        prev = row_cluster_labels[0]
        for k, cl in enumerate(row_cluster_labels):
            if cl != prev:
                ax_heat.axhline(k - 0.5, color="white", lw=1.5)
                prev = cl

    plt.colorbar(im, cax=ax_cbar, label="Z-score")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_path


def _cluster_heatmap(mat_z, n_row_k, n_col_k):
    """K-means sur lignes et colonnes pour ordonner la heatmap clusters."""
    from sklearn.cluster import KMeans
    km_rows = KMeans(n_clusters=n_row_k, random_state=42, n_init=10)
    row_labels = km_rows.fit_predict(mat_z)
    km_cols = KMeans(n_clusters=n_col_k, random_state=42, n_init=10)
    col_labels = km_cols.fit_predict(mat_z.T)
    return np.argsort(row_labels), np.argsort(col_labels), row_labels


def _plot_cluster_violin(mat_z, row_names, row_labels, conditions, design, out_path):
    """Violin + boxplot par cluster × condition."""
    n_clusters = len(np.unique(row_labels))
    fig, axes = plt.subplots(1, n_clusters,
                             figsize=(n_clusters * 4, 5), sharey=False)
    if n_clusters == 1:
        axes = [axes]

    cmap = _condition_colors(conditions)

    for ci, ax in enumerate(axes):
        mask_prot = row_labels == ci
        data_cl = mat_z[mask_prot, :]  # (n_prot_cluster × n_samples)

        df_v = pd.DataFrame(data_cl.T, columns=row_names[mask_prot])
        df_v["condition"] = conditions
        df_v["sample"] = design["label"].values
        df_long = df_v.melt(id_vars=["condition", "sample"],
                            var_name="protein", value_name="Z_score")

        cond_order = sorted(np.unique(conditions))
        for k, cond in enumerate(cond_order):
            sub = df_long[df_long["condition"] == cond]["Z_score"].values
            if len(sub) > 1:
                parts = ax.violinplot([sub], positions=[k], widths=0.6,
                                      showmedians=False)
                for pc in parts["bodies"]:
                    pc.set_facecolor(cmap[cond])
                    pc.set_alpha(0.6)
            q1, med, q3 = np.percentile(sub, [25, 50, 75])
            ax.plot([k - 0.1, k + 0.1], [med, med], color="black", lw=2)
            ax.plot([k, k], [q1, q3], color="black", lw=1.5)

        ax.set_xticks(range(len(cond_order)))
        ax.set_xticklabels(cond_order, rotation=45, ha="right", fontsize=7)
        ax.set_title(f"Cluster {ci+1}\n(n={mask_prot.sum()} proteins)", fontsize=9)
        ax.set_ylabel("Z-score" if ci == 0 else "")

    fig.suptitle("Expression profiles by cluster", fontsize=11)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ==============================================================================
# 11. UPSET PLOT & INTERSECTIONS
# ==============================================================================

def plot_upset(df_results: pd.DataFrame, contrast_names: list,
               params: dict, out_dir: str) -> tuple[str, pd.DataFrame]:
    """UpSet plot des protéines DEP par contraste."""
    p_key = "p.adj" if params["volcano_use_padj"] else "p.val"
    thresh = params["volcano_p_thresh"]
    lfc    = params["volcano_lfc_min"]

    upset_dict = {}
    for cname in contrast_names:
        diff_col = f"{cname}_diff"
        pval_col = f"{cname}_{p_key}"
        if diff_col not in df_results.columns:
            continue
        mask_sig = ((np.abs(df_results[diff_col].values) >= lfc) &
                    (df_results[pval_col].values < thresh))
        prots = df_results.loc[mask_sig, "name"].dropna().unique().tolist()
        if prots:
            upset_dict[cname] = set(prots)

    if len(upset_dict) < 2:
        print("  [WARN] Not enough DEP contrasts for the UpSet.")
        return None, pd.DataFrame()

    all_prots = sorted(set.union(*upset_dict.values()))
    mat_bin = pd.DataFrame(
        {k: [1 if p in v else 0 for p in all_prots] for k, v in upset_dict.items()},
        index=all_prots
    )

    # UpSet plot matplotlib maison
    cnames_list = list(upset_dict.keys())
    n_sets = len(cnames_list)

    # Intersections (trier par fréquence)
    from itertools import chain
    intersection_counts = {}
    for _, row in mat_bin.iterrows():
        key = tuple(cnames_list[j] for j in range(n_sets) if row.iloc[j] == 1)
        if key:
            intersection_counts[key] = intersection_counts.get(key, 0) + 1

    top_intersections = sorted(intersection_counts.items(),
                                key=lambda x: -x[1])[:30]

    n_inter = len(top_intersections)
    fig = plt.figure(figsize=(max(14, n_inter * 0.5), 8))
    gs  = fig.add_gridspec(2, 2, width_ratios=[1, 4], height_ratios=[2, 1], hspace=0.05)

    ax_bar  = fig.add_subplot(gs[0, 1])
    ax_mat  = fig.add_subplot(gs[1, 1])
    ax_sets = fig.add_subplot(gs[1, 0])

    # Barplot intersections
    bar_vals = [v for _, v in top_intersections]
    ax_bar.bar(range(n_inter), bar_vals, color="#2C3E50", edgecolor="none")
    ax_bar.set_ylabel("Number of DEP proteins")
    ax_bar.set_xticks([])
    ax_bar.set_title("UpSet Plot — DEP intersections")

    # Matrice points
    ax_mat.set_xlim(-0.5, n_inter - 0.5)
    ax_mat.set_ylim(-0.5, n_sets - 0.5)
    ax_mat.set_yticks(range(n_sets))
    ax_mat.set_yticklabels([c[:25] for c in cnames_list], fontsize=6)
    ax_mat.set_xticks([])

    for xi, (keys, _) in enumerate(top_intersections):
        active = [cnames_list.index(k) for k in keys if k in cnames_list]
        for yi in active:
            ax_mat.scatter(xi, yi, s=50, c="#2C3E50", zorder=3)
        if len(active) > 1:
            ax_mat.plot([xi, xi], [min(active), max(active)],
                        color="#2C3E50", lw=2, zorder=2)

    # Barplot sets
    set_sizes = [len(upset_dict[c]) for c in cnames_list]
    ax_sets.barh(range(n_sets), set_sizes, color="#3498DB")
    ax_sets.invert_xaxis()
    ax_sets.set_yticks([])
    ax_sets.set_xlabel("Total DEP")

    fig.tight_layout()
    f_upset = os.path.join(out_dir, "upset_plot.png")
    fig.savefig(f_upset, dpi=150, bbox_inches="tight")
    plt.close(fig)

    # Tableau d'intersections
    mat_bin["Nb_Conditions"] = mat_bin.sum(axis=1)
    mat_bin_X = mat_bin.copy()
    for col in cnames_list:
        mat_bin_X[col] = mat_bin_X[col].map({1: "X", 0: ""})
    mat_bin_X = mat_bin_X.sort_values("Nb_Conditions", ascending=False).reset_index()
    mat_bin_X = mat_bin_X.rename(columns={"index": "Protein.Group"})

    print(f"  [OK] UpSet plot generated ({len(upset_dict)} contrasts with DEP)")
    return f_upset, mat_bin_X


# ==============================================================================
# 12. EXPORT EXCEL
# ==============================================================================

def build_mm_sheet(ws):
    """
    Feuille 'M&M_Amont' (préparation d'échantillons, LC-MS/MS, DIA-NN) au format
    structuré, placée en première position du classeur. Champ 'Base de données'
    (espèce) à renseigner selon le projet.
    """
    from openpyxl.styles import Alignment, Border, Side
    C_TITLE, C_SECTION, C_HDRTXT, C_ELEM = "2C3E50", "34495E", "7F8C8D", "ECF0F1"
    f_title   = Font(bold=True, size=14, color="FFFFFF")
    f_sub     = Font(bold=False, size=9, color=C_HDRTXT)
    f_section = Font(bold=True, size=11, color="FFFFFF")
    f_hdr     = Font(bold=True, size=9, color=C_HDRTXT)
    f_elem    = Font(bold=True, size=10)
    f_val     = Font(bold=False, size=11)
    fill_title   = PatternFill("solid", fgColor=C_TITLE)
    fill_section = PatternFill("solid", fgColor=C_SECTION)
    fill_elem    = PatternFill("solid", fgColor=C_ELEM)
    wrap = Alignment(wrap_text=True, vertical="top")
    wrap_center = Alignment(wrap_text=True, vertical="center")
    border = Border(bottom=Side(style="thin", color="D5DBDB"))
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 70
    state = {"row": 1}

    def title(txt, sub=None):
        r = state["row"]
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        c = ws.cell(r, 1, txt); c.font = f_title; c.fill = fill_title
        c.alignment = Alignment(vertical="center")
        ws.row_dimensions[r].height = 24
        state["row"] += 1
        if sub:
            r = state["row"]
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
            ws.cell(r, 1, sub).font = f_sub
            state["row"] += 1
        state["row"] += 1

    def section(txt):
        r = state["row"]
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        c = ws.cell(r, 1, txt); c.font = f_section; c.fill = fill_section
        c.alignment = Alignment(vertical="center")
        ws.row_dimensions[r].height = 20
        state["row"] += 1
        for col, h in enumerate(["Item", "Choice / Value", "Method / Detail"], 1):
            ws.cell(state["row"], col, h).font = f_hdr
        state["row"] += 1

    def line(elem, val, detail):
        r = state["row"]
        c1 = ws.cell(r, 1, elem); c1.font = f_elem; c1.fill = fill_elem
        c1.alignment = wrap_center; c1.border = border
        c2 = ws.cell(r, 2, val); c2.font = f_val; c2.alignment = wrap; c2.border = border
        c3 = ws.cell(r, 3, detail); c3.font = f_val; c3.alignment = wrap; c3.border = border
        state["row"] += 1

    title("SAMPLE PREPARATION, LC-MS/MS & DIA-NN — Methods & Parameters",
          "Upstream part of the LFQ proteomics workflow | TIMS-TOF HT (Bruker) · DIA-NN")

    section("1. SAMPLE PREPARATION (BIOCHEMISTRY)")
    line("Protein extraction", "Modified GASP protocol",
         "Gel-aided Sample Preparation (PMC4409837), modified version")
    line("Digestion", "Trypsin / Lys-C", "Overnight digestion at 37 °C")
    line("Desalting / concentration", "µC18 Omix (Agilent)",
         "Peptides desalted and concentrated before nano-LC analysis")

    section("2. CHROMATOGRAPHY (NANO-LC)")
    line("System", "NanoElute (Bruker Daltonics)", "UHPLC nano-flow")
    line("Injected amount", "~ 50 ng / sample", "Peptide load per injection")
    line("Trap column", "C18 PepMap 100", "5 mm × 300 µm i.d. — pre-concentration")
    line("Analytical column", "Reprosil C18 (Ionopticks)",
         "25 cm × 75 µm i.d., 1.6 µm C18 beads")
    line("Column temperature", "50 °C", "Reverse-phase separation")
    line("Mobile phases", "A: 0.1% FA / B: 0.1% FA, ACN",
         "A = 0.1% aqueous formic acid; B = 0.1% FA in ACN (v/v)")
    line("Flow rate", "250 nL/min", "Nanoflow")
    line("Gradient", "2 -> 95% B / 40 min",
         "2->15% B (15 min); ->30% (15 min); ->45% (5 min); ->95% (5 min)")

    section("3. MASS SPECTROMETRY (TIMS-TOF HT)")
    line("Instrument", "TIMS-TOF HT (Bruker Daltonics)",
         "CaptiveSpray nano-ESI source (Bruker)")
    line("Spray voltage", "1400 V", "Capillary temperature 180 °C")
    line("Mode / polarity", "PASEF DIA, positive", "Singly-charged exclusion")
    line("m/z range", "100 – 1700 m/z", "MS spectra acquisition")
    line("Mobility window", "0.75 – 1.28 1/k0", "TIMS domain")
    line("DIA scheme", "Variable windows", "Isolation windows from 350 to 1000 m/z")

    section("4. IDENTIFICATION & QUANTIFICATION (DIA-NN)")
    line("Software", "DIA-NN v2.7.0", "Search + LFQ quantification (Demichev 2019)")
    line("Database", "[!] TO BE FILLED IN (species)",
         "Protein database of the studied species — library-free / library generation")
    line("Mass / RT correction", "Automatic", "Automatic mass and retention-time correction")
    line("Fragments", "Top 6", "6 most intense fragments (identification + quantification)")
    line("Variable modifications", "N-term acetylation, Oxidation (M)", "Allowed modifications")
    line("Enzyme specificity", "Trypsin/P", "Cleavage rule")
    line("FDR", "1%", "Identification filtering")
    line("Cross-run normalization", "RT-dependent", "Cross-run normalization")

    note_r = state["row"] + 1
    ws.merge_cells(start_row=note_r, start_column=1, end_row=note_r, end_column=3)
    nc = ws.cell(note_r, 1,
        "Note: adapt the database to the studied species (highlighted field). "
        "The differential-analysis parameters (thresholds, stats, clusters) are "
        "detailed in the following 'Methods' sheet.")
    nc.font = Font(italic=True, size=9, color=C_HDRTXT); nc.alignment = wrap


def _methods_go_species_orthologs(wb, organism, n_orth: int, n_prot: int,
                                  params: dict) -> None:
    """Onglet Methods écrit avant Perseverance : la ligne 'Species' de la section GO
    indique alors l'organisme mesuré. Avec les orthologues, le GO porte sur l'espèce
    de référence : la ligne est réécrite (organisme + mode de traduction)."""
    if "Methods" not in wb.sheetnames or not organism:
        return
    ws = wb["Methods"]
    in_go = False
    for row in ws.iter_rows():
        key = str(row[0].value or "")
        if "FUNCTIONAL ENRICHMENT" in key:
            in_go = True
        elif in_go and key == "Species" and len(row) >= 3:
            measured = params.get("go_organism") or "measured species"
            row[1].value = f"{organism} (reference species, via orthologues)"
            row[2].value = (f"g:Profiler organism code of the reference species. Proteins of "
                            f"{measured} translated by reciprocal best hits (DIAMOND, "
                            f"Perseverance): {n_orth}/{n_prot} proteins with an orthologue, "
                            f"identity >= {params.get('perseverance_min_identity', 25.0)}%, "
                            f"coverage >= {params.get('perseverance_min_coverage', 50.0)}%; "
                            f"proteins without orthologue are excluded from the query and "
                            f"the background; pairs in sheet Orthologues_Perseverance")
            return


def build_methods_sheet(ws, params: dict, tsv: pd.DataFrame,
                        df_results: pd.DataFrame, sig_names, contrast_names: list,
                        design: pd.DataFrame, n_proteins_filt: int,
                        go_enabled: bool = False, go_organism: str = None,
                        n_iter: int = 100, use_deqms: bool = False):
    """
    Construit la feuille 'Méthodes & Paramètres' documentant l'ensemble du
    pipeline : étapes, méthodes statistiques, seuils choisis. Pensée pour la
    traçabilité et la rédaction de la partie Méthodes d'un article.
    """
    from openpyxl.styles import Alignment, Border, Side

    title_font   = Font(bold=True, size=14, color="FFFFFF")
    title_fill   = PatternFill("solid", fgColor="2C3E50")
    section_font = Font(bold=True, size=11, color="FFFFFF")
    section_fill = PatternFill("solid", fgColor="34495E")
    key_font     = Font(bold=True, size=10)
    key_fill     = PatternFill("solid", fgColor="ECF0F1")
    wrap         = Alignment(wrap_text=True, vertical="top")
    thin         = Side(style="thin", color="BDC3C7")
    border       = Border(left=thin, right=thin, top=thin, bottom=thin)

    p_volc = "p.adj (FDR-BH)" if params["volcano_use_padj"] else "p.value (raw)"
    p_anova = "p.adj (FDR-BH)" if params["anova_use_padj"] else "p.value (raw)"
    n_samples = len(design)
    n_cond = design["condition"].nunique()
    reps = design.groupby("condition").size()
    rep_range = f"{reps.min()}–{reps.max()}" if reps.min() != reps.max() else str(reps.min())
    n_raw = len(tsv)
    n_sig_anova = len(sig_names) if sig_names is not None else 0

    row = 1
    def put_title(text):
        nonlocal row
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=3)
        c = ws.cell(row=row, column=1, value=text)
        c.font = title_font; c.fill = title_fill
        c.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[row].height = 24
        row += 2

    def put_section(text):
        nonlocal row
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=3)
        c = ws.cell(row=row, column=1, value=text)
        c.font = section_font; c.fill = section_fill
        ws.row_dimensions[row].height = 18
        row += 1

    def put_kv(key, value, method=""):
        nonlocal row
        kc = ws.cell(row=row, column=1, value=key)
        kc.font = key_font; kc.fill = key_fill; kc.border = border
        kc.alignment = wrap
        vc = ws.cell(row=row, column=2, value=value)
        vc.alignment = wrap; vc.border = border
        mc = ws.cell(row=row, column=3, value=method)
        mc.alignment = wrap; mc.border = border
        row += 1

    def put_header():
        nonlocal row
        for col, label in [(1, "Item"), (2, "Choice / Value"), (3, "Method / Detail")]:
            c = ws.cell(row=row, column=col, value=label)
            c.font = Font(bold=True, italic=True, size=9, color="7F8C8D")
        row += 1

    # ===== TITLE =====
    put_title("LFQ PROTEOMICS PIPELINE — Methods & Parameters")
    ws.cell(row=row-1, column=1,
            value=f"Auto-generated | {n_raw} raw proteins -> "
                  f"{n_proteins_filt} after filtering | {n_samples} samples, "
                  f"{n_cond} conditions").font = Font(italic=True, size=9, color="7F8C8D")
    row += 1

    # ===== DESIGN =====
    put_section("1. EXPERIMENTAL DESIGN")
    put_header()
    put_kv("Samples", str(n_samples), "LFQ columns from the DIA-NN report")
    put_kv("Conditions", str(n_cond), ", ".join(map(str, design["condition"].unique())))
    put_kv("Replicates / condition", rep_range, "Biological replicates")
    _n_pairs = n_cond * (n_cond - 1) // 2
    put_kv("Comparisons", str(len(contrast_names)),
           "All condition pairs (pairwise combinations)" if len(contrast_names) >= _n_pairs
           else f"Selected among the {_n_pairs} condition pairs (configuration key "
                f"'contrasts'): " + ", ".join(map(str, contrast_names)))

    # ===== PREPROCESSING =====
    put_section("2. DATA PREPROCESSING")
    put_header()
    put_kv("Source", "DIA-NN pg_matrix", "LFQ intensities (label-free quantification)")
    if params.get("id_mapping_summary"):
        put_kv("Identifier mapping", "id_mapping (pg + pr_matrix)",
               params["id_mapping_summary"])
    put_kv("Contaminants", "cRAP removal", "Filter on Protein.Group / Protein.Names")
    put_kv("Transformation", "log2", "log2(intensity), zeros -> NA")
    put_kv("Filtering", ">= (n_rep - 1) values",
           "Kept if detected in all but 1 replicate of at least one condition")
    put_kv("Proteins retained", f"{n_proteins_filt} / {n_raw}",
           "After missing-value filtering")
    _imp = params.get("impute_method", "qrilc")
    if _imp == "mixed":
        put_kv("Imputation", "Mixed (MNAR + MAR)",
               "QRILC (truncated normal, Lazar 2016) for every missing value of a "
               "protein absent from all replicates of at least one condition (MNAR, "
               "below the detection limit); kNN (k=10) for proteins with partial "
               "missingness only (MAR). Classification per protein based on the design.")
    elif _imp == "mixed_legacy":
        put_kv("Imputation", "Mixed, legacy rule (MNAR + MAR)",
               "QRILC for the conditions where the protein is absent from all "
               "replicates; kNN (k=10) for partial missingness in the other "
               "conditions, including for proteins absent from a whole condition. "
               "Kept to reproduce earlier analyses: this rule can create artificial "
               "group differences (low QRILC values vs kNN values near the observed ones).")
    else:
        put_kv("Imputation", "QRILC (MNAR)",
               "Quantile Regression Imputation of Left-Censored data (Lazar 2016): "
               "draw from a truncated normal below the estimated detection limit. "
               "Suited to DIA (predominantly MNAR missingness).")
    put_kv("Imputation choice", params.get("impute_method", "qrilc").upper(),
           params.get("impute_method_reason", "set explicitly in the configuration"))
    put_kv("Random seed", str(params.get("seed", 42)),
           "Seed of the reference imputation draw (p-values, volcanos). "
           "Re-running with the same seed and inputs gives identical results.")
    if (params.get("_primary") or {}).get("statistic") == "dpc":
        put_kv("Imputed matrix used for", "secondary analyses",
               "Imputed analysis kept in *_imputed columns, PCA, UMAP, correlation, "
               "ANOVA heatmaps and WGCNA. The primary differential statistic does not "
               "use it (section 3).")

    # ===== DIFFERENTIAL ANALYSIS =====
    put_section("3. DIFFERENTIAL ANALYSIS (Volcanos)")
    put_header()
    # Detect whether DEqMS is authoritative (presence of secondary limma columns)
    _deqms_active = any(str(c).endswith("_p.adj_limma") for c in df_results.columns)
    _prim = params.get("_primary") or {}
    if _prim.get("statistic") == "dpc":
        _d = _prim.get("dpc_precursor") or {}
        put_kv("Primary statistic", "Imputation-free DPC + weighted limma (limpa method)",
               "Detection probability curve (DPC) on the precursor matrix (report.pr_matrix): "
               f"logit p = {_d.get('beta0', float('nan')):.3f} + "
               f"{_d.get('beta1', float('nan')):.3f} y (50 % detection at log2 "
               f"{-_d.get('beta0', 0) / _d.get('beta1', 1):.2f}), complete-normal model "
               "(Li & Smyth 2023, Bioinformatics 39:btad200). Protein abundances and their "
               "standard errors estimated from the precursors by maximum posterior under "
               "the DPC (additive precursor + sample model; limpa dpcQuant): undetected "
               "precursors contribute their probability of non-detection, nothing is "
               "imputed. limma with vooma precision weights predicted by intensity and "
               "standard error, residual df corrected when a whole group is unobserved "
               f"({_prim.get('n_df_corrected', 0)} protein groups), eBayes (limpa dpcDE, "
               "Li et al. 2025). Independent Python implementation, checked against "
               "limpa 1.5.2 (same significant calls). Authoritative for volcanos, UpSet, "
               "GO, GSEA, dashboard and Pathfinder.")
        if _prim.get("n_protein_level"):
            put_kv("Proteins without precursor", str(_prim["n_protein_level"]),
                   "Absent from the pr_matrix: DPC at protein level (limpa "
                   "dpcQuantByRow logic), same model and BH correction")
        put_kv("Fold-changes", "DPC estimates",
                "Weakly observed values are shrunk towards the prior: fold-changes of "
                "proteins absent from a whole condition are conservative (about 12 % "
                "compression in in-silico spike-ins); see Differential_Detection for "
                "on/off proteins")
        put_kv("Imputed analysis (secondary)",
               "DEqMS on imputed data" if _prim.get("imputed_deqms") else
               "limma eBayes on imputed data",
               "Previous primary statistic, kept for comparison: columns *_diff_imputed, "
               "*_p.val_imputed, *_p.adj_imputed"
               + (", *_p.val_imputed_limma" if _prim.get("imputed_deqms") else "")
               + ", Pi_Score_imputed_*, Robustness_Score_imputed_*")
    elif _deqms_active:
        put_kv("Primary statistic", "DEqMS",
               "Residual variance modeled as a function of peptide count "
               "(Zhu et al. 2020). Authoritative for volcanos, UpSet, GO and robustness. "
               "limma retained in secondary columns (_limma)")
        put_kv("Base model", "limma eBayes",
               "Linear regression + empirical Bayes moderation (Smyth 2004), "
               "extended by DEqMS")
    else:
        put_kv("Primary statistic", "limma eBayes",
               "Linear regression + empirical Bayes moderation (Smyth 2004). "
               "Variance moderated by information borrowing across proteins — "
               "essential for small sample sizes (n=3). "
               "DEqMS not available (no pr_matrix peptide count)")
    _dq = params.get("_deqms")
    if _dq and (_deqms_active or _prim.get("imputed_deqms")):
        put_kv("DEqMS settings", f"prior df = {_dq['df_prior']:.1f}",
               "Peptide count = minimum number of distinct peptides across the analysed "
               "samples + 1 (pseudo-count of the DEqMS LFQ vignette); prior variance from "
               "loess(log s² ~ log2 count, span 0.75) and prior df by the grid search of "
               "spectraCounteBayes, reproduced exactly (same results as R DEqMS 1.31 on "
               f"test data); loess: {_dq['engine']}")
    put_kv("Implementation", "limma_ebayes.py (Python)",
           "lmFit, contrasts.fit, eBayes (squeezeVar/fitFDist) and BH reproduced "
           "exactly: coefficients, moderated t and p-values identical to R limma 3.58 "
           "and to InMoose to 1e-12 on simulated and real datasets")
    if _prim.get("statistic") == "imputation" and _prim.get("requested") == "dpc":
        put_kv("DPC primary statistic", "not applied",
               f"primary_statistic: dpc requested, but {_prim.get('fallback') or 'not available'}; "
               "the imputed analysis is the primary statistic")
    _has_subj = any(c in design.columns for c in
                    ("subject", "pair", "patient", "individual"))
    _paired = False
    if _has_subj:
        _sc = next(c for c in ("subject", "pair", "patient", "individual")
                   if c in design.columns)
        _pp = design.groupby(_sc)["condition"].nunique()
        _paired = (_pp >= 2).any() and design[_sc].nunique() >= 2 \
                  and design[_sc].nunique() < len(design)
    _pr = pseudoreplication_check(design)
    if _pr:
        put_kv("Design check", "WARNING: pseudo-replication",
               f"{_pr['n_subjects']} subject(s) ('{_pr['subj_col']}') with several "
               f"samples in the same condition ({_pr['n_samples']} samples); "
               f"treated as independent replicates, so variance may be "
               f"underestimated and p-values optimistic"
               + ("; subjects nested in conditions (between-subject comparison)"
                  if _pr["nested"] else ""))
    if _paired:
        put_kv("Design matrix", "~0 + condition + subject",
               "Paired design: subject added as fixed effect to absorb "
               "inter-individual baseline (generalized paired t-test). "
               "Contrasts are on conditions only.")
    else:
        put_kv("Design matrix", "~0 + condition",
               "One-hot encoding of conditions")
    put_kv("Contrasts", "All pairs" if len(contrast_names) >= _n_pairs
           else f"{len(contrast_names)} selected pairs", "makeContrasts equivalent")
    put_kv("Multiple correction", "Benjamini-Hochberg",
           "Global FDR (all comparisons, one test family)"
           if params.get("fdr_global") else
           "Per-contrast FDR (one test family per comparison)")
    put_kv("Significance threshold", p_volc,
           f"Threshold = {params['volcano_p_thresh']}")
    put_kv("Fold-Change threshold",
           f"ratio >= {params['volcano_ratio_min']}",
           f"|log2FC| >= {params['volcano_lfc_min']:.3f}")
    _yax = str(params.get("volcano_y_axis", "pvalue")).lower()
    put_kv("Volcano Y axis",
           "-log10(p.value)" if (_yax == "pvalue" or not params["volcano_use_padj"])
           else "-log10(p.adj)",
           ("Raw p-value (limma volcanoplot convention); colours follow the p.adj "
            "threshold, and the dashed line sits at the raw p-value equivalent to it in "
            "each contrast (Benjamini-Hochberg is monotone in p)")
           if (_yax == "pvalue" and params["volcano_use_padj"]) else
           "Same statistic as the significance threshold")
    put_kv("Pi-score", "|log2FC| x -log10(p)",
           "Combined magnitude x significance score (Xiao et al.). "
           "Uses the p-value of the primary statistic.")

    # ===== ROBUSTNESS =====
    put_section("4. ROBUSTNESS SCORE")
    put_header()
    if _prim.get("statistic") == "dpc" and _prim.get("robustness"):
        put_kv("Principle", "Leave-one-sample-out (DPC statistic)",
               "For each contrast, the DPC analysis is refitted after removing, in turn, "
               "each sample of the two compared conditions (abundances and standard "
               "errors of the full quantification kept). No random draw is involved in "
               "the DPC statistic, so the re-imputation score has no direct equivalent"
               + (f"; {_prim['loo_skipped']} sample(s) skipped (design not estimable "
                  "without them)" if _prim.get("loo_skipped") else ""))
        put_kv("Applied thresholds", p_volc + f" < {params['volcano_p_thresh']} "
               f"& ratio >= {params['volcano_ratio_min']}",
               "IDENTICAL to the volcano thresholds (consistency)")
        put_kv("Score", "0-100",
               "Percentage of the refits where the protein still passes the thresholds. "
               "High score = call not driven by a single sample (outlier injection, "
               "one replicate carrying the effect)")
        put_kv("Imputation robustness", f"{n_iter} re-imputations",
               f"Stability of the secondary imputed analysis "
               f"({params.get('impute_method', 'qrilc').upper()}), columns "
               "Robustness_Score_imputed_* (0-" + str(n_iter) + ")")
    else:
        put_kv("Principle", f"{n_iter} re-imputations",
               f"Repeated stochastic imputation ({params.get('impute_method', 'qrilc').upper()}, "
               f"same method as the reference draw; base seed={params.get('seed', 42)}), "
               "model re-estimation at each iteration to assess stability against "
               "missing-value imputation uncertainty")
        put_kv("Applied thresholds", p_volc + f" < {params['volcano_p_thresh']} "
               f"& ratio >= {params['volcano_ratio_min']}",
               "IDENTICAL to the volcano thresholds (consistency)")
        put_kv("Score", f"0-{n_iter}",
               f"Number of iterations (out of {n_iter}) where the protein passes the "
               "thresholds. High score = differential robust to imputation uncertainty")

    # ===== ANOVA / HEATMAPS =====
    put_section("5. ANOVA & HEATMAPS")
    put_header()
    put_kv("Test", "One-way ANOVA (F-test)",
           "Per protein, on the condition factor")
    put_kv("Multiple correction", "Benjamini-Hochberg",
           "Across proteins (one F-test per protein)")
    put_kv("Significance threshold", p_anova,
           f"Threshold = {params['anova_p_thresh']} (independent of the volcanos)")
    put_kv("Significant proteins", str(n_sig_anova),
           "Proteins retained for the heatmaps")
    put_kv("Standardization", "Per-row Z-score",
           "Per-protein centering-scaling before clustering")
    put_kv("Clustering", "K-means (rows & columns)",
           "Clustered heatmap: structure of expression profiles")

    # ===== EXPLORATORY ANALYSES =====
    put_section("6. EXPLORATORY ANALYSES")
    put_header()
    put_kv("PCA", "PCA on imputed data",
           "Standardized, 95% confidence ellipses (normal distribution)")
    put_kv("PCA loadings", "Score plot + loading plot (same PCA)",
           "Protein loadings = eigenvector components on PC1/PC2 (sheet PCA_Loadings, PC1-PC3): "
           "a protein on the right of the loading plot is more abundant in the samples on the "
           "right of the score plot. Colours: ANOVA-significant proteins by the condition "
           "where they are most abundant, as in the score plot (one contrast: volcano rule). "
           f"Driving proteins: the {int(params.get('pca_n_drivers', 20) or 0)} most extreme "
           "loadings, split between PC1+, PC1-, PC2+ and PC2- (column 'driver')")
    if params.get("export_matrices", True):
        put_kv("Matrices (other analyses)", "folder matrices/ (TSV)",
               "Protein x sample matrices for Mfuzz, MOFA+/MEFISTO or multi-omics "
               "integration: log2 with NA (no imputation), log2 imputed, DPC abundances "
               "with standard errors and observed flags, DPC condition means, sample "
               "table; no normalisation beyond DIA-NN (see README_matrices.txt)")
    put_kv("UMAP", "n_neighbors=5, min_dist=0.1",
           "Non-linear projection, seed=42 (reproducible)")
    put_kv("Correlation", "Pearson between samples",
           "Quality control of replicate consistency")
    put_kv("UpSet", "DEP intersections",
           "Significant proteins shared across comparisons "
           "(volcano thresholds)")

    # ===== WGCNA =====
    put_section("7. WGCNA (Co-expression)")
    put_header()
    put_kv("Network", "Unsigned",
           "Adjacency = |Pearson correlation|^beta: positively and negatively "
           "correlated proteins can belong to the same module")
    put_kv("Soft power (beta)", "Auto (R2 >= 0.80)",
           "Selected by scale-free topology fit")
    put_kv("Similarity", "TOM",
           "Topological Overlap Matrix")
    put_kv("Modules", "Hierarchical clustering",
           "Average linkage on TOM dissimilarity + dynamic tree cut")
    put_kv("Module merging", "1 - cor(ME) < 0.25",
           "Merge modules with similar eigengenes")
    put_kv("Hub score", "kME",
           "Protein <-> module eigengene correlation")
    put_kv("Trait correlation", "Pearson module <-> condition",
           "Module-trait relationship")

    # ===== GO (if enabled) =====
    if go_enabled:
        put_section("8. FUNCTIONAL ENRICHMENT (GO)")
        put_header()
        if params.get("go_backend", "gprofiler") == "string":
            _bg = params.get("string_background") or params.get("enrichment_background",
                                                                  "quantified")
            _cats = params.get("string_categories") or ["Process", "Function",
                                                         "Component", "KEGG", "RCTM"]
            put_kv("Tool", "STRING (API 'enrichment')",
                   "Over-representation enrichment (Szklarczyk et al.)")
            put_kv("Species", f"NCBI taxid {params.get('go_species_taxid')}",
                   (f"{params['go_species_name']} — resolved automatically from "
                    f"the accessions (UniProt taxonomy, checked in STRING)"
                    if params.get("go_species_name")
                    else "Organism identified by NCBI Taxonomy ID"))
            put_kv("Sources", ", ".join(_cats),
                   "STRING categories (Process/Function/Component/RCTM "
                   "relabelled GO:BP/GO:MF/GO:CC/REAC)")
            if params.get("go_string_mode") == "ortholog":
                put_kv("ID mapping", "Orthology (reciprocal best hits, DIAMOND)",
                       f"{params.get('go_string_strain') or 'Run proteins'} -> STRING "
                       f"proteome taxid {params.get('go_species_taxid')} "
                       f"(accessions not indexed in STRING); identity >= "
                       f"{params.get('perseverance_min_identity', 25.0)}%, coverage >= "
                       f"{params.get('perseverance_min_coverage', 50.0)}%; "
                       f"pairs in sheet Orthologues_STRING")
            else:
                put_kv("ID mapping", "get_string_ids (1st accession of the group)",
                       "Unresolved accessions excluded from the query")
            put_kv("Input list", "DEP per contrast",
                   f"Proteins passing {p_volc} < {params['volcano_p_thresh']} "
                   f"& ratio >= {params['volcano_ratio_min']} (volcano thresholds)")
            put_kv("Background", ("quantified proteins" if _bg == "quantified"
                                  else "whole genome"),
                   ("background_string_identifiers = all quantified proteins "
                    "resolved by STRING" if _bg == "quantified"
                    else "STRING default (whole annotated genome)"))
            put_kv("Multiple correction", "FDR (Benjamini-Hochberg, STRING)",
                   "STRING 'fdr' field, threshold 0.05")
        else:
            put_kv("Tool", "g:Profiler (gost)",
                   "Over-representation enrichment")
            put_kv("Species", str(go_organism), "g:Profiler organism code")
            put_kv("Sources", "GO:BP, GO:CC, GO:MF, REAC, KEGG",
                   "Gene Ontology + Reactome + KEGG")
            put_kv("Input list", "DEP per contrast",
                   f"Proteins passing {p_volc} < {params['volcano_p_thresh']} "
                   f"& ratio >= {params['volcano_ratio_min']} (volcano thresholds)")
            _gbg = params.get("enrichment_background", "quantified")
            put_kv("Background", ("quantified proteins" if _gbg == "quantified"
                                  else "whole annotated genome"),
                   ("custom background = all proteins tested in the differential "
                    "analysis (or their orthologues), restricted to annotated genes "
                    "(domain_scope='custom_annotated'); also used for the ANOVA "
                    "cluster enrichment. Corrects the detectability bias of proteomics "
                    "(abundant categories over-called against the genome)"
                    if _gbg == "quantified" else
                    "all known genes of the species (domain_scope='known')"))
            put_kv("Multiple correction", "FDR (g:SCS disabled in favor of FDR)",
                   "significance_threshold_method='fdr'")
        put_kv("Term filters", "size 5-1000, roots excluded",
               "Exclusion of GO:0003674/0008150/0005575")
        put_kv("Z-score", "term mean log2FC",
               "Pathway regulation direction")

    _next_sec = 9 if go_enabled else 8

    # ===== SENSITIVITY TO MISSING VALUES (added analyses) =====
    _sm = params.get("_sensitivity_methods")
    if _sm:
        put_section(f"{_next_sec}. SENSITIVITY TO MISSING VALUES (complementary)")
        _next_sec += 1
        put_header()
        if _sm.get("primary_dpc"):
            put_kv("Principle", "Comparison of the two treatments of missing values",
                   "The DPC analysis is the primary statistic (section 3); the imputed "
                   "analysis is kept in *_imputed columns. Sensitivity_DPC and "
                   "Sensitivity_Summary compare their calls; Differential_Detection "
                   "tests on/off proteins.")
        else:
            put_kv("Principle", "Added to the main analysis, which is unchanged",
                   "Volcanos, robustness, GO and dashboard use the imputed analysis "
                   "above. These analyses read the filtered, NON-imputed matrix and are "
                   "reported in separate sheets (Sensitivity_Summary, Sensitivity_DPC, "
                   "Differential_Detection).")
        put_kv("Detection probability curve",
               f"logit p = {_sm['beta0']:.3f} + {_sm['beta1']:.3f} y",
               f"Probability that a protein is detected as a function of its log2 "
               f"intensity y (50 % at {_sm['lod50']:.2f}); maximum likelihood under "
               f"the complete-normal model (Li & Smyth 2023, Bioinformatics "
               f"39:btad200), on {_sm['n_rows']} protein groups before filtering")
        if _sm.get("dpc"):
            _lvl = _sm.get("level", "protein")
            put_kv("Imputation-free analysis",
                   f"DPC quantification ({_lvl} level) + weighted limma",
                   ("Protein abundances estimated from the precursor matrix "
                    "(report.pr_matrix) by maximum posterior under the precursor-level "
                    "DPC (additive precursor + sample model, method of limpa dpcQuant), "
                    "with standard errors; " if _lvl == "precursor" else
                    "Missing values replaced by their maximum posterior under the "
                    "DPC, with standard errors; ") +
                   "limma with vooma precision weights "
                   "predicted by intensity and standard error, residual df corrected "
                   "when a whole group is unobserved "
                   f"({_sm.get('n_df_corrected') or 0} protein groups), eBayes. "
                   "Method of limpa dpcQuant/dpcQuantByRow + dpcDE (Li et al. 2025), "
                   "independent Python implementation, checked against limpa 1.5.2. "
                   "Same design and contrasts as the main model.")
        if _sm.get("detection"):
            _dp = _sm.get("dropout") or {}
            put_kv("Differential detection", "On/off proteins",
                   "For each contrast: probability of the observed non-detections in "
                   "one condition if the protein had the abundance of the other. "
                   "Probability of non-detection = pi + (1 - pi) x (1 - DPC), where pi "
                   "is a protein-specific sporadic dropout rate (identification failures, "
                   "presence in some individuals only): prior estimated on this dataset "
                   "from abundant protein x condition cells (nonparametric maximum "
                   "likelihood"
                   + (f"; mean {_dp['mean']:.3f}, {100 * _dp['frac_above_0.1']:.1f} % of "
                      f"proteins with pi > 0.1" if _dp.get("mean") is not None else "")
                   + "), updated by the non-detections of the condition where the "
                   "protein is present; binomial, integrated over the uncertainty of the "
                   "abundance and of pi; two-sided, BH over all proteins of the contrast. "
                   "Listed: on/off patterns (detected in >= n-1 samples of one "
                   "condition, < half of the other) and significant pairs")
        put_kv("Concordance", f"volcano rule on both analyses ({_sm['pkey']})",
               "both / imputation only / DPC only, per protein and contrast "
               "(sheet Sensitivity_DPC); counts per contrast in Sensitivity_Summary")

    # ===== PATHFINDER (if requested and found) =====
    _pf_dir = locate_pathfinder(params) if params.get("make_pathfinder") else None
    if _pf_dir:
        put_section(f"{_next_sec}. DOWNSTREAM SYNTHESIS")
        put_header()
        _pthr = (params.get("pathfinder_options") or {}).get("pthr", 0.05)
        put_kv("Downstream synthesis", f"Pathfinder {pathfinder_version(_pf_dir)}",
               "Reads this workbook after it is saved, no recomputation; outputs in "
               "pathfinder/ (report, synthesis workbook, summary, log). Protein "
               f"signature = p.adj < {_pthr} without fold-change criterion "
               "(independent of the volcano thresholds above)")

    # ===== LARGEURS DE COLONNES =====
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 70


def export_excel(tsv: pd.DataFrame, df_results: pd.DataFrame,
                 df_anova: pd.DataFrame, df_intersections: pd.DataFrame,
                 mat_zscore: np.ndarray, meta: pd.DataFrame,
                 sig_names: np.ndarray, contrast_names: list,
                 design: pd.DataFrame, params: dict,
                 qc_files: list, pca_files: list, scatter_files: list,
                 volc_files: list, facet_volc: str, umap_file: str,
                 hm_corr: str, hm_classic: str, hm_clusters: str,
                 hm_violin: str, upset_file: str,
                 out_path: str,
                 go_enabled: bool = False, go_organism: str = None,
                 n_iter: int = 100, use_deqms: bool = False,
                 mat_imp: pd.DataFrame = None, umap_coords: pd.DataFrame = None,
                 imputation_info: pd.DataFrame = None, pca_loadings_file: str = None):
    """Assemble le classeur Excel multionglets."""
    print("\n[EXCEL] Generating the Excel file...")
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    header_fill  = PatternFill("solid", fgColor="D9D9D9")
    zscore_fill  = PatternFill("solid", fgColor="FFCC00")
    header_font  = Font(bold=True)

    def write_df(ws, df, fill=header_fill):
        ws.append(list(df.columns))
        for cell in ws[1]:
            cell.fill = fill
            cell.font = header_font
        for row in df.itertuples(index=False):
            ws.append(list(row))

    # Largeur de colonne Excel ≈ 64 px ; hauteur de ligne ≈ 20 px.
    # openpyxl 3.1 ne redimensionne pas fiablement via img.width/height ;
    # on redimensionne donc physiquement le PNG avec PIL avant insertion.
    from openpyxl.utils import get_column_letter
    _resized_cache = {}

    def _resize_png(path, max_w_px, max_h_px):
        """Crée une copie redimensionnée du PNG (ratio conservé). Retourne le chemin."""
        try:
            from PIL import Image as _PILImage
        except ImportError:
            return path  # PIL absent : on garde l'original
        key = (str(path), max_w_px, max_h_px)
        if key in _resized_cache:
            return _resized_cache[key]
        try:
            im = _PILImage.open(path)
            w, h = im.size
            scale = min(max_w_px / w, max_h_px / h, 1.0)
            if scale < 1.0:
                im = im.resize((int(w * scale), int(h * scale)),
                               _PILImage.LANCZOS)
                base, ext = os.path.splitext(str(path))
                out = f"{base}_xl{max_w_px}x{max_h_px}{ext}"
                im.save(out)
                _resized_cache[key] = out
                return out
        except Exception:
            pass
        _resized_cache[key] = path
        return path

    def insert_img(ws, path, anchor=None, *, row=None, col=None,
                   max_w_px=560, max_h_px=440):
        """Insère une image redimensionnée (PIL) pour un placement sans
        chevauchement. anchor='A1' OU (row, col) 1-based."""
        if not path or not os.path.exists(str(path)):
            return
        rpath = _resize_png(path, max_w_px, max_h_px)
        img = XLImage(str(rpath))
        if anchor is None:
            anchor = f"{get_column_letter(col)}{row}"
        ws.add_image(img, anchor)

    def img_width_cols(path, max_w_px, max_h_px, col_px=64, margin=2):
        """Largeur d'affichage finale de l'image (après redimensionnement)
        exprimée en nombre de colonnes Excel. Sert à décaler dynamiquement
        un tableau placé à droite de l'image (largeur UpSet variable)."""
        try:
            from PIL import Image as _PILImage
            rpath = _resize_png(path, max_w_px, max_h_px)
            w, _ = _PILImage.open(rpath).size
            return int(ceil(w / col_px)) + margin
        except Exception:
            return int(ceil(max_w_px / col_px)) + margin

    # Une image bornée à 560×440 px occupe ~9 colonnes et ~22 lignes.
    # On espace les ancres de 10 colonnes et 24 lignes (marge de sécurité).
    IMG_COL_STEP = 10
    IMG_ROW_STEP = 24

    # --- Feuille M&M Amont (bioch/LC-MS/DIA-NN) en TOUTE PREMIÈRE position ---
    ws = wb.create_sheet("Methods_Upstream")
    build_mm_sheet(ws)

    # --- Feuille Méthodes (pipeline aval) en SECONDE position ---
    ws = wb.create_sheet("Methods")
    build_methods_sheet(ws, params, tsv, df_results, sig_names, contrast_names,
                        design, n_proteins_filt=len(df_results),
                        go_enabled=go_enabled, go_organism=go_organism,
                        n_iter=n_iter, use_deqms=use_deqms)

    # --- Onglet raw_data ---
    ws = wb.create_sheet("raw_data")
    write_df(ws, tsv)

    # --- Onglet Log2_Impute : matrice log2 imputée, TOUTES les protéines ---
    # Valeurs log2 imputées (tirage de référence seedé) pour chaque protéine × échantillon.
    if mat_imp is not None:
        ws = wb.create_sheet("Log2_Impute")
        df_imp = mat_imp.copy()
        df_imp.columns = [str(c) for c in df_imp.columns]
        # Identifiant protéine : on aligne sur meta (même ordre que mat_filt/mat_imp)
        ids = None
        for col in ("Protein.Group", "name"):
            if col in meta.columns and len(meta) == len(df_imp):
                ids = meta[col].values
                break
        df_imp.insert(0, "Protein.Group",
                      ids if ids is not None else np.arange(len(df_imp)))
        # Ajouter Genes/description si disponibles et alignés
        for extra in ("Genes", "First.Protein.Description"):
            if extra in meta.columns and len(meta) == len(df_imp):
                df_imp.insert(1, extra, meta[extra].values)
        df_imp = df_imp.round(4)
        write_df(ws, df_imp)
        print(f"  [OK] Log2_Impute sheet: {df_imp.shape[0]} proteins x "
              f"{mat_imp.shape[1]} samples (imputed log2)")

    # --- Contrôle Qualité ---
    ws = wb.create_sheet("QC")
    for i, f in enumerate(qc_files):
        r = (i // 3) * IMG_ROW_STEP + 1
        c = (i % 3) * IMG_COL_STEP + 1
        insert_img(ws, f, row=r, col=c)

    # --- PCA + UMAP + Corrélation ---
    ws = wb.create_sheet("PCA_UMAP")
    pca_imgs = list(pca_files) + [umap_file, hm_corr]
    for i, f in enumerate(pca_imgs):
        r = (i // 2) * IMG_ROW_STEP + 1
        c = (i % 2) * IMG_COL_STEP + 1
        insert_img(ws, f, row=r, col=c)
    if pca_loadings_file:
        # figure double (échantillons | protéines) : une ligne entière, plus large
        r = ((len(pca_imgs) + 1) // 2) * IMG_ROW_STEP + 1
        insert_img(ws, pca_loadings_file, row=r, col=1, max_w_px=1150, max_h_px=500)

    # --- Feuille UMAP : coordonnées par échantillon (pour le dashboard) ---
    if umap_coords is not None and len(umap_coords) > 0:
        ws = wb.create_sheet("UMAP")
        write_df(ws, umap_coords)

    # --- Scatter Plots ---
    ws = wb.create_sheet("Scatter_Plots")
    for i, f in enumerate(scatter_files):
        r = (i // 2) * IMG_ROW_STEP + 1
        c = (i % 2) * IMG_COL_STEP + 1
        insert_img(ws, f, row=r, col=c)

    # --- Comparaison (stats différentielles) ---
    ws = wb.create_sheet("Differential_Expression")
    # Ajouter les infos d'imputation (comme le script R) si disponibles
    df_comp_src = df_results.copy()
    if imputation_info is not None and len(imputation_info) == len(df_comp_src):
        df_comp_src["imputed"] = imputation_info["imputed"].values
        df_comp_src["num_NAs"] = imputation_info["num_NAs"].values
    cols_keep = ["name", "Protein.Group", "Genes",
                 "First.Protein.Description"]
    if "N.Sequences" in df_comp_src.columns:
        cols_keep.append("N.Sequences")
    for extra in ("imputed", "num_NAs"):
        if extra in df_comp_src.columns:
            cols_keep.append(extra)
    if "Peptide_Count_min" in df_comp_src.columns:
        cols_keep.append("Peptide_Count_min")
    for extra in ("dpc_source", "n_precursors"):        # statistique principale DPC
        if extra in df_comp_src.columns:
            cols_keep.append(extra)
    for cname in contrast_names:
        # Colonnes principales (_p.val/_p.adj = DPC si primary_statistic: dpc,
        # sinon DEqMS si dispo, sinon limma), colonnes limma secondaires (_limma),
        # puis analyse imputée conservée (_imputed) quand la DPC est principale.
        ordered = [f"{cname}_diff", f"{cname}_p.val", f"{cname}_p.adj",
                   f"{cname}_p.val_limma", f"{cname}_p.adj_limma",
                   f"Pi_Score_{cname}", f"Robustness_Score_{cname}",
                   f"{cname}_diff_imputed", f"{cname}_p.val_imputed",
                   f"{cname}_p.adj_imputed", f"{cname}_p.val_imputed_limma",
                   f"{cname}_p.adj_imputed_limma", f"Pi_Score_imputed_{cname}",
                   f"Robustness_Score_imputed_{cname}"]
        for col in ordered:
            if col in df_comp_src.columns:
                cols_keep.append(col)
    cols_keep = [c for c in cols_keep if c in df_comp_src.columns]
    write_df(ws, df_comp_src[cols_keep])

    # --- Volcano Plots ---
    ws = wb.create_sheet("Volcano_Plots")
    p_str = f"{'p.adj' if params['volcano_use_padj'] else 'p.value'} < {params['volcano_p_thresh']} | ratio ≥ {params['volcano_ratio_min']}"
    ws.append([f"Facet Volcano — {len(contrast_names)} comparaisons | {p_str}"])
    insert_img(ws, facet_volc, anchor="A3", max_w_px=1100, max_h_px=1400)

    # Volcanos individuels : placés bien en dessous du facet, en grille 3 colonnes
    # avec espacement régulier (le facet peut être très haut avec beaucoup de
    # contrastes, donc on démarre largement plus bas).
    facet_rows = ceil(len(contrast_names) / 4) * 22 + 8
    base_row = max(60, facet_rows)
    for i, f in enumerate(volc_files):
        r = base_row + (i // 3) * IMG_ROW_STEP
        c = (i % 3) * IMG_COL_STEP + 1
        insert_img(ws, f, row=r, col=c)

    # --- Intersections UpSet ---
    # Image de l'UpSet à GAUCHE (col 1), tableau d'intersections à DROITE.
    # La largeur de l'UpSet varie selon le nombre de contrastes : on décale
    # donc le tableau dynamiquement en fonction de la largeur réelle de l'image.
    ws = wb.create_sheet("UpSet_Intersections")
    UPSET_MAX_W, UPSET_MAX_H = 1100, 850
    insert_img(ws, upset_file, row=1, col=1,
               max_w_px=UPSET_MAX_W, max_h_px=UPSET_MAX_H)

    if df_intersections is not None and len(df_intersections) > 0:
        # Colonne de départ du tableau = largeur de l'image (en colonnes) + marge
        start_col = 1
        if upset_file and os.path.exists(str(upset_file)):
            start_col = img_width_cols(upset_file, UPSET_MAX_W, UPSET_MAX_H) + 1
        # En-tête
        for j, colname in enumerate(df_intersections.columns):
            cell = ws.cell(row=1, column=start_col + j, value=colname)
            cell.fill = header_fill
            cell.font = header_font
        # Données
        for i, row in enumerate(df_intersections.itertuples(index=False), start=2):
            for j, val in enumerate(row):
                ws.cell(row=i, column=start_col + j, value=val)

    # --- Z-score Heatmap ---
    ws = wb.create_sheet("Zscore_Heatmap")
    if mat_zscore is not None and len(sig_names) > 0:
        df_z = pd.DataFrame(mat_zscore,
                            columns=design["label"].values)
        df_z.insert(0, "Protein.Group", sig_names[:len(df_z)])
        write_df(ws, df_z, fill=zscore_fill)
        # heatmap après les colonnes de données
        z_col = df_z.shape[1] + 2
    else:
        z_col = 13
    insert_img(ws, hm_classic, row=2, col=z_col, max_w_px=900, max_h_px=1100)

    # --- ANOVA Classique ---
    ws = wb.create_sheet("ANOVA_Results")
    write_df(ws, df_anova)
    insert_img(ws, hm_classic, row=2, col=df_anova.shape[1] + 2,
               max_w_px=900, max_h_px=1100)

    # --- ANOVA Clusters ---
    ws = wb.create_sheet("ANOVA_Clusters")
    write_df(ws, df_anova)
    base_c = df_anova.shape[1] + 2
    insert_img(ws, hm_clusters, row=2, col=base_c, max_w_px=900, max_h_px=1100)
    insert_img(ws, hm_violin,   row=2, col=base_c + IMG_COL_STEP + 5,
               max_w_px=900, max_h_px=600)

    wb.save(out_path)
    print(f"  [OK] Excel file saved: {out_path}")


# ==============================================================================
# HELPERS
# ==============================================================================

def _condition_colors(conditions) -> dict:
    """Génère une palette de couleurs par condition."""
    unique_conds = list(dict.fromkeys(conditions))
    n = max(len(unique_conds), 1)
    # API compatible matplotlib < 3.7 et >= 3.9 (get_cmap supprimé en 3.9)
    try:
        cmap = matplotlib.colormaps["tab20"].resampled(n)
    except (AttributeError, KeyError):
        cmap = plt.cm.get_cmap("tab20", n)
    return {c: matplotlib.colors.to_hex(cmap(i))
            for i, c in enumerate(unique_conds)}


def _makedirs(path):
    os.makedirs(path, exist_ok=True)
    return path


def _col_letter(n: int) -> str:
    """Convertit un index de colonne (1-based) en lettres Excel (A, B, … AA…)."""
    result = ""
    while n > 0:
        n, rem = divmod(n - 1, 26)
        result = chr(65 + rem) + result
    return result


# ==============================================================================
# WGCNA — Fonctions intégrées
# ==============================================================================

WGCNA_CONFIG = {
    "soft_power":       None,   # None = auto-détection | int = valeur fixe
    "min_module_size":  10,
    "merge_cut_height": 0.25,
    "n_powers_test":    range(1, 21),
    # Allègement : ne garder que les N protéines les plus variables pour le réseau.
    # La TOM est en O(N²) en mémoire et O(N²·échantillons) en temps ; au-delà de
    # ~5000 protéines le calcul devient lourd. Les protéines peu variables
    # n'apportent rien à l'analyse de co-expression.
    "max_proteins":     2000,   # None = pas de filtrage | int = top-N par variance
}


def wgcna_pick_soft_threshold(datExpr: pd.DataFrame, powers: range,
                               out_dir: str) -> tuple[int, str]:
    """
    Sélection automatique du soft-thresholding power.
    Retourne le plus petit power avec R² ≥ 0.80 sur le fit scale-free.
    """
    print("\n[WGCNA] Soft power selection...")
    X = datExpr.values  # (n_samples × n_proteins)
    corr_mat = np.corrcoef(X.T)
    np.fill_diagonal(corr_mat, 0)

    r2_fits, mean_k = [], []
    for power in powers:
        adj = np.abs(corr_mat) ** power
        k = adj.sum(axis=0)
        mean_k.append(k.mean())
        k_pos = k[k > 0]
        if len(k_pos) < 5:
            r2_fits.append(0)
            continue
        hist_counts, bin_edges = np.histogram(k_pos, bins=20)
        bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
        valid = hist_counts > 0
        log_k = np.log10(bin_centers[valid])
        log_p = np.log10(hist_counts[valid] / hist_counts[valid].sum())
        if len(log_k) < 3:
            r2_fits.append(0)
            continue
        coeffs = np.polyfit(log_k, log_p, 1)
        y_pred = np.polyval(coeffs, log_k)
        ss_res = np.sum((log_p - y_pred) ** 2)
        ss_tot = np.sum((log_p - log_p.mean()) ** 2)
        r2_fits.append(max(1 - ss_res / ss_tot if ss_tot > 0 else 0, 0))

    powers_list = list(powers)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    ax1.plot(powers_list, r2_fits, "o-", color="#2C3E50")
    ax1.axhline(0.80, color="red", ls="--", lw=1, label="R² = 0.80")
    ax1.set_xlabel("Soft Thresholding Power")
    ax1.set_ylabel("Scale Free Topology R²")
    ax1.set_title("Soft Power selection")
    ax1.legend()
    ax2.plot(powers_list, mean_k, "s-", color="#3498DB")
    ax2.set_xlabel("Soft Thresholding Power")
    ax2.set_ylabel("Mean connectivity")
    ax2.set_title("Mean connectivity vs Power")
    fig.tight_layout()
    f = os.path.join(out_dir, "wgcna_soft_threshold.png")
    fig.savefig(f, dpi=150)
    plt.close(fig)

    best_power = next((p for p, r2 in zip(powers_list, r2_fits) if r2 >= 0.80), None)
    if best_power is None:
        best_power = powers_list[np.argmax(r2_fits)]
        print(f"  [WARN] R2 < 0.80 for all powers. Best: {best_power} (R2={max(r2_fits):.2f})")
    else:
        print(f"  [OK] Soft power: {best_power} (R2={r2_fits[powers_list.index(best_power)]:.2f})")
    return best_power, f


def wgcna_build_network(datExpr: pd.DataFrame, soft_power: int) -> tuple[np.ndarray, np.ndarray]:
    """TOM signée hybride par blocs (500×500) pour gestion mémoire."""
    print(f"\n[WGCNA] Network construction (soft power={soft_power})...")
    X = datExpr.values.T  # (n_proteins × n_samples)
    n = X.shape[0]
    corr = np.corrcoef(X)
    np.fill_diagonal(corr, 0)
    adj = np.abs(corr) ** soft_power
    np.fill_diagonal(adj, 0)
    k = adj.sum(axis=1)

    print(f"  -> TOM computation ({n} x {n})...")
    block_size = 500
    TOM = np.zeros((n, n), dtype=np.float32)
    for i in range(0, n, block_size):
        ei = min(i + block_size, n)
        for j in range(0, n, block_size):
            ej = min(j + block_size, n)
            L = adj[i:ei, :] @ adj[:, j:ej]
            min_k = np.minimum(k[i:ei, np.newaxis], k[np.newaxis, j:ej])
            denom = np.maximum(min_k + 1 - adj[i:ei, j:ej], 1e-10)
            TOM[i:ei, j:ej] = (L + adj[i:ei, j:ej]) / denom
    np.fill_diagonal(TOM, 0)
    TOM = np.clip(TOM, 0, 1)
    print("  [OK] TOM computed")
    return TOM, adj


def wgcna_detect_modules(TOM: np.ndarray, datExpr: pd.DataFrame,
                          min_module_size: int, merge_cut_height: float,
                          out_dir: str) -> tuple[np.ndarray, np.ndarray, str]:
    """
    Clustering hiérarchique sur dissimilarité TOM + découpe dynamique.
    Fusion des modules trop similaires (corrélation ME > 1 - merge_cut_height).
    """
    print("\n[WGCNA] Module detection...")
    diss = 1 - TOM
    diss_cond = np.maximum(squareform(diss, checks=False), 0)
    Z = linkage(diss_cond, method="average")

    cut_h = np.percentile(Z[:, 2], 80)
    labels_raw = fcluster(Z, t=cut_h, criterion="distance")

    unique, counts = np.unique(labels_raw, return_counts=True)
    small = unique[counts < min_module_size]
    labels_clean = labels_raw.copy()
    for s in small:
        labels_clean[labels_clean == s] = 0

    valid = sorted(set(labels_clean) - {0})
    remap = {old: new for new, old in enumerate(valid, 1)}
    remap[0] = 0
    labels_clean = np.array([remap[l] for l in labels_clean])

    # Calcul des MEs pour fusion
    ME_dict = {}
    for mod in sorted(set(labels_clean)):
        idx = np.where(labels_clean == mod)[0]
        if len(idx) >= 2:
            me = PCA(n_components=1).fit_transform(datExpr.values[:, idx]).flatten()
            ME_dict[mod] = me

    # Fusion itérative
    merged = True
    while merged:
        merged = False
        mods = sorted(set(labels_clean) - {0})
        for i in range(len(mods)):
            for j in range(i + 1, len(mods)):
                m1, m2 = mods[i], mods[j]
                if m1 not in ME_dict or m2 not in ME_dict:
                    continue
                r, _ = pearsonr(ME_dict[m1], ME_dict[m2])
                if (1 - r) < merge_cut_height:
                    labels_clean[labels_clean == m2] = m1
                    idx1 = np.where(labels_clean == m1)[0]
                    if len(idx1) >= 2:
                        ME_dict[m1] = PCA(n_components=1).fit_transform(
                            datExpr.values[:, idx1]).flatten()
                    del ME_dict[m2]
                    merged = True
                    break
            if merged:
                break

    valid = sorted(set(labels_clean) - {0})
    remap = {old: new for new, old in enumerate(valid, 1)}
    remap[0] = 0
    labels_clean = np.array([remap.get(l, 0) for l in labels_clean])

    n_final = len(set(labels_clean)) - (1 if 0 in labels_clean else 0)
    print(f"  [OK] {n_final} modules detected (after merging)")

    colors_palette = _wgcna_color_palette(int(labels_clean.max()) + 1)
    # Liste Python (pas np.array) : np.array de strings donne np.str_ qui
    # provoque ValueError dans matplotlib lors de la résolution RGBA.
    module_colors = [str(colors_palette[l]) for l in labels_clean]

    # Augmenter la limite de récursion (scipy dendrogram est récursif sur les feuilles)
    import sys as _sys
    _old_limit = _sys.getrecursionlimit()
    _sys.setrecursionlimit(max(_old_limit, len(module_colors) * 3 + 1000))

    n_leaves = Z.shape[0] + 1
    f_dendro = os.path.join(out_dir, "wgcna_dendrogram.png")
    try:
        # 1) Récupérer l'ordre des feuilles SANS tracer (pas de récursion d'affichage)
        dend_order = dendrogram(Z, no_plot=True)
        leaf_order = dend_order["leaves"]

        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=(max(12, min(len(module_colors) * 0.05, 60)), 6),
            gridspec_kw={"height_ratios": [4, 0.5]})

        # 2) Dendrogramme : tronqué si trop de feuilles (illustratif, modules déjà calculés)
        if n_leaves > 400:
            dendrogram(Z, ax=ax1, no_labels=True, color_threshold=0,
                       above_threshold_color="grey",
                       link_color_func=lambda k: "grey",
                       truncate_mode="lastp", p=120)
            ax1.set_title(f"Protein dendrogram (TOM dissimilarity) — "
                          f"truncated to the last 120 clusters / {n_leaves} proteins")
        else:
            dendrogram(Z, ax=ax1, no_labels=True, color_threshold=0,
                       above_threshold_color="grey",
                       link_color_func=lambda k: "grey")
            ax1.set_title("Protein dendrogram (TOM dissimilarity)")
        ax1.set_ylabel("Height")

        # 3) Barre de couleur des modules selon l'ordre RÉEL des feuilles
        for xi, col in enumerate([module_colors[i] for i in leaf_order]):
            ax2.add_patch(mpatches.Rectangle((xi, 0), 1, 1, color=col))
        ax2.set_xlim(0, len(leaf_order))
        ax2.set_ylim(0, 1)
        ax2.axis("off")
        fig.tight_layout()
        fig.savefig(f_dendro, dpi=150, bbox_inches="tight")
        plt.close(fig)
    except RecursionError:
        # Garde-fou : si le tracé échoue malgré tout, on produit juste la barre
        # de couleurs des modules (les modules eux-mêmes restent valides).
        print("  [WARN] Dendrogram too deep to plot — module bar only.")
        try:
            leaf_order = list(range(len(module_colors)))
            fig, ax2 = plt.subplots(figsize=(14, 1.2))
            for xi, col in enumerate(module_colors):
                ax2.add_patch(mpatches.Rectangle((xi, 0), 1, 1, color=col))
            ax2.set_xlim(0, len(module_colors)); ax2.set_ylim(0, 1); ax2.axis("off")
            ax2.set_title("WGCNA modules (dendrogram not plotted)")
            fig.savefig(f_dendro, dpi=150, bbox_inches="tight")
            plt.close(fig)
        except Exception:
            f_dendro = None
    finally:
        _sys.setrecursionlimit(_old_limit)

    return module_colors, labels_clean, f_dendro


def _wgcna_color_palette(n: int) -> list:
    wgcna_colors = [
        "grey", "turquoise", "blue", "brown", "yellow", "green",
        "red", "black", "pink", "magenta", "purple", "greenyellow",
        "tan", "salmon", "cyan", "midnightblue", "lightcyan", "#999999",
        "lightgreen", "lightyellow", "royalblue", "darkred", "darkgreen",
        "darkturquoise", "darkgrey", "orange", "darkorange", "white",
        "skyblue", "saddlebrown", "steelblue", "paleturquoise", "violet",
    ]
    extended = wgcna_colors + [to_hex(plt.cm.tab20(i % 20))
                                for i in range(max(0, n - len(wgcna_colors) + 1))]
    return extended[:n + 1]


def wgcna_compute_eigengenes(datExpr: pd.DataFrame, module_colors: np.ndarray,
                              design: pd.DataFrame, out_dir: str
                              ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, str]:
    """Module eigengenes (PC1 par module) + corrélation avec les traits (conditions)."""
    print("\n[WGCNA] Module eigengenes and trait correlation...")
    unique_mods = sorted(set(module_colors))
    ME_dict = {}
    for mod in unique_mods:
        idx = np.where(np.array(module_colors) == mod)[0]
        if len(idx) < 2:
            continue
        me = PCA(n_components=1).fit_transform(datExpr.values[:, idx]).flatten()
        mean_mod = datExpr.values[:, idx].mean(axis=1)
        if pearsonr(me, mean_mod)[0] < 0:
            me = -me
        ME_dict[f"ME_{mod}"] = me

    df_ME = pd.DataFrame(ME_dict, index=datExpr.index)

    conditions = design["condition"].values
    unique_conds = sorted(set(conditions))
    df_traits = pd.DataFrame(
        {c: (conditions == c).astype(float) for c in unique_conds},
        index=design["label"].values
    ).loc[datExpr.index]

    n_me, n_tr = len(df_ME.columns), len(df_traits.columns)
    cor_mat  = np.zeros((n_me, n_tr))
    pval_mat = np.zeros((n_me, n_tr))
    for i, me_col in enumerate(df_ME.columns):
        for j, tr_col in enumerate(df_traits.columns):
            r, p = pearsonr(df_ME[me_col].values, df_traits[tr_col].values)
            cor_mat[i, j]  = r
            pval_mat[i, j] = p

    df_cor  = pd.DataFrame(cor_mat,  index=df_ME.columns, columns=df_traits.columns)
    df_pval = pd.DataFrame(pval_mat, index=df_ME.columns, columns=df_traits.columns)

    # Heatmap module-trait
    fig, ax = plt.subplots(figsize=(max(6, n_tr * 0.7), max(5, n_me * 0.45)))
    im = ax.imshow(df_cor.values, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
    for i in range(n_me):
        for j in range(n_tr):
            r = df_cor.values[i, j]
            p = df_pval.values[i, j]
            ax.text(j, i, f"{r:.2f}\n({p:.3f})", ha="center", va="center",
                    fontsize=max(5, 9 - n_me // 4),
                    color="black" if abs(r) < 0.7 else "white")
    ax.set_xticks(range(n_tr))
    ax.set_xticklabels(df_cor.columns, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(n_me))
    ax.set_yticklabels(df_cor.index, fontsize=8)
    for tick, me in zip(ax.get_yticklabels(), df_cor.index):
        try:
            tick.set_color(me.replace("ME_", ""))
        except Exception:
            pass
    plt.colorbar(im, ax=ax, fraction=0.03, label="Pearson r")
    ax.set_title("Module–Trait correlation\n(r, p-value)", fontsize=10)
    fig.tight_layout()
    f_hm = os.path.join(out_dir, "wgcna_module_trait_heatmap.png")
    fig.savefig(f_hm, dpi=150, bbox_inches="tight")
    plt.close(fig)

    return df_ME, df_cor, df_pval, f_hm


def wgcna_compute_hub_scores(datExpr: pd.DataFrame, df_ME: pd.DataFrame,
                              module_colors: np.ndarray, meta: pd.DataFrame,
                              out_dir: str) -> tuple[pd.DataFrame, pd.DataFrame, str]:
    """kME par protéine + hub score (kME du module propre) + barplot top 5."""
    print("\n[WGCNA] Hub scores (kME)...")
    protein_names = datExpr.columns.tolist()
    unique_mods   = sorted(set(module_colors))

    kme_dict = {}
    for mod in unique_mods:
        me_col = f"ME_{mod}"
        if me_col not in df_ME.columns:
            continue
        me_vals  = df_ME[me_col].values
        kme_vals = np.array([pearsonr(datExpr[p].values, me_vals)[0]
                             for p in protein_names])
        kme_dict[f"kME_{mod}"] = kme_vals

    df_kme = pd.DataFrame(kme_dict, index=protein_names)

    hub_scores = np.array([
        df_kme.loc[p, f"kME_{module_colors[k]}"]
        if f"kME_{module_colors[k]}" in df_kme.columns else np.nan
        for k, p in enumerate(protein_names)
    ])

    df_final = pd.DataFrame({
        "Gene_Name":    protein_names,
        "Module_Color": module_colors,
        "HubScore":     hub_scores,
    })
    if "name" in meta.columns:
        meta_sub = meta[["name", "Genes", "First.Protein.Description"]].drop_duplicates("name")
        df_final = df_final.merge(meta_sub, left_on="Gene_Name",
                                   right_on="name", how="left").drop(columns="name", errors="ignore")
    df_final = df_final.sort_values(["Module_Color", "HubScore"],
                                     ascending=[True, False]).reset_index(drop=True)

    # Barplot top 5 hubs par module
    # Boucle explicite : évite le comportement variable de groupby+apply
    # selon la version pandas (2.x peut perdre Module_Color après reset_index)
    _df_non_grey = df_final[df_final["Module_Color"] != "grey"]
    df_plot = pd.concat(
        [grp.nlargest(5, "HubScore") for _, grp in _df_non_grey.groupby("Module_Color")],
        ignore_index=True
    ) if len(_df_non_grey) > 0 else pd.DataFrame(columns=df_final.columns)
    mods = df_plot["Module_Color"].unique() if len(df_plot) > 0 else []
    n_mods = len(mods)
    f_hubs = None
    if n_mods > 0:
        n_cols = min(4, n_mods)
        n_rows = (n_mods + n_cols - 1) // n_cols
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 3.5, n_rows * 3))
        axes = np.array(axes).flatten()
        for idx, mod in enumerate(mods):
            ax = axes[idx]
            sub = df_plot[df_plot["Module_Color"] == mod].sort_values("HubScore")
            ax.barh(sub["Gene_Name"].values, sub["HubScore"].values,
                    color=str(mod), edgecolor="white")
            ax.set_title(f"Module {mod}", fontsize=9, fontweight="bold", color=str(mod))
            ax.set_xlabel("kME", fontsize=8)
            ax.tick_params(labelsize=7)
            ax.set_xlim(0, 1)
        for idx in range(n_mods, len(axes)):
            axes[idx].set_visible(False)
        fig.suptitle("Top 5 Hub Proteins per Module", fontsize=11, fontweight="bold")
        fig.tight_layout()
        f_hubs = os.path.join(out_dir, "wgcna_hubs.png")
        fig.savefig(f_hubs, dpi=150, bbox_inches="tight")
        plt.close(fig)

    print(f"  [OK] Hub scores computed ({len(protein_names)} proteins)")
    return df_final, df_kme, f_hubs


def wgcna_module_summary(df_final: pd.DataFrame, df_cor: pd.DataFrame,
                          out_dir: str) -> tuple[pd.DataFrame, str]:
    """Résumé par module : taille, top hub, top trait corrélé."""
    rows = []
    for mod, grp in df_final.groupby("Module_Color"):
        n = len(grp)
        top_hub = grp.nlargest(1, "HubScore")["Gene_Name"].values[0] if n > 0 else ""
        top_hub_score = grp["HubScore"].max()
        me_col = f"ME_{mod}"
        if me_col in df_cor.index:
            top_trait = df_cor.loc[me_col].abs().idxmax()
            top_r     = df_cor.loc[me_col, top_trait]
        else:
            top_trait, top_r = "", np.nan
        rows.append({"Module": mod, "N_proteins": n, "Top_Hub": top_hub,
                     "Hub_kME": round(top_hub_score, 3),
                     "Top_Trait": top_trait, "Trait_r": round(float(top_r), 3)})

    df_summary = pd.DataFrame(rows).sort_values("N_proteins", ascending=False)

    # Le module 'grey' n'est PAS un module de co-expression : il regroupe les
    # protéines NON assignées (ne corrèlent avec aucun réseau). On l'affiche
    # quand même — son poids renseigne sur la qualité du clustering — mais
    # visuellement distinct (hachures + placé en dernier) pour ne pas le
    # confondre avec un vrai module co-régulé.
    real_mods = df_summary[df_summary["Module"] != "grey"]
    grey_mod  = df_summary[df_summary["Module"] == "grey"]
    mods_plot = pd.concat([real_mods, grey_mod])  # grey toujours en dernier

    fig, ax = plt.subplots(figsize=(max(8, len(mods_plot) * 0.5), 4))
    bars = ax.bar(mods_plot["Module"], mods_plot["N_proteins"],
                  color=[str(c) for c in mods_plot["Module"].values],
                  edgecolor="black", linewidth=0.6)
    # Distinguer la barre grey : hachures + libellé
    for bar, mod in zip(bars, mods_plot["Module"].values):
        if mod == "grey":
            bar.set_hatch("///")
            bar.set_edgecolor("#555555")
            ax.annotate("unassigned", (bar.get_x() + bar.get_width() / 2,
                        bar.get_height()), ha="center", va="bottom",
                        fontsize=7, color="#555555", style="italic")
    ax.set_xlabel("Module")
    ax.set_ylabel("Number of proteins")
    ax.set_xticks(range(len(mods_plot)))
    ax.set_xticklabels(mods_plot["Module"], rotation=45, ha="right", fontsize=8)
    n_grey = int(grey_mod["N_proteins"].iloc[0]) if len(grey_mod) else 0
    n_total = int(df_summary["N_proteins"].sum())
    pct_grey = (100 * n_grey / n_total) if n_total else 0
    ax.set_title(f"WGCNA module sizes  (grey = unassigned: "
                 f"{n_grey}, {pct_grey:.0f}%)")
    fig.tight_layout()
    f_sizes = os.path.join(out_dir, "wgcna_module_sizes.png")
    fig.savefig(f_sizes, dpi=150)
    plt.close(fig)

    return df_summary, f_sizes


def run_wgcna(mat_imp: pd.DataFrame, meta: pd.DataFrame,
              design: pd.DataFrame, out_dir: str) -> dict:
    """
    Point d'entrée WGCNA. Reçoit mat_imp (protéines × samples) directement
    depuis le pipeline DEP — pas besoin de relire l'Excel.
    Retourne un dict avec tous les objets et chemins de figures.
    """
    print("\n" + "="*60)
    print("  WGCNA — Protein co-expression analysis")
    print("="*60)

    cfg = WGCNA_CONFIG

    # Orientation WGCNA : samples en lignes, protéines en colonnes
    datExpr = mat_imp.T.copy()
    datExpr.columns = meta["name"].values[:datExpr.shape[1]]
    datExpr.index   = design["label"].values

    # Nettoyage : exclure colonnes avec > 50% NaN
    col_ok  = datExpr.isna().mean(axis=0) < 0.5
    datExpr = datExpr.loc[:, col_ok].fillna(datExpr.mean(axis=0))
    n_total = datExpr.shape[1]

    # Allègement : filtrer sur les protéines les plus variables.
    # La TOM est O(N²) ; au-delà de max_proteins on ne garde que les plus variables
    # (les protéines invariantes n'informent pas la co-expression).
    max_prot = cfg.get("max_proteins")
    if max_prot is not None and n_total > max_prot:
        variances = datExpr.var(axis=0)
        top_cols = variances.sort_values(ascending=False).head(max_prot).index
        datExpr = datExpr[top_cols]
        print(f"  -> {n_total} proteins -> {datExpr.shape[1]} kept "
              f"(top variance, TOM lightening) | {datExpr.shape[0]} samples")
    else:
        print(f"  -> {datExpr.shape[1]} proteins | {datExpr.shape[0]} samples")

    # 1. Soft threshold
    if cfg["soft_power"] is None:
        soft_power, f_thresh = wgcna_pick_soft_threshold(
            datExpr, cfg["n_powers_test"], out_dir)
    else:
        soft_power = cfg["soft_power"]
        f_thresh   = None
        print(f"  [INFO] Soft power fixed: {soft_power}")

    # 2. TOM
    TOM, adj = wgcna_build_network(datExpr, soft_power)

    # 3. Modules
    module_colors, labels_int, f_dendro = wgcna_detect_modules(
        TOM, datExpr, cfg["min_module_size"], cfg["merge_cut_height"], out_dir)

    # 4. Eigengenes + corrélation traits
    df_ME, df_cor, df_pval, f_hm = wgcna_compute_eigengenes(
        datExpr, module_colors, design, out_dir)

    # 5. Hub scores
    df_final, df_kme, f_hubs = wgcna_compute_hub_scores(
        datExpr, df_ME, module_colors, meta, out_dir)

    # 6. Résumé
    df_summary, f_sizes = wgcna_module_summary(df_final, df_cor, out_dir)

    print("  [OK] WGCNA done")
    return {
        "df_final": df_final, "df_kme": df_kme, "df_ME": df_ME,
        "df_cor": df_cor, "df_pval": df_pval, "df_summary": df_summary,
        "f_thresh": f_thresh, "f_dendro": f_dendro,
        "f_hm": f_hm, "f_hubs": f_hubs, "f_sizes": f_sizes,
    }


def export_wgcna_sheets(wb: openpyxl.Workbook, wgcna: dict,
                         write_df_fn, ins_img_fn):
    """
    Ajoute les onglets WGCNA au classeur Excel DEP existant.
    Reçoit les helpers write_df et ins_img pour réutiliser le même style.
    """
    df_final  = wgcna["df_final"]
    df_kme    = wgcna["df_kme"]
    df_ME     = wgcna["df_ME"]
    df_cor    = wgcna["df_cor"]
    df_pval   = wgcna["df_pval"]
    df_summary = wgcna["df_summary"]

    # --- Résultats principaux ---
    ws = wb.create_sheet("WGCNA_Results")
    write_df_fn(ws, df_final)
    col_img = len(df_final.columns) + 2
    ins_img_fn(ws, wgcna["f_hm"],   f"{_col_letter(col_img)}2")
    ins_img_fn(ws, wgcna["f_hubs"], f"{_col_letter(col_img)}42")

    # --- Résumé modules ---
    ws2 = wb.create_sheet("WGCNA_Modules")
    write_df_fn(ws2, df_summary)
    ins_img_fn(ws2, wgcna["f_sizes"], "H2")

    # --- kME complet ---
    ws3 = wb.create_sheet("WGCNA_kME")
    df_kme_out = df_kme.reset_index().rename(columns={"index": "Gene_Name"})
    write_df_fn(ws3, df_kme_out)

    # --- Module Eigengenes ---
    ws4 = wb.create_sheet("WGCNA_Eigengenes")
    df_ME_out = df_ME.reset_index().rename(columns={"index": "Sample"})
    write_df_fn(ws4, df_ME_out)

    # --- Corrélation module-trait ---
    ws5 = wb.create_sheet("WGCNA_ModuleTrait")
    df_cor_out = df_cor.reset_index().rename(columns={"index": "Module"})
    write_df_fn(ws5, df_cor_out)
    # P-values sous les corrélations
    row_start = len(df_cor_out) + 3
    ws5.cell(row=row_start, column=1, value="P-values")
    df_pval_out = df_pval.reset_index().rename(columns={"index": "Module"})
    for row in df_pval_out.itertuples(index=False):
        ws5.append(list(row))
    ins_img_fn(ws5, wgcna["f_hm"], "H2")

    # --- Diagnostics ---
    ws6 = wb.create_sheet("WGCNA_Diagnostics")
    ins_img_fn(ws6, wgcna["f_thresh"],  "A2")
    ins_img_fn(ws6, wgcna["f_dendro"], "M2")


# ==============================================================================
# MAIN
# ==============================================================================

def main():
    # --- Configuration : YAML / rechargement / interactif ---
    # resolve_config gère les trois modes sans modifier le comportement interactif :
    #   · python deimos.py --config mon_projet.yaml  → zéro question
    #   · python deimos.py --save-config             → questions + sauvegarde
    #   · python deimos.py                           → propose last_config ou questions
    # last_config.yaml est toujours sauvegardé dans out_dir après chaque run.
    _pr_path_default = "report.pr_matrix.tsv"

    params = resolve_config(
        ask_params_fn     = ask_params,
        ask_go_params_fn  = ask_go_params if _GO_AVAILABLE else lambda: None,
        go_available      = _GO_AVAILABLE,
        dash_available    = _DASHBOARD_AVAILABLE,
        pr_path           = _pr_path_default,
    )

    # --- Variables locales reconstituées (compatibilité avec le reste de main()) ---
    tsv_path    = params["tsv_path"]
    design_path = params["design_path"]
    pr_path     = params.get("pr_path", _pr_path_default)
    out_dir     = params["out_dir"]
    make_wgcna  = params["make_wgcna"]
    make_dash   = params["make_dashboard"]
    use_deqms   = params["use_deqms"]

    # --- 0. Conversion des identifiants (optionnelle, clé YAML id_mapping) ---
    # Remplace les identifiants du Protein.Group dans pg ET pr_matrix via une table
    # de correspondance (ex. UPI UniParc -> locus tags reconnus par STRING), sans
    # relancer DIA-NN. Matrices converties dans <out_dir>/id_mapping/ ; seules les
    # variables locales changent : params["tsv_path"] reste le fichier d'origine
    # (labels des runs, dossier des FASTA, last_config.yaml). Idempotent.
    if params.get("id_mapping"):
        from id_remap import apply_id_mapping
        tsv_path, pr_path = apply_id_mapping(params, tsv_path, pr_path, out_dir)

    # go_params : dict {"organism": "bnapus"} attendu par run_go_enrichment, ou None.
    # Mode Perseverance (annotation par orthologie) : independant de gProfiler/go_organism,
    # active des que perseverance_annotation_path est fourni.
    # Backend STRING (go_backend='string') : espèce = NCBI taxid (go_species_taxid)
    # au lieu d'un code gProfiler — le GO est actif si la cible du backend choisi
    # est renseignée.
    _go_org = params.get("go_organism")
    _go_backend = params.get("go_backend", "gprofiler")
    _go_target = params.get("go_species_taxid") if _go_backend == "string" else _go_org
    _perseverance_path = params.get("perseverance_annotation_path")
    if _perseverance_path:
        _perseverance_annot = pd.read_csv(_perseverance_path, sep="\t")
        go_params = {"organism": _go_org, "run_gsea": params.get("run_gsea", False),
                    "custom_annotation": _perseverance_annot, "background": None}
        print(f"[GO] Annotation custom Perseverance chargee : {_perseverance_path} "
              f"({len(_perseverance_annot)} proteines annotees)")
    elif _GO_AVAILABLE and _go_target:
        _bg_mode = params.get("enrichment_background", "quantified")
        go_params = {"organism": _go_org, "run_gsea": params.get("run_gsea", False),
                    "backend": _go_backend,
                    "species_taxid": params.get("go_species_taxid"),
                    "caller_identity": params.get("string_caller_identity"),
                    "background_mode": _bg_mode,
                    "string_background": params.get("string_background") or _bg_mode,
                    "string_categories": params.get("string_categories")}
        if (_go_backend == "string" and params.get("string_background")
                and params["string_background"] != _bg_mode):
            print(f"[GO] STRING background = '{params['string_background']}' "
                  f"(string_background set in the configuration; remove the key to "
                  f"follow enrichment_background: {_bg_mode}).")
    else:
        go_params = None
        if _go_backend == "string" and not params.get("go_species_taxid"):
            print("[WARN] go_backend='string' sans go_species_taxid — GO désactivé.")

    _makedirs(out_dir)

    # --- 0. Diagnostic labels ---
    if not diagnose_labels(tsv_path, design_path):
        sys.exit(1)

    # --- 1. Chargement ---
    tsv, design = load_data(tsv_path, design_path)

    # --- 1ter. Pré-vol STRING : taxid validé/détecté AVANT les stats ---
    # Échec rapide plutôt qu'au GO après tout le pipeline. Pour les bactéries,
    # STRING indexe par SOUCHE : un taxid d'espèce (ex. 1304) renvoie 404.
    # Le taxid retenu est réécrit dans params -> feuille Methods exacte.
    # --- 1bis0. Design sans aucun réplicat -> mode QC seul (automatique) ---
    if not params.get("qc_only") and no_replicate_design(design):
        _nc = design["condition"].nunique()
        params["qc_only"] = True
        params["qc_only_reason"] = (
            f"no replicate ({len(design)} samples for {_nc} conditions): residual "
            f"variance cannot be estimated, differential statistics are impossible")
        print(f"\n[QC-ONLY] Aucun réplicat ({len(design)} échantillons, {_nc} "
              f"conditions) : statistiques impossibles -> mode QC seul "
              f"(données brutes, M&M, figures QC).")
    elif params.get("qc_only"):
        print("\n[QC-ONLY] Mode QC seul demandé (qc_only) : données brutes, M&M, "
              "figures QC.")

    if (go_params and go_params.get("backend") == "string"
            and not params.get("qc_only")):
        print("\n[STEP] STRING — vérification de l'organisme...")
        _plan = plan_string_mapping(
            tsv["Protein.Group"].astype(str).tolist(),
            go_params.get("species_taxid"),
            go_params.get("caller_identity") or "Proteogen",
            gene_names=(tsv["Genes"].astype(str).tolist()
                        if "Genes" in tsv.columns else None),
            reference_taxid=params.get("string_reference_taxid"))
        if _plan["mode"] is None:
            go_params = None
        else:
            go_params["species_taxid"] = _plan["taxid"]
            go_params["string_mode"] = _plan["mode"]
            params["go_species_taxid"] = _plan["taxid"]
            params["go_species_name"] = _plan["name"]
            params["go_string_mode"] = _plan["mode"]
            params["go_string_strain"] = (
                f"{_plan['strain_name']} (taxid {_plan['strain_taxid']})"
                if _plan.get("strain_name") else None)

    # --- 1bis. Détection multi-organismes (host/pathogen ou plus) ---
    # Générique : repose sur le suffixe '_TAG' de Protein.Names, pas sur une
    # liste fixe (MAGGI/OSHVF ne sont pas codés en dur — n'importe quelle
    # fusion de FASTA avec cette convention est détectée automatiquement).
    species_tag = detect_species_tags(tsv)
    tag_counts = species_tag.value_counts(dropna=True)

    do_split = False
    if len(tag_counts) > 1:
        if go_params and go_params.get("custom_annotation") is not None:
            print(f"  [WARN] perseverance_annotation_path est partagé entre les "
                  f"{len(tag_counts)} organismes détectés (même limite que "
                  f"go_organism actuellement) — l'annotation Perseverance ne "
                  f"couvrira correctement que l'organisme dont elle provient. "
                  f"Fournir une annotation par organisme nécessiterait de "
                  f"reconstruire go_params à l'intérieur de la boucle.")
        cfg_split = params.get("species_split")   # None si absent du YAML
        if cfg_split is None:
            do_split = ask_species_split(tag_counts)
        else:
            do_split = bool(cfg_split)
            print(f"\n[CONFIG] species_split={do_split} (from config)")
    elif len(tag_counts) == 1:
        print(f"\n[INFO] Single organism detected (_{tag_counts.index[0]}) "
              f"— no split needed.")
    else:
        print("\n[INFO] No recognizable '_TAG' suffix in Protein.Names "
              "— running as a single combined dataset.")

    if do_split:
        subsets = [(tag, tsv[species_tag == tag].reset_index(drop=True))
                   for tag in tag_counts.index]
        n_unassigned = int(species_tag.isna().sum())
        if n_unassigned:
            print(f"  [WARN] {n_unassigned} protein group(s) without a recognizable "
                  f"organism suffix — excluded from the split (check Protein.Names).")
    else:
        subsets = [(None, tsv)]

    base_out_dir = out_dir
    for tag, tsv_subset in subsets:
        run_out_dir = os.path.join(base_out_dir, tag) if tag else base_out_dir
        _makedirs(run_out_dir)
        label = tag or "combined"
        print(f"\n{'='*60}\n  RUN: {label}  ({len(tsv_subset)} protein groups)\n{'='*60}")
        run_pipeline_core(
            tsv=tsv_subset, design=design, out_dir=run_out_dir, pr_path=pr_path,
            params=params, go_params=go_params, make_wgcna=make_wgcna,
            make_dash=make_dash, use_deqms=use_deqms,
        )


def no_replicate_design(design: pd.DataFrame) -> bool:
    """Vrai si aucune condition n'a de réplicat : ddl résiduels = n - k = 0,
    donc aucune variance estimable -> statistiques différentielles impossibles."""
    if design is None or "condition" not in design.columns or design.empty:
        return False
    n_cond = design["condition"].nunique()
    return len(design) - n_cond < 1


def export_qc_excel(tsv: pd.DataFrame, mat_log2: pd.DataFrame, meta: pd.DataFrame,
                    design: pd.DataFrame, params: dict, qc_files: list,
                    pca_imgs: list, n_complete: int, reason: str, out_path: str):
    """Classeur du mode QC seul : M&M amont, Methods (traitement QC), données
    brutes, matrice log2 (non imputée), figures QC et PCA/corrélation."""
    from openpyxl.utils import get_column_letter
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    hdr_fill, hdr_font = PatternFill("solid", fgColor="D9D9D9"), Font(bold=True)

    def write_df(ws, df):
        ws.append([str(c) for c in df.columns])
        for cell in ws[1]:
            cell.fill, cell.font = hdr_fill, hdr_font
        for row in df.itertuples(index=False):
            ws.append([None if (isinstance(v, float) and np.isnan(v)) else v
                       for v in row])

    def insert_img(ws, path, row, col, max_w=560, max_h=440):
        if not path or not os.path.exists(str(path)):
            return
        p = str(path)
        try:
            from PIL import Image as _PIL
            im = _PIL.open(p)
            s = min(max_w / im.size[0], max_h / im.size[1], 1.0)
            if s < 1.0:
                base, ext = os.path.splitext(p)
                p = f"{base}_xl{ext}"
                im.resize((int(im.size[0] * s), int(im.size[1] * s)),
                          _PIL.LANCZOS).save(p)
        except Exception:
            pass
        ws.add_image(XLImage(p), f"{get_column_letter(col)}{row}")

    # 1. M&M amont (préparation, LC-MS/MS, DIA-NN) — identique au mode complet
    build_mm_sheet(wb.create_sheet("Methods_Upstream"))

    # 2. Methods : traitement effectué en mode QC
    ws = wb.create_sheet("Methods")
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 42
    ws.column_dimensions["C"].width = 80
    ws.append(["DATA PROCESSING — QC only (no differential statistics)"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([])
    ws.append(["Item", "Value", "Detail"])
    for cell in ws[3]:
        cell.fill, cell.font = hdr_fill, hdr_font
    conds = design["condition"].astype(str)
    rows = [
        ("Mode", "QC only", reason),
        ("Input", os.path.basename(str(params.get("tsv_path", "pg_matrix"))),
         "DIA-NN protein group matrix (contaminants 'cRAP' removed)"),
        ("Protein groups", str(len(mat_log2)), "all quantified protein groups"),
        ("Samples", str(mat_log2.shape[1]),
         f"{conds.nunique()} condition(s): " + ", ".join(dict.fromkeys(conds))),
        ("Intensities", "log2(LFQ)", "Zero intensities treated as missing; "
         "no filtering, no imputation, no normalisation beyond DIA-NN"),
        ("QC figures", "sheet QC", "Detection frequency, proteins per sample, "
         "intensity distributions, RLE, missing-value map"),
        ("PCA / correlation", "sheet PCA_Correlation",
         f"Computed on the {n_complete} protein groups quantified in all samples "
         f"(complete cases, no imputation); PCA on standardised log2 values, "
         f"Pearson correlation"),
        ("Differential statistics", "not performed", reason),
    ]
    for r in rows:
        ws.append(list(r))
    for row in ws.iter_rows(min_row=4):
        row[0].font = Font(bold=True)

    # 3. Données brutes et matrice log2
    write_df(wb.create_sheet("raw_data"), tsv)
    log2 = mat_log2.copy()
    log2.columns = [str(c) for c in design["label"].values]
    for col in ("First.Protein.Description", "Genes", "Protein.Group"):
        if col in meta.columns and len(meta) == len(log2):
            log2.insert(0, col, meta[col].values)
    write_df(wb.create_sheet("Log2"), log2.round(4))

    # 4. Figures
    ws = wb.create_sheet("QC")
    for i, f in enumerate(qc_files):
        insert_img(ws, f, row=(i // 3) * 24 + 1, col=(i % 3) * 10 + 1)
    if pca_imgs:
        ws = wb.create_sheet("PCA_Correlation")
        for i, f in enumerate(pca_imgs):
            insert_img(ws, f, row=(i // 2) * 24 + 1, col=(i % 2) * 10 + 1)

    wb.save(out_path)


def run_qc_only(tsv: pd.DataFrame, mat_log2: pd.DataFrame, meta: pd.DataFrame,
                design: pd.DataFrame, params: dict, qc_files: list,
                out_dir: str) -> str:
    """Mode QC seul : figures QC + PCA/corrélation sur les cas complets, puis
    Excel (M&M, Methods, données brutes, log2, figures). Aucune imputation,
    statistique, WGCNA, GO ni dashboard."""
    reason = params.get("qc_only_reason") or "requested in the configuration (qc_only)"
    mat = mat_log2.copy()
    mat.columns = design["label"].values
    complete = mat.dropna()
    pca_imgs = []
    print(f"\n[QC-ONLY] PCA / corrélation sur les {len(complete)} protéines "
          f"quantifiées dans tous les échantillons (sans imputation)...")
    if len(complete) >= 10 and mat.shape[1] >= 3:
        try:
            _pca = plot_pca(complete, design, out_dir,
                            data_label="complete cases, no imputation")
            # Variante « ellipses 95 % » inutile si aucune condition n'a >= 3
            # échantillons (aucune ellipse traçable) : on ne garde que la simple.
            if design["condition"].value_counts().max() < 3:
                for f in _pca:
                    if "_ellipses" in os.path.basename(str(f)):
                        try:
                            os.remove(f)
                        except OSError:
                            pass
                _pca = [f for f in _pca if "_ellipses" not in os.path.basename(str(f))]
            pca_imgs += _pca
        except Exception as e:
            print(f"  [SKIP] PCA ({type(e).__name__}: {str(e)[:60]})")
        try:
            pca_imgs.append(plot_correlation_heatmap(complete, design, out_dir))
        except Exception as e:
            print(f"  [SKIP] Corrélation ({type(e).__name__}: {str(e)[:60]})")
    else:
        print("  [SKIP] PCA/corrélation : moins de 3 échantillons ou de 10 "
              "protéines complètes.")
    out_path = os.path.join(out_dir, "ProteomicAnalysis_QC.xlsx")
    print("\n[EXCEL] Generating the QC Excel file...")
    export_qc_excel(tsv, mat_log2, meta, design, params, qc_files, pca_imgs,
                    len(complete), reason, out_path)
    print(f"  [OK] Excel file saved: {out_path}")
    # Figures déjà intégrées à l'Excel : on ne supprime QUE celles de ce run
    # (et leurs copies redimensionnées), pas d'éventuels fichiers d'autres runs.
    for f in list(qc_files) + list(pca_imgs):
        if not f:
            continue
        base, ext = os.path.splitext(str(f))
        for p in (str(f), f"{base}_xl{ext}"):
            try:
                os.remove(p)
            except OSError:
                pass
    print(f"  Sheets: Methods_Upstream, Methods, raw_data, Log2, QC"
          f"{', PCA_Correlation' if pca_imgs else ''}")
    print("\n[DONE] QC-only pipeline finished (no statistics, WGCNA, GO or dashboard).")
    return out_path


def _run_basename(c: str) -> str:
    return re.split(r"[\\/]", str(c))[-1]


def _injection_key(c: str) -> str:
    """Nom de run sans le label d'échantillon (ex. '260622-_Slot1-19_1_5580.d') :
    identifie l'injection même quand le label a été corrigé dans un seul des deux
    fichiers DIA-NN."""
    b = _run_basename(c)
    m = re.search(r"(Sple-[^_]+)_", b)
    return b.replace(m.group(1), "", 1) if m else ""


def _precursor_columns(pr_cols: list, labels: list, pg_path=None) -> "tuple[dict, list]":
    """Colonne du pr_matrix pour chaque label analysé. Retourne (mapping, notes).

    1. Par le pg_matrix (même recherche DIA-NN) : nom de run identique, sinon même
       injection (nom de run sans le label) quand le label a été corrigé dans le
       pg_matrix seulement (ex. doublon Sple-21 renommé Sple-33).
    2. Sinon par label ('Sple-xxx' extrait du nom de run, ou nom exact, ou nom se
       terminant par '.<label>' / '-<label>'), comme pour le pg_matrix.
    Un label porté par plusieurs runs du pr_matrix n'est jamais choisi au hasard :
    il reste non apparié (repli, avec avertissement)."""
    notes = []
    by_label = {}
    for c in pr_cols:
        m = re.search(r"(Sple-[^_]+)_", str(c))
        by_label.setdefault(m.group(1) if m else str(c), []).append(c)
    by_name = {_run_basename(c): c for c in pr_cols}
    by_inj = {}
    for c in pr_cols:
        k = _injection_key(c)
        if k:
            by_inj.setdefault(k, []).append(c)
    pg_of = {}
    if pg_path and os.path.exists(str(pg_path)):
        try:
            raw, clean = _extract_labels_from_tsv(str(pg_path))
            for r, cl in zip(raw, clean):
                pg_of.setdefault(cl, []).append(r)
        except Exception:
            pg_of = {}
    out = {}
    for lbl in map(str, labels):
        cand_pg = pg_of.get(lbl) or [r for cl, rs in pg_of.items()
                                     if cl.endswith(f".{lbl}") or cl.endswith(f"-{lbl}")
                                     for r in rs]
        if len(cand_pg) == 1:
            r = cand_pg[0]
            if _run_basename(r) in by_name:
                out[lbl] = by_name[_run_basename(r)]
                continue
            inj = by_inj.get(_injection_key(r), [])
            if len(inj) == 1:
                out[lbl] = inj[0]
                notes.append(f"{_run_basename(inj[0])} -> {lbl}")
                continue
        cand = by_label.get(lbl)
        if cand is None:
            keys = [k for k in by_label if k.endswith(f".{lbl}") or k.endswith(f"-{lbl}")]
            cand = by_label[min(keys, key=len)] if keys else []
        if len(cand) == 1:
            out[lbl] = cand[0]
        elif len(cand) > 1:
            notes.append(f"AMBIGUOUS {lbl}: {len(cand)} runs in the pr_matrix")
    return out, notes


def _load_precursor_matrix(pr_path, labels, pg_path=None) -> "dict | None":
    """Matrice log2 des précurseurs (report.pr_matrix.tsv de DIA-NN), colonnes dans
    l'ordre des échantillons analysés (labels du design), et Protein.Group de chaque
    précurseur. None si le fichier est absent, illisible ou incomplet.
    Appariement des runs : _precursor_columns (par le pg_matrix si pg_path est
    donné, sinon par label)."""
    if not pr_path or not os.path.exists(str(pr_path)):
        return None
    try:
        pr = pd.read_csv(pr_path, sep="\t", low_memory=False)
    except Exception as e:
        print(f"  [WARN] pr_matrix unreadable ({type(e).__name__}).")
        return None
    if "Protein.Group" not in pr.columns:
        return None
    num = [c for c in pr.columns if pd.api.types.is_numeric_dtype(pr[c])]
    found, notes = _precursor_columns(num, list(labels), pg_path)
    for n_ in notes:
        if n_.startswith("AMBIGUOUS"):
            print(f"  [WARN] pr_matrix: {n_[10:]} — sample not matched (fix the run "
                  f"names so that each sample has one injection).")
    renamed = [n_ for n_ in notes if not n_.startswith("AMBIGUOUS")]
    if renamed:
        print(f"  [INFO] pr_matrix: {len(renamed)} run(s) matched to the pg_matrix by "
              f"injection (label differs between the two files): {'; '.join(renamed[:4])}")
    missing = [l for l in map(str, labels) if l not in found]
    if missing:
        print(f"  [WARN] {len(missing)} sample(s) not found in the pr_matrix "
              f"({missing[:3]}...).")
        return None
    Y = pr[[found[str(l)] for l in labels]].to_numpy(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        Y = np.log2(np.where(Y > 0, Y, np.nan))
    pid = pr["Protein.Group"].astype(str)
    # Contaminants cRAP retirés comme dans load_data
    keep = ~pid.str.startswith("cRAP").to_numpy()
    if "Protein.Names" in pr.columns:
        keep &= ~pr["Protein.Names"].astype(str).str.startswith("cRAP").to_numpy()
    return {"Y": Y[keep], "protein_ids": pid.to_numpy()[keep], "renamed": renamed}


def run_dpc_primary_step(mat_log2: pd.DataFrame, mat_filt: pd.DataFrame,
                         df_results: pd.DataFrame, model_info: dict,
                         params: dict, pr_path: "str | None") -> "dict | None":
    """primary_statistic: dpc — statistique principale SANS imputation (méthode
    limpa : DPC au niveau précurseur -> quantification -> limma pondéré), sur le
    MÊME design et les MÊMES contrastes que le modèle imputé.

    Retourne le résultat (dpc_sensitivity.dpc_primary_analysis + robustesse
    leave-one-sample-out), ou None : la statistique principale reste alors
    l'analyse imputée (pr_matrix absent ou inutilisable, module absent, échec).
    Ne lève jamais."""
    if str(params.get("primary_statistic", "dpc")).lower() != "dpc":
        return None
    print("\n[STEP] Primary statistic: imputation-free DPC analysis (limpa method)...")
    why = None
    if not _DPC_AVAILABLE:
        why = "dpc_sensitivity.py not found next to deimos.py"
    elif not model_info:
        why = "model not available"
    elif "Protein.Group" not in df_results.columns:
        why = "no Protein.Group column"
    precursors = None
    if why is None:
        precursors = _load_precursor_matrix(pr_path or params.get("pr_path"),
                                            list(mat_filt.columns),
                                            pg_path=params.get("tsv_path"))
        if precursors is None:
            why = f"no usable pr_matrix ({pr_path or params.get('pr_path')})"
    if why is None:
        try:
            from dpc_sensitivity import dpc_primary_analysis, dpc_loo_robustness
            res = dpc_primary_analysis(
                mat_log2.values, mat_filt.values,
                df_results["Protein.Group"].astype(str).to_numpy(),
                model_info["design_mat"], model_info["contrast_mat"],
                fdr_global=bool(params.get("fdr_global")), precursors=precursors)
            if res["level"] != "precursor":
                why = "pr_matrix proteins do not match the pg_matrix"
            else:
                res["robustness"] = None
                if int(params.get("n_iter_robustness", 0) or 0) > 0:
                    print("  [...] DPC robustness score (leave-one-sample-out)...")
                    res["robustness"] = dpc_loo_robustness(
                        res, model_info["n_groups"], params,
                        fdr_global=bool(params.get("fdr_global")))
                n_sig = [int(((res["p_adj"] if params.get("volcano_use_padj")
                               else res["p_value"])[:, k] < params["volcano_p_thresh"]).sum())
                         for k in range(res["p_value"].shape[1])]
                print(f"  [OK] Primary statistic = DPC + weighted limma "
                      f"({res['dpc_precursor']['n_proteins_quantified']} proteins from "
                      f"precursors); imputed analysis kept in _imputed columns. "
                      f"p-threshold passed per contrast: {n_sig[:6]}"
                      f"{'...' if len(n_sig) > 6 else ''}")
                return res
        except Exception as e:
            why = f"{type(e).__name__}: {e}"
    print(f"  [WARN] DPC primary statistic not available ({why}) — the primary statistic "
          f"stays the imputed analysis (imputation + limma/DEqMS).")
    params["_dpc_primary_fallback"] = why
    return None


def condition_means(expr: np.ndarray, conditions) -> dict:
    """Moyenne par condition, clés au format des contrastes (cf. make_all_contrasts)."""
    conditions = np.asarray(conditions)
    out = {}
    for cond in np.unique(conditions):
        idx = np.where(conditions == cond)[0]
        cond_clean = re.sub(r"[^A-Za-z0-9_]", ".", cond)
        cond_clean = "X" + cond_clean if cond_clean[0].isdigit() else cond_clean
        out[cond_clean.replace(".", "_")] = np.nanmean(expr[:, idx], axis=1)
    return out


MATRICES_README = """\
Deimos — protein x sample matrices for other analyses
======================================================
Time courses / clustering (Mfuzz), factor models (MOFA+, MEFISTO), integration
with transcriptomics / methylation (MOFA+, DIABLO / mixOmics, ...).

Normalisation
  Intensities = DIA-NN protein-group quantities (MaxLFQ), with DIA-NN's
  RT-dependent cross-run normalisation. Deimos adds no further normalisation:
  log2, 0 -> NA, cRAP contaminants removed. Residual normalisation check: RLE
  plot in the QC sheet of the workbook.
  Proteins kept: {filter_rule} ({n_prot} proteins, {n_samp} samples).

Files (rows = proteins, same order in every file; first columns = annotation:
protein (unique ID), Protein.Group, Genes, Description; then one column per
sample, in the order of samples.tsv)
  log2_filtered_NA.tsv    log2, missing values kept as NA (no imputation).
                          -> MOFA+ / MEFISTO: they model missing values; an
                             imputed value would be read as a measurement.
  log2_imputed.tsv        same matrix, imputed ({imp_method}, seed {seed}) — as
                          the Log2_Impute sheet; used by Deimos for PCA, ANOVA,
                          heatmaps, WGCNA.
                          -> methods that need a complete matrix (Mfuzz, WGCNA...).
                             Imputed low values (MNAR) pull profiles down: keep
                             proteins with few NA (num_NA column of
                             log2_filtered_NA) or use the DPC matrix.
{dpc_block}  samples.tsv             sample metadata (label, condition, replicate...).
                          Add the numeric covariates (time, stage) needed by
                          MEFISTO; the label column must match the sample IDs of
                          the other omics.

Integration with other omics
  - same sample IDs in every view; same biological samples (or same conditions
    if the integration is done on condition means);
  - feature names unique across views: prefix them (e.g. "prot_" + protein);
  - one value per gene is not required: protein groups are features of their own
    (Genes column to match with transcripts);
  - remove known batch effects before integration, and select variable features
    so that the views stay balanced (e.g. same order of magnitude of features).

R
  x  <- read.delim("log2_filtered_NA.tsv", check.names = FALSE)
  s  <- read.delim("samples.tsv", check.names = FALSE)
  M  <- as.matrix(x[, s$label]); rownames(M) <- x$protein
"""

_DPC_README_BLOCK = """\
  dpc_abundance.tsv       protein abundances estimated from the precursors under
                          the detection probability curve (limpa method, the
                          primary statistic of the differential analysis):
                          complete matrix, no random draw; an unobserved value is
                          the posterior estimate, not a measurement. Scale of the
                          precursor intensities (not MaxLFQ): use it for profiles
                          across samples, not to compare abundances between
                          proteins with the LFQ values.
  dpc_standard_error.tsv  standard error of each value (precision weights).
  dpc_observed.tsv        1 = at least one precursor observed in the sample,
                          0 = estimated without observation. To give MOFA+ the DPC
                          values without the unobserved ones, set them to NA.
  condition_means_dpc.tsv mean DPC abundance per condition (column order of
                          samples.tsv) -> Mfuzz on condition means.
"""


def export_matrices(out_dir: str, mat_filt: pd.DataFrame, mat_imp: pd.DataFrame,
                    meta: pd.DataFrame, design: pd.DataFrame,
                    dpc_primary: "dict | None" = None, params: "dict | None" = None
                    ) -> "str | None":
    """Écrit dans <out_dir>/matrices/ les matrices protéines × échantillons pour
    d'autres analyses que les contrastes (Mfuzz, MOFA+/MEFISTO, intégration
    multi-omique) : log2 filtrée avec NA, log2 imputée, abondances DPC (+ erreurs
    standard, observé oui/non, moyennes par condition), métadonnées des
    échantillons et README. Mêmes lignes, même ordre dans tous les fichiers.
    Ne lève jamais (retourne None en cas d'échec)."""
    params = params or {}
    try:
        d = os.path.join(out_dir, "matrices")
        _makedirs(d)
        samples = [str(c) for c in mat_filt.columns]
        n = len(mat_filt)
        meta = meta.reset_index(drop=True)

        def _col(c):
            return (meta[c].fillna("").astype(str).to_numpy()
                    if c in meta.columns and len(meta) == n else np.full(n, "", dtype=object))
        pid = _col("name")
        pid = np.where(pid == "", _col("Protein.Group"), pid)
        pid = np.where(pid == "", [f"protein_{i + 1}" for i in range(n)], pid)
        s = pd.Series(pid)
        dup = s.duplicated(keep=False)
        if dup.any():                       # identifiants uniques (MOFA, rownames R)
            s[dup] = s[dup] + "_" + (s[dup].groupby(s[dup]).cumcount() + 1).astype(str)
        ann = pd.DataFrame({"protein": s.to_numpy(), "Protein.Group": _col("Protein.Group"),
                            "Genes": _col("Genes"),
                            "Description": _col("First.Protein.Description")})

        def _write(name, M, digits=4, extra=None):
            body = (pd.DataFrame(np.asarray(M, int), columns=samples) if digits == 0
                    else pd.DataFrame(np.round(np.asarray(M, float), digits), columns=samples))
            parts = [ann] + ([extra] if extra is not None else []) + [body]
            pd.concat(parts, axis=1).to_csv(os.path.join(d, name), sep="\t",
                                            index=False, na_rep="NA")

        des = design.copy()                 # métadonnées dans l'ordre des colonnes
        des["label"] = des["label"].astype(str)
        des = des.set_index("label").reindex(samples).reset_index()
        na = mat_filt.isna().to_numpy()
        _write("log2_filtered_NA.tsv", mat_filt.to_numpy(),
               extra=pd.DataFrame({"num_NA": na.sum(axis=1)}))
        files = ["log2_filtered_NA.tsv"]
        if mat_imp is not None:
            _write("log2_imputed.tsv", mat_imp.to_numpy())
            files.append("log2_imputed.tsv")
        dpc_block = ""
        if dpc_primary is not None and dpc_primary.get("E") is not None:
            E = np.asarray(dpc_primary["E"], float)
            if E.shape == mat_filt.shape:
                _write("dpc_abundance.tsv", E)
                _write("dpc_standard_error.tsv", dpc_primary["SE"])
                obs = (~np.asarray(dpc_primary["imputed"], bool)).astype(int)
                _write("dpc_observed.tsv", obs, digits=0)
                conds = list(dict.fromkeys(des["condition"].astype(str)))
                cv = des["condition"].astype(str).to_numpy()
                means = pd.DataFrame({c: np.round(E[:, cv == c].mean(axis=1), 4)
                                      for c in conds})
                pd.concat([ann, means], axis=1).to_csv(
                    os.path.join(d, "condition_means_dpc.tsv"), sep="\t", index=False,
                    na_rep="NA")
                files += ["dpc_abundance.tsv", "dpc_standard_error.tsv",
                          "dpc_observed.tsv", "condition_means_dpc.tsv"]
                dpc_block = _DPC_README_BLOCK
        des.to_csv(os.path.join(d, "samples.tsv"), sep="\t", index=False, na_rep="NA")
        files.append("samples.tsv")
        with open(os.path.join(d, "README_matrices.txt"), "w", encoding="utf-8") as fh:
            fh.write(MATRICES_README.format(
                filter_rule="detected in all but one replicate of at least one condition",
                n_prot=n, n_samp=len(samples),
                imp_method=str(params.get("impute_method", "")).upper() or "see Methods",
                seed=params.get("seed", 42), dpc_block=dpc_block))
        print(f"  [OK] Matrices for other analyses: {d} ({', '.join(files)})")
        return d
    except Exception as e:                                            # noqa: BLE001
        print(f"  [WARN] Matrices export skipped ({type(e).__name__}: {e})")
        return None


def apply_dpc_primary(df_results: pd.DataFrame, primary: dict,
                      contrast_names: list) -> pd.DataFrame:
    """Met la statistique DPC dans les colonnes principales lues par tout l'aval
    (volcanos, UpSet, GO, GSEA, dashboard, Pathfinder) et CONSERVE l'analyse
    imputée sous des noms suffixés : rien n'est supprimé.
      <C>_diff / _p.val / _p.adj, Pi_Score_<C>, Robustness_Score_<C>  -> DPC
      <C>_diff_imputed / _p.val_imputed / _p.adj_imputed,
      <C>_p.val_imputed_limma / _p.adj_imputed_limma (si DEqMS),
      Pi_Score_imputed_<C>, Robustness_Score_imputed_<C>                -> imputé"""
    df = df_results.copy()
    ren = {}
    for c in contrast_names:
        for suf in ("_diff", "_p.val", "_p.adj"):
            ren[f"{c}{suf}"] = f"{c}{suf}_imputed"
        for suf in ("_p.val_limma", "_p.adj_limma"):
            ren[f"{c}{suf}"] = f"{c}{suf.replace('_limma', '_imputed_limma')}"
        ren[f"Pi_Score_{c}"] = f"Pi_Score_imputed_{c}"
        ren[f"Robustness_Score_{c}"] = f"Robustness_Score_imputed_{c}"
    df = df.rename(columns={k: v for k, v in ren.items() if k in df.columns})
    rob = primary.get("robustness")
    new = {"dpc_source": primary["source"], "n_precursors": primary["n_precursors"]}
    for k, c in enumerate(contrast_names):
        lfc, pv = primary["logFC"][:, k], primary["p_value"][:, k]
        new[f"{c}_diff"] = lfc
        new[f"{c}_p.val"] = pv
        new[f"{c}_p.adj"] = primary["p_adj"][:, k]
        new[f"Pi_Score_{c}"] = np.abs(lfc) * (-np.log10(np.maximum(pv, 1e-10)))
        if rob is not None:
            new[f"Robustness_Score_{c}"] = rob["score"][:, k]
    return pd.concat([df.reset_index(drop=True), pd.DataFrame(new)], axis=1)


def run_sensitivity_step(mat_log2: pd.DataFrame, mat_filt: pd.DataFrame,
                         df_results: pd.DataFrame, model_info: dict,
                         params: dict, out_dir: str, primary: "dict | None" = None,
                         pr_path: "str | None" = None) -> "dict | None":
    """Analyses de sensibilité aux valeurs manquantes (dpc_sensitivity.py) :
    1. analyse différentielle sans imputation (DPC), comparée à l'analyse imputée ;
    2. détection différentielle (protéines on/off).
    df_results doit porter l'analyse IMPUTÉE dans ses colonnes principales (appel
    avant apply_dpc_primary). primary : analyse DPC déjà faite comme statistique
    principale, réutilisée sans recalcul ; les onglets comparent alors la
    statistique principale (DPC) à l'analyse imputée. Ne lève jamais : retourne
    None si désactivées, sans objet ou en échec."""
    do_dpc = bool(params.get("dpc_sensitivity", True))
    do_det = bool(params.get("differential_detection", True))
    if not (do_dpc or do_det):
        return None
    print("\n[STEP] Sensitivity to missing values (detection probability curve)...")
    if not _DPC_AVAILABLE:
        print("  [SKIP] dpc_sensitivity.py not found next to deimos.py.")
        return None
    if not model_info or (primary is None and not mat_filt.isna().values.any()):
        print("  [SKIP] No missing value after filtering: nothing to assess.")
        return None
    precursors = None
    level = str(params.get("dpc_level", "auto")).lower()
    if do_dpc and primary is None and level in ("auto", "precursor"):
        precursors = _load_precursor_matrix(pr_path or params.get("pr_path"),
                                            list(mat_filt.columns),
                                            pg_path=params.get("tsv_path"))
        if precursors is None and level == "precursor":
            print("  [INFO] dpc_level: precursor requested but no usable pr_matrix — "
                  "protein level used.")
    try:
        res = run_missingness_sensitivity(
            mat_log2.values, mat_filt.values, df_results,
            model_info["design_mat"], model_info["contrast_mat"],
            model_info["contrast_names"], model_info["n_groups"], params,
            do_dpc=do_dpc, do_detection=do_det, precursors=precursors,
            primary=primary)
    except Exception as e:
        print(f"  [WARN] Sensitivity analyses skipped ({type(e).__name__}: {e}) "
              f"— main results not affected.")
        return None
    try:
        from dpc_sensitivity import plot_dpc
        res["plot"] = plot_dpc(mat_log2.values, res["dpc"]["beta0"], res["dpc"]["beta1"],
                               os.path.join(out_dir, "dpc_curve.png"))
    except Exception:
        res["plot"] = None
    d = res["dpc"]
    res["methods"] = {
        "beta0": d["beta0"], "beta1": d["beta1"], "n_rows": d["n_rows"],
        "lod50": -d["beta0"] / d["beta1"], "dpc": "dpc_sheet" in res,
        "detection": "detection_sheet" in res,
        "n_df_corrected": (res.get("dpc_de") or {}).get("n_df_corrected"),
        "pkey": res["pkey"], "level": res.get("dpc_level", "protein"),
        "precursor": res.get("dpc_precursor"), "primary_dpc": primary is not None,
        "dropout": res.get("dropout_prior")}
    return res


def _sensitivity_manifest_rows(sensitivity, sheets) -> list:
    """Lignes 'sensitivity' du manifeste (schéma 1.1, ajout)."""
    if not sensitivity or not sheets:
        return []
    m = sensitivity["methods"]
    rows = [("sensitivity", "summary_sheet", "Sensitivity_Summary"),
            ("sensitivity", "dpc_beta0", f"{m['beta0']:.4f}"),
            ("sensitivity", "dpc_beta1", f"{m['beta1']:.4f}")]
    if "Sensitivity_DPC" in sheets:
        rows.append(("sensitivity", "dpc_sheet", "Sensitivity_DPC"))
    if "Differential_Detection" in sheets:
        rows.append(("sensitivity", "detection_sheet", "Differential_Detection"))
    return rows


def export_sensitivity_sheets(wb, sensitivity: dict, write_df_fn, ins_img_fn) -> list:
    """Onglets Sensitivity_Summary, Sensitivity_DPC, Differential_Detection
    (ajoutés après l'existant). Noms choisis pour n'être captés ni par les
    filtres GO/WGCNA/UMAP du dashboard, ni comme matrice d'échantillons par
    Pathfinder. Retourne la liste des onglets écrits."""
    written = []
    m = sensitivity["methods"]
    ws = wb.create_sheet("Sensitivity_Summary")
    head = pd.DataFrame({
        "item": ["Detection probability curve (DPC), protein level", "50 % detection at",
                 "Rows used to fit the DPC",
                 "Main analysis" if m.get("primary_dpc") else "Main analysis (unchanged)",
                 "Imputation-free analysis", "Differential detection", "Significance rule"],
        "value": [f"logit p = {m['beta0']:.3f} + {m['beta1']:.3f} x log2 intensity",
                  f"log2 intensity {m['lod50']:.2f}", str(m["n_rows"]),
                  ("imputation-free DPC (sheet Differential_Expression); imputed analysis "
                   "in the *_imputed columns, compared below")
                  if m.get("primary_dpc") else
                  "imputation + limma/DEqMS (sheet Differential_Expression)",
                  (f"sheet Sensitivity_DPC ({m['level']} level"
                   + (f"; precursor DPC logit p = {m['precursor']['beta0']:.3f} + "
                      f"{m['precursor']['beta1']:.3f} y, {m['precursor']['n_precursors']} "
                      f"precursors" if m.get("precursor") else "") + ")")
                  if m["dpc"] else "not run",
                  "sheet Differential_Detection" if m["detection"] else "not run",
                  "volcano thresholds applied to both analyses (detection: p.adj < 0.05)"]})
    write_df_fn(ws, head)
    ws.append([])
    start = ws.max_row + 1
    summ = sensitivity["summary"]
    ws.append(list(summ.columns))
    for row in summ.itertuples(index=False):
        ws.append([None if (isinstance(v, float) and np.isnan(v)) else v for v in row])
    for cell in ws[start]:
        cell.font = Font(bold=True)
    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 58
    if sensitivity.get("plot"):
        ins_img_fn(ws, sensitivity["plot"], f"A{ws.max_row + 3}", max_w_px=640, max_h_px=440)
    written.append("Sensitivity_Summary")
    if "dpc_sheet" in sensitivity:
        write_df_fn(wb.create_sheet("Sensitivity_DPC"), sensitivity["dpc_sheet"])
        written.append("Sensitivity_DPC")
    if "detection_sheet" in sensitivity:
        write_df_fn(wb.create_sheet("Differential_Detection"), sensitivity["detection_sheet"])
        written.append("Differential_Detection")
    return written


def run_pipeline_core(tsv: pd.DataFrame, design: pd.DataFrame, out_dir: str,
                       pr_path: str, params: dict, go_params: "dict | None",
                       make_wgcna: bool, make_dash: bool, use_deqms: bool):
    """
    Corps du pipeline DEP pour UN dataset déjà résolu (organisme unique, ou
    dataset combiné si l'utilisateur a refusé la scission). Appelé une fois
    (mono-organisme) ou en boucle, une fois par organisme détecté, avec un
    out_dir dédié à chacun — jamais de FDR, imputation ou normalisation
    partagés entre organismes.
    """
    # --- 2. Matrice expression ---
    mat_log2, meta, design_filt, lfq_cols = build_expression_matrix(tsv, design)

    # Sécurité : colonnes dupliquées → crash dans pandas lors de l'imputation
    # Doit être fait AVANT plot_qc pour garder mat_log2 et design_filt synchronisés
    if mat_log2.columns.duplicated().any():
        n_dup = mat_log2.columns.duplicated().sum()
        print(f"  [WARN] {n_dup} duplicate sample column(s) in matrix — keeping first occurrence.")
        dup_labels = mat_log2.columns[mat_log2.columns.duplicated()].tolist()
        print(f"         Duplicates: {dup_labels}")
        keep_mask_dup = ~pd.Series(mat_log2.columns).duplicated().values
        mat_log2    = mat_log2.loc[:, keep_mask_dup]
        design_filt = design_filt[keep_mask_dup].reset_index(drop=True)

    # --- 3. QC ---
    print("\n[QC] Quality control...")
    qc_files = plot_qc(mat_log2, meta, design_filt, out_dir)

    # --- Mode QC seul : données brutes + M&M + figures QC, rien d'autre ---
    if params.get("qc_only"):
        run_qc_only(tsv, mat_log2, meta, design_filt, params, qc_files, out_dir)
        if params.get("make_pathfinder"):
            print("  [SKIP] Pathfinder: QC-only mode, no p-values to synthesise.")
        return

    # --- 4. Filtration + Imputation ---
    print("\n[STEP] Filtering and imputation...")
    mat_filt, keep_mask = filter_missval(mat_log2, design_filt, thr=1)
    meta_filt = meta[keep_mask].reset_index(drop=True)

    # Diagnostic de missingness (objective le choix Mixte vs QRILC)
    miss_diag = diagnose_missingness(mat_filt, design_filt, out_dir)
    if miss_diag.get("plot"):
        qc_files.append(miss_diag["plot"])

    # --- Choix de la méthode : 'auto' = décidé par le diagnostic ci-dessus ---
    #   MAR >= 20 % des NA  -> MIXED (QRILC absences totales + kNN partielles)
    #   sinon               -> QRILC
    # Une valeur explicite ('qrilc' / 'mixed') dans le YAML reste prioritaire.
    # Copie locale de params : en mode multi-organisme, chaque dataset refait
    # son propre choix (le dict appelant garde 'auto').
    imp_requested = params.get("impute_method", "auto")
    if imp_requested in (None, "auto", "__auto__"):
        pct_mar = float(miss_diag.get("pct_mar", 0.0) or 0.0)
        imp_method = "mixed" if pct_mar >= AUTO_MIXED_MAR_PCT else "qrilc"
        imp_reason = (f"auto: {miss_diag.get('pct_mnar', 0):.0f}% MNAR / "
                      f"{pct_mar:.0f}% MAR of missing values "
                      f"(MIXED if MAR >= {AUTO_MIXED_MAR_PCT:.0f}%)")
        print(f"  [AUTO] Imputation method -> {imp_method.upper()} ({imp_reason})")
    else:
        imp_method = imp_requested
        imp_reason = "set explicitly in the configuration"
    params = {**params, "impute_method": imp_method,
              "impute_method_requested": imp_requested,
              "impute_method_reason": imp_reason}
    seed = int(params.get("seed", 42))
    # Tirage de référence seedé : les colonnes _p.val/_p.adj et les volcanos
    # sont ainsi reproductibles à l'identique d'un run à l'autre.
    mat_imp = impute(mat_filt, method=imp_method, design=design_filt,
                     rng=np.random.default_rng(seed))
    print(f"  [OK] Imputation: {imp_method.upper()} (seed={seed})")
    qc_imp  = plot_imputation(mat_filt, mat_imp, out_dir)
    qc_files.append(qc_imp)

    # Info d'imputation par protéine (comme le script R) : nombre de valeurs
    # manquantes imputées par protéine, et drapeau imputed oui/non.
    na_mask = mat_filt.isna()
    n_na_per_prot = na_mask.sum(axis=1).values
    imputation_info = pd.DataFrame({
        "imputed": np.where(n_na_per_prot > 0, "VRAI", "FAUX"),
        "num_NAs": n_na_per_prot.astype(int),
    }, index=mat_filt.index)

    mat_imp.columns  = design_filt["label"].values
    mat_filt.columns = design_filt["label"].values

    # --- 4bis. Comptage peptidique pour DEqMS (optionnel) ---
    pep_count = None
    if use_deqms:
        print("\n[STEP] Building peptide count (DEqMS)...")
        pep_count = build_peptide_count_table(
            pr_path, meta_filt["name"].tolist(), count_level="peptide",
            sample_labels=design_filt["label"].astype(str).tolist(),
            pg_path=params.get("tsv_path"))
        if pep_count is None:
            print("  -> DEqMS disabled (counting unavailable).")

    # --- 5. Analyse différentielle + Robustness ---
    print("\n[STEP] Differential analysis + robustness score...")
    N_ITER = params.get("n_iter_robustness", 100)
    model_info = {}
    df_results, contrast_names, scatter_files = run_differential_analysis(
        mat_imp, mat_filt, meta_filt, design_filt, params, out_dir,
        n_iter=N_ITER, pep_count=pep_count, model_out=model_info
    )

    if model_info.get("deqms"):
        params = {**params, "_deqms": model_info["deqms"]}

    # --- 5bis. Statistique principale sans imputation (primary_statistic: dpc) ---
    # Méthode limpa au niveau précurseur, même design et mêmes contrastes. En cas
    # d'indisponibilité (pas de pr_matrix exploitable...), la statistique
    # principale reste l'analyse imputée ci-dessus.
    dpc_primary = run_dpc_primary_step(mat_log2, mat_filt, df_results,
                                       model_info, params, pr_path)

    # --- 5ter. Sensibilité aux valeurs manquantes (AJOUT, non bloquant) ---
    # Lit la matrice NON imputée ; compare la DPC à l'analyse imputée (avant le
    # basculement des colonnes) et ajoute la détection différentielle (on/off).
    sensitivity = run_sensitivity_step(mat_log2, mat_filt, df_results,
                                       model_info, params, out_dir,
                                       primary=dpc_primary, pr_path=pr_path)
    if sensitivity is not None:
        params = {**params, "_sensitivity_methods": sensitivity["methods"]}

    # Basculement : la DPC occupe les colonnes principales lues par tout l'aval
    # (volcanos, UpSet, GO, GSEA, dashboard, Pathfinder) ; l'analyse imputée est
    # conservée dans les colonnes *_imputed.
    if dpc_primary is not None:
        df_results = apply_dpc_primary(df_results, dpc_primary, contrast_names)
        scatter_files = plot_contrast_scatters(
            df_results, contrast_names,
            condition_means(dpc_primary["E"], design_filt["condition"].values),
            params, out_dir)
        _rob = dpc_primary.get("robustness")
        params = {**params, "_primary": {
            "statistic": "dpc", "level": dpc_primary["level"],
            "dpc": dpc_primary["dpc"], "dpc_precursor": dpc_primary["dpc_precursor"],
            "n_df_corrected": dpc_primary["n_df_corrected"],
            "n_protein_level": int((dpc_primary["source"] == "protein").sum()),
            "robustness": _rob is not None,
            "loo_skipped": (_rob or {}).get("n_skipped", 0),
            "imputed_deqms": any(str(c).endswith("_p.adj_imputed_limma")
                                 for c in df_results.columns)}}
    else:
        params = {**params, "_primary": {
            "statistic": "imputation",
            "requested": str(params.get("primary_statistic", "dpc")).lower(),
            "fallback": params.get("_dpc_primary_fallback")}}

    # --- 6. Volcanos ---
    print("\n[STEP] Generating volcano plots...")
    volc_files, facet_volc = plot_volcanoes(df_results, contrast_names, params, out_dir)

    # --- 7. PCA ---
    print("\n[STEP] PCA...")
    pca_files = plot_pca(mat_imp, design_filt, out_dir)

    # --- 8. Corrélation ---
    print("\n[STEP] Correlation heatmap...")
    hm_corr = plot_correlation_heatmap(mat_imp, design_filt, out_dir)

    # --- 9. UMAP ---
    print("\n🗺️  UMAP...")
    umap_file, umap_coords = plot_umap(mat_imp, meta_filt, design_filt, out_dir)

    # --- 10. ANOVA + Heatmaps ---
    print("\n[STEP] ANOVA and heatmaps...")
    (df_anova, hm_classic, hm_clusters, hm_violin,
     mat_zscore, cluster_mapping, sig_names) = run_anova_heatmaps(
        mat_imp, meta_filt, design_filt, params, out_dir
    )

    # --- 10bis. PCA : score plot + loading plot (après l'ANOVA : couleurs = clusters) ---
    print("\n[STEP] PCA loading plot...")
    pca_load_file, pca_loadings, pca_scores = plot_pca_loadings(
        mat_imp, meta_filt, design_filt, df_results, contrast_names,
        cluster_mapping, params, out_dir)
    if pca_load_file:
        print("  [OK] Score + loading plot saved (sheets PCA_UMAP, PCA_Loadings, PCA_Scores)")

    # --- 11. UpSet ---
    print("\n[STEP] UpSet plot...")
    upset_file, df_intersections = plot_upset(df_results, contrast_names, params, out_dir)

    # --- 12. WGCNA (optionnel) ---
    wgcna_results = None
    if make_wgcna:
        print("\n[STEP] WGCNA...")
        wgcna_results = run_wgcna(mat_imp, meta_filt, design_filt, out_dir)
    else:
        print("\n[SKIP] WGCNA not requested — step skipped.")

    # --- 13. Export Excel (DEP + WGCNA dans le même classeur) ---
    output_name = os.path.join(out_dir, "ProteomicAnalysis_Results.xlsx")

    # Helpers partagés pour l'écriture Excel
    hdr_fill = PatternFill("solid", fgColor="D9D9D9")
    hdr_font = Font(bold=True)

    def _write_df(ws, df, fill=hdr_fill):
        ws.append(list(df.columns))
        for cell in ws[1]:
            cell.fill = fill
            cell.font = hdr_font
        for row in df.itertuples(index=False):
            ws.append(list(row))

    def _ins_img(ws, path, anchor, max_w_px=700, max_h_px=900):
        if not (path and os.path.exists(str(path))):
            return
        try:
            from PIL import Image as _PILImage
            im = _PILImage.open(path); w, h = im.size
            scale = min(max_w_px / w, max_h_px / h, 1.0)
            if scale < 1.0:
                im = im.resize((int(w*scale), int(h*scale)), _PILImage.LANCZOS)
                base, ext = os.path.splitext(str(path))
                path = f"{base}_xl{max_w_px}x{max_h_px}{ext}"
                im.save(path)
        except Exception:
            pass
        ws.add_image(XLImage(str(path)), anchor)

    # --- Matrices protéines × échantillons pour d'autres analyses (Mfuzz,
    #     MOFA+/MEFISTO, intégration multi-omique) : dossier matrices/ ---
    if params.get("export_matrices", True):
        export_matrices(out_dir, mat_filt, mat_imp, meta_filt, design_filt,
                        dpc_primary=dpc_primary, params=params)

    export_excel(
        tsv=tsv, df_results=df_results, df_anova=df_anova,
        df_intersections=df_intersections, mat_zscore=mat_zscore,
        meta=meta_filt, sig_names=sig_names, contrast_names=contrast_names,
        design=design_filt, params=params,
        qc_files=qc_files, pca_files=pca_files,
        scatter_files=scatter_files, volc_files=volc_files,
        facet_volc=facet_volc, umap_file=umap_file,
        hm_corr=hm_corr, hm_classic=hm_classic,
        hm_clusters=hm_clusters, hm_violin=hm_violin,
        upset_file=upset_file, out_path=output_name,
        go_enabled=(go_params is not None),
        go_organism=(go_params["organism"] if go_params else None),
        n_iter=N_ITER, use_deqms=(pep_count is not None),
        mat_imp=mat_imp, umap_coords=umap_coords,
        imputation_info=imputation_info, pca_loadings_file=pca_load_file
    )

    # Ré-ouvrir le classeur pour ajouter les onglets WGCNA
    wb = load_workbook(output_name)
    if pca_loadings is not None and len(pca_loadings):
        _pos = (wb.sheetnames.index("PCA_UMAP") + 1) if "PCA_UMAP" in wb.sheetnames else None
        ws = wb.create_sheet("PCA_Loadings", _pos)
        _write_df(ws, pca_loadings.round(5))
        if pca_scores is not None:
            ws = wb.create_sheet("PCA_Scores", (_pos + 1) if _pos is not None else None)
            _write_df(ws, pca_scores.round(4))
    if wgcna_results is not None:
        export_wgcna_sheets(wb, wgcna_results, _write_df, _ins_img)

    # --- 13bis0. Onglets de sensibilité aux valeurs manquantes (ajoutés) ---
    sensitivity_sheets = []
    if sensitivity is not None:
        try:
            sensitivity_sheets = export_sensitivity_sheets(wb, sensitivity, _write_df, _ins_img)
            print(f"  [OK] Sensitivity sheets added: {', '.join(sensitivity_sheets)}")
        except Exception as e:
            print(f"  [WARN] Sensitivity sheets not written ({type(e).__name__}: {e})")

    # --- 13bis. Perseverance (orthologues, optionnel) — APRÈS les stats, AVANT le GO ---
    # Ne mute PAS le go_params partagé entre sous-espèces (boucle multi-especes) :
    # on travaille sur une copie locale, propre à ce subset.
    local_go_params = dict(go_params) if go_params else None
    _string_orth = bool(local_go_params and local_go_params.get("backend") == "string"
                        and local_go_params.get("string_mode") == "ortholog")
    if _string_orth:
        correspondence_df, persev_override = run_string_ortholog_step(
            df_results, params, local_go_params, out_dir)
        _orth_sheet = "Orthologues_STRING"
    elif local_go_params and local_go_params.get("backend") == "string":
        # Backend STRING (mode direct) : Perseverance appartient à la voie gProfiler
        # (orthologues vers une espèce de référence). Ses identifiants (UniProt
        # d'une autre espèce) seraient pris pour des identifiants STRING.
        if params.get("run_perseverance") not in (False, None, "__auto__"):
            print("\n  [INFO] run_perseverance ignored: GO backend = STRING (mapping to "
                  "STRING is handled by the STRING step).")
        correspondence_df, persev_override = None, None
        _orth_sheet = "Orthologues_Perseverance"
    else:
        correspondence_df, persev_override = run_perseverance_step(df_results, params, out_dir)
        _orth_sheet = "Orthologues_Perseverance"
    if correspondence_df is not None:
        export_perseverance_sheet(wb, correspondence_df, _write_df, sheet_name=_orth_sheet)
        print(f"  [OK] {_orth_sheet} sheet added "
              f"({len(correspondence_df)} correspondances).")
    if persev_override is not None:
        local_go_params = {**(local_go_params or {}), **persev_override}
    elif _string_orth:
        print("  [WARN] Orthologie STRING indisponible — GO STRING ignoré pour ce run.")
        local_go_params = None

    # GO sur l'espèce de RÉFÉRENCE (annotation Perseverance ou orthologues
    # Perseverance) : l'organisme mesuré n'est pas celui du GO.
    _persev_go = bool((go_params or {}).get("custom_annotation") is not None
                      or (persev_override is not None and not _string_orth))

    if persev_override is not None and not _string_orth:
        _methods_go_species_orthologs(wb, persev_override.get("organism"),
                                      len(persev_override.get("ortholog_map") or {}),
                                      len(df_results), params)

    # --- 14. Enrichissement GO/gProfiler (optionnel, non bloquant) ---
    go_sheet_map = {}
    if local_go_params is not None:
        print("\n[STEP] GO enrichment...")
        go_results = run_go_enrichment(
            df_results, contrast_names, params, local_go_params, out_dir)
        if go_results:
            go_sheet_map = export_go_sheets(wb, go_results, _write_df, _ins_img) or {}
            print(f"  [OK] {len(go_results)} GO sheet(s) added.")

        # GO par cluster de la heatmap ANOVA (réutilise cluster_mapping)
        if cluster_mapping:
            go_cluster_results = run_go_enrichment_clusters(
                cluster_mapping, params, local_go_params, out_dir,
                universe=df_results["name"].astype(str).tolist())
            if go_cluster_results:
                export_go_cluster_sheets(
                    wb, go_cluster_results, _write_df, _ins_img)
                print(f"  [OK] {len(go_cluster_results)} GO cluster sheet(s) added.")

        # GSEA rank-based (optionnel, complément de l'ORA)
        # (go_params peut être None ici si seul Perseverance a activé le GO)
        if (go_params or {}).get("run_gsea"):
            try:
                from gsea_enrichment import run_gsea, export_gsea_sheets
                gsea_results = run_gsea(
                    df_results, contrast_names, params, go_params, out_dir)
                if gsea_results:
                    export_gsea_sheets(wb, gsea_results, _ins_img)
                    print(f"  [OK] {len(gsea_results)} GSEA sheet(s) added.")
            except Exception as e:
                print(f"  [WARN] GSEA step skipped ({type(e).__name__}) — "
                      f"pipeline not affected.")

    # --- 13ter. Manifeste (contrat lu par Pathfinder), dernier onglet, caché ---
    try:
        write_manifest(
            wb, params, contrast_names, go_sheet_map, design_filt,
            perseverance=_persev_go,
            primary_statistic=(
                "DPC (limpa method, precursor level) + weighted limma eBayes"
                if params["_primary"]["statistic"] == "dpc" else
                "DEqMS" if any(str(c).endswith("_p.adj_limma") for c in df_results.columns)
                else "limma eBayes"),
            extra_rows=_sensitivity_manifest_rows(sensitivity, sensitivity_sheets))
    except Exception as e:      # jamais bloquant pour le livrable
        print(f"  [WARN] _manifest sheet not written ({type(e).__name__}: {e})")

    wb.save(output_name)

    print(f"\n[DONE] Full pipeline finished.")
    print(f"   -> {output_name}")
    suffix_go = " + GO" if local_go_params is not None else ""
    print(f"   Sheets: DEP + UMAP + WGCNA{suffix_go} in a single file.")

    # --- 15. Dashboard HTML interactif (optionnel, non bloquant) ---
    if make_dash and _DASHBOARD_AVAILABLE:
        print("\n[STEP] Generating the interactive HTML dashboard...")
        dash_out = os.path.join(out_dir, "proteogen_dashboard.html")
        result = run_dashboard(output_name, design_filt, dash_out, params=params)
        if result:
            print(f"  [OK] Dashboard generated: {result}")
        else:
            print("  [WARN] Dashboard not generated (see messages above).")

    # --- 15bis. Pathfinder (optionnel, processus séparé, non bloquant) ---
    # Relit le classeur qui vient d'être enregistré : le rapport dérive exactement
    # du fichier livré. Le nettoyage (16) ne touche pas pathfinder/.
    if params.get("make_pathfinder"):
        print("\n[STEP] Pathfinder — multi-contrast synthesis...")
        pf_html = run_pathfinder_step(output_name, design_filt, params, out_dir,
                                      go_ran=bool(go_sheet_map),
                                      perseverance=_persev_go)
        if pf_html:
            print(f"  [OK] Pathfinder report: {pf_html}")

    # --- 16. Nettoyage des figures temporaires ---
    # Toutes les figures sont déjà intégrées dans l'Excel (et le dashboard les
    # embarque en base64). On supprime les PNG/TIFF intermédiaires pour ne pas
    # encombrer le dossier. EXCEPTION : les volcanos (volc_*.png) sont conservés
    # car souvent réutilisés individuellement pour les figures d'article.
    print("\n[CLEAN] Removing temporary figures...")
    keep_prefixes = ("volc_",)              # volcanos individuels conservés
    keep_exact = {"proteogen_dashboard.html",
                  "ProteomicAnalysis_Results.xlsx"}
    removed = 0
    for fn in os.listdir(out_dir):
        if not fn.lower().endswith((".png", ".tiff", ".tif")):
            continue
        # Conserver les volcanos ORIGINAUX (volc_*.png) mais pas leurs copies
        # redimensionnées pour l'Excel (suffixe _xlNNNxNNN).
        is_volcano = fn.startswith("volc_")
        is_resized = "_xl" in fn and "x" in fn.split("_xl")[-1]
        if (is_volcano and not is_resized) or fn in keep_exact:
            continue
        try:
            os.remove(os.path.join(out_dir, fn))
            removed += 1
        except OSError:
            pass
    print(f"  [OK] {removed} temporary figures removed "
          f"(individual volcanos kept).")


if __name__ == "__main__":
    main()
